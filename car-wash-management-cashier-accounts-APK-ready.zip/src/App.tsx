import React, { useState } from 'react';
import { useCarWash } from './context/useCarWash';
import { Navbar } from './components/Navbar';
import { RoleSwitcherModal } from './components/RoleSwitcherModal';
import { NewTransactionModal } from './components/NewTransactionModal';
import { QuickCustomerModal } from './components/QuickCustomerModal';
import { ReceiptModal } from './components/ReceiptModal';
import { QueueHistoryModal } from './components/QueueHistoryModal';

// Screen Views
import { DashboardView } from './views/DashboardView';
import { PosView } from './views/PosView';
import { QueueView } from './views/QueueView';
import { EmployeeView } from './views/EmployeeView';
import { ServicesView } from './views/ServicesView';
import { CustomerVehicleView } from './views/CustomerVehicleView';
import { MembershipView } from './views/MembershipView';
import { AttendanceView } from './views/AttendanceView';
import { FinancialReportView } from './views/FinancialReportView';
import { MasterView } from './views/MasterView';
import { BusinessSettingsView } from './views/BusinessSettingsView';
import { LoginView } from './views/LoginView';
import { TestScenariosView } from './views/TestScenariosView';

import { Transaction, Vehicle } from './types';

export default function App() {
  const {
    storage,
    currentUser,
    currentBusiness,
    businesses,
    users,
    employees,
    services,
    customers,
    vehicles,
    transactions,
    queueHistory,
    attendance,
    packages,
    customerMemberships,
    pointRule,
    auditLogs,
    toastMessage,
    clearToast,
  } = useCarWash();

  const [activeTab, setActiveTab] = useState<string>(() => {
    if (currentUser?.role === 'KASIR') return 'pos';
    if (currentUser?.role === 'STAFF') return 'antrian';
    if (currentUser?.role === 'MASTER') return 'master';
    return 'dashboard';
  });

  // Modal States
  const [isRoleSwitcherOpen, setIsRoleSwitcherOpen] = useState(false);
  const [isNewTxModalOpen, setIsNewTxModalOpen] = useState(false);
  const [isQuickCustomerOpen, setIsQuickCustomerOpen] = useState(false);
  const [activeReceiptTx, setActiveReceiptTx] = useState<Transaction | null>(null);
  const [historyVehicle, setHistoryVehicle] = useState<Vehicle | null>(null);

  // If user is logged out
  if (!currentUser) {
    return (
      <LoginView
        storage={storage}
        onLoginSuccess={user => {
          storage.switchUser(user.id);
          if (user.role === 'MASTER') {
            setActiveTab('master');
          } else if (user.role === 'KASIR') {
            setActiveTab('pos');
          } else if (user.role === 'STAFF') {
            setActiveTab('antrian');
          } else {
            setActiveTab('dashboard');
          }
        }}
      />
    );
  }

  const canViewProfit = storage.canViewFinancials(currentUser.role);
  const canManageProfit = storage.canManageProfitSetting(currentUser.role);
  const canManageStaff = storage.canManageEmployees(currentUser.role);

  // Active vehicle history list
  const selectedVehicleHistory = historyVehicle
    ? storage.getVehicleStatusHistory(historyVehicle.id)
    : [];

  const activeQueueCount = vehicles.filter(v => {
    const latest = queueHistory.find(q => q.vehicleId === v.id)?.status || 'WAITING';
    return latest !== 'PICKED_UP';
  }).length;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 antialiased selection:bg-sky-500 selection:text-white flex flex-col">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
          <div
            className={`px-4 py-2.5 rounded-xl shadow-lg text-xs font-bold flex items-center gap-2 ${
              toastMessage.type === 'success'
                ? 'bg-emerald-600 text-white'
                : toastMessage.type === 'error'
                ? 'bg-red-600 text-white'
                : 'bg-slate-900 text-white'
            }`}
          >
            <span>{toastMessage.text}</span>
            <button onClick={clearToast} className="opacity-70 hover:opacity-100 ml-1 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Top Main Navbar */}
      <Navbar
        storage={storage}
        currentUser={currentUser}
        currentBusiness={currentBusiness}
        businesses={businesses}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenRoleSwitcher={() => setIsRoleSwitcherOpen(true)}
        onOpenNewTx={() => setIsNewTxModalOpen(true)}
        onSwitchBusiness={b => storage.switchBusiness(b.id)}
        onLogout={() => storage.logout()}
        queueActiveCount={activeQueueCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            storage={storage}
            currentUser={currentUser}
            currentBusiness={currentBusiness}
            transactions={transactions}
            employees={employees}
            services={services}
            customers={customers}
            vehicles={vehicles}
            queueHistory={queueHistory}
            onNavigateTab={setActiveTab}
            onOpenNewTxModal={() => setIsNewTxModalOpen(true)}
            onOpenReceipt={tx => setActiveReceiptTx(tx)}
          />
        )}

        {activeTab === 'pos' && (
          <PosView
            storage={storage}
            customers={customers}
            vehicles={vehicles}
            services={services}
            employees={employees}
            transactions={transactions}
            customerMemberships={customerMemberships}
            pointRule={pointRule}
            canViewProfit={canViewProfit}
            onOpenQuickCustomer={() => setIsQuickCustomerOpen(true)}
            onOpenReceipt={tx => setActiveReceiptTx(tx)}
          />
        )}

        {activeTab === 'antrian' && (
          <QueueView
            storage={storage}
            vehicles={vehicles}
            customers={customers}
            transactions={transactions}
            queueHistory={queueHistory}
            onOpenNewTxModal={() => setIsNewTxModalOpen(true)}
            onOpenReceipt={tx => setActiveReceiptTx(tx)}
            onOpenQueueHistory={veh => setHistoryVehicle(veh)}
          />
        )}

        {activeTab === 'karyawan' && (
          <EmployeeView
            storage={storage}
            employees={employees}
            canViewProfit={canViewProfit}
            canManageProfit={canManageProfit}
            canManageStaff={canManageStaff}
          />
        )}

        {activeTab === 'layanan' && (
          <ServicesView storage={storage} services={services} />
        )}

        {activeTab === 'pelanggan' && (
          <CustomerVehicleView
            storage={storage}
            customers={customers}
            vehicles={vehicles}
            customerMemberships={customerMemberships}
            pointRule={pointRule}
            transactions={transactions}
            onOpenQuickCustomer={() => setIsQuickCustomerOpen(true)}
          />
        )}

        {activeTab === 'membership' && (
          <MembershipView
            storage={storage}
            packages={packages}
            customerMemberships={customerMemberships}
            pointRule={pointRule}
            customers={customers}
          />
        )}

        {activeTab === 'absensi' && (
          <AttendanceView
            storage={storage}
            employees={employees}
            attendanceList={attendance}
          />
        )}

        {activeTab === 'laporan' && (
          <FinancialReportView
            storage={storage}
            currentUser={currentUser}
            transactions={transactions}
            employees={employees}
            services={services}
            customers={customers}
            vehicles={vehicles}
            attendance={attendance}
          />
        )}

        {activeTab === 'master' && (
          <MasterView
            storage={storage}
            currentUser={currentUser}
            businesses={businesses}
            users={users}
            auditLogs={auditLogs}
            onSwitchBusiness={b => storage.switchBusiness(b.id)}
          />
        )}

        {activeTab === 'pengaturan' && (
          <BusinessSettingsView
            storage={storage}
            currentBusiness={currentBusiness}
            currentUser={currentUser}
          />
        )}

        {activeTab === 'test' && (
          <TestScenariosView
            storage={storage}
            currentUser={currentUser}
            employees={employees}
            transactions={transactions}
            onSwitchUser={userId => storage.switchUser(userId)}
          />
        )}
      </main>

      {/* Global Modals */}
      <RoleSwitcherModal
        isOpen={isRoleSwitcherOpen}
        onClose={() => setIsRoleSwitcherOpen(false)}
        currentUser={currentUser}
        users={users}
        businesses={businesses}
        onSelectUser={userId => storage.switchUser(userId)}
      />

      <NewTransactionModal
        isOpen={isNewTxModalOpen}
        onClose={() => setIsNewTxModalOpen(false)}
        customers={customers}
        vehicles={vehicles}
        services={services}
        employees={employees}
        customerMemberships={customerMemberships}
        pointRule={pointRule}
        canViewProfit={canViewProfit}
        onConfirm={payload => {
          const res = storage.createTransaction(payload);
          if (res.success && res.transaction) {
            setActiveReceiptTx(res.transaction);
          }
        }}
        onOpenQuickCustomer={() => setIsQuickCustomerOpen(true)}
      />

      <QuickCustomerModal
        isOpen={isQuickCustomerOpen}
        onClose={() => setIsQuickCustomerOpen(false)}
        onConfirm={data => storage.addCustomerWithVehicle(data)}
      />

      <ReceiptModal
        isOpen={!!activeReceiptTx}
        onClose={() => setActiveReceiptTx(null)}
        transaction={activeReceiptTx}
        business={currentBusiness}
        customer={customers.find(c => c.id === activeReceiptTx?.customerId) || null}
        vehicle={vehicles.find(v => v.id === activeReceiptTx?.vehicleId) || null}
      />

      <QueueHistoryModal
        isOpen={!!historyVehicle}
        onClose={() => setHistoryVehicle(null)}
        vehicle={historyVehicle}
        historyList={selectedVehicleHistory}
      />
    </div>
  );
}
