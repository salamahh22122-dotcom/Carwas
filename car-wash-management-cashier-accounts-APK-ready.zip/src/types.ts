export type UserRole = 'MASTER' | 'OWNER' | 'ADMIN' | 'KASIR' | 'STAFF';

export interface UserRoleMeta {
  role: UserRole;
  displayName: string;
  badgeColor: string;
  badgeBg: string;
  level: number;
  description: string;
}

export const USER_ROLES: Record<UserRole, UserRoleMeta> = {
  MASTER: {
    role: 'MASTER',
    displayName: 'Master Admin',
    badgeColor: '#7e22ce',
    badgeBg: '#f3e8ff',
    level: 100,
    description: 'Akses tertinggi sistem, kelola Owner, unit usaha & audit log platform',
  },
  OWNER: {
    role: 'OWNER',
    displayName: 'Owner Bisnis',
    badgeColor: '#0369a1',
    badgeBg: '#e0f2fe',
    level: 80,
    description: 'Akses penuh bisnis, kelola staff, atur % bagi hasil, laporan & POS',
  },
  ADMIN: {
    role: 'ADMIN',
    displayName: 'Admin Operasional',
    badgeColor: '#c2410c',
    badgeBg: '#ffedd5',
    level: 60,
    description: 'Kelola operasional antrian cucian, katalog layanan & pelanggan',
  },
  KASIR: {
    role: 'KASIR',
    displayName: 'Kasir',
    badgeColor: '#15803d',
    badgeBg: '#dcfce7',
    level: 40,
    description: 'Fokus kasir POS & antrian. % Komisi staff dilindungi & dirahasiakan',
  },
  STAFF: {
    role: 'STAFF',
    displayName: 'Staff / Cuci',
    badgeColor: '#475569',
    badgeBg: '#f1f5f9',
    level: 20,
    description: 'Tugas antrian cuci mobil dan presensi kehadiran kerja harian',
  },
};

export type VehicleQueueStatus = 'WAITING' | 'WASHING' | 'DRYING' | 'FINISHED' | 'PICKED_UP';
export type QueueStatus = VehicleQueueStatus;

export interface QueueStatusMeta {
  status: VehicleQueueStatus;
  displayName: string;
  color: string;
  bg: string;
  step: number;
}

export const QUEUE_STATUSES: Record<VehicleQueueStatus, QueueStatusMeta> = {
  WAITING: {
    status: 'WAITING',
    displayName: 'Menunggu',
    color: '#ea580c',
    bg: '#ffedd5',
    step: 1,
  },
  WASHING: {
    status: 'WASHING',
    displayName: 'Sedang Dicuci',
    color: '#0284c7',
    bg: '#e0f2fe',
    step: 2,
  },
  DRYING: {
    status: 'DRYING',
    displayName: 'Pengeringan',
    color: '#7c3aed',
    bg: '#ede9fe',
    step: 3,
  },
  FINISHED: {
    status: 'FINISHED',
    displayName: 'Selesai Dicuci',
    color: '#16a34a',
    bg: '#dcfce7',
    step: 4,
  },
  PICKED_UP: {
    status: 'PICKED_UP',
    displayName: 'Sudah Dijemput',
    color: '#64748b',
    bg: '#f1f5f9',
    step: 5,
  },
};

export type AttendanceStatus = 'PRESENT' | 'LATE' | 'PERMISSION' | 'PERMIT' | 'SICK' | 'ABSENT';

export interface AttendanceStatusMeta {
  status: AttendanceStatus;
  displayName: string;
  color: string;
  bg: string;
}

export const ATTENDANCE_STATUSES: Record<string, AttendanceStatusMeta> = {
  PRESENT: {
    status: 'PRESENT',
    displayName: 'Hadir',
    color: '#16a34a',
    bg: '#dcfce7',
  },
  LATE: {
    status: 'LATE',
    displayName: 'Terlambat',
    color: '#ea580c',
    bg: '#ffedd5',
  },
  PERMISSION: {
    status: 'PERMISSION',
    displayName: 'Izin',
    color: '#0284c7',
    bg: '#e0f2fe',
  },
  PERMIT: {
    status: 'PERMIT',
    displayName: 'Izin',
    color: '#0284c7',
    bg: '#e0f2fe',
  },
  SICK: {
    status: 'SICK',
    displayName: 'Sakit',
    color: '#7c3aed',
    bg: '#ede9fe',
  },
  ABSENT: {
    status: 'ABSENT',
    displayName: 'Alpha',
    color: '#dc2626',
    bg: '#fee2e2',
  },
};

export interface RolePermissionConfig {
  canViewProfitShare: boolean;
  canViewFinancialReports: boolean;
  canManageEmployees: boolean;
  canOperatePos: boolean;
  canManageQueue: boolean;
}

export const ROLE_PERMISSIONS: Record<UserRole, RolePermissionConfig> = {
  MASTER: {
    canViewProfitShare: true,
    canViewFinancialReports: true,
    canManageEmployees: true,
    canOperatePos: true,
    canManageQueue: true,
  },
  OWNER: {
    canViewProfitShare: true,
    canViewFinancialReports: true,
    canManageEmployees: true,
    canOperatePos: true,
    canManageQueue: true,
  },
  ADMIN: {
    canViewProfitShare: false,
    canViewFinancialReports: false,
    canManageEmployees: true,
    canOperatePos: true,
    canManageQueue: true,
  },
  KASIR: {
    canViewProfitShare: false,
    canViewFinancialReports: true,
    canManageEmployees: false,
    canOperatePos: true,
    canManageQueue: true,
  },
  STAFF: {
    canViewProfitShare: false,
    canViewFinancialReports: false,
    canManageEmployees: false,
    canOperatePos: false,
    canManageQueue: true,
  },
};

export interface AdditionalOption {
  id: string;
  name: string;
  price: number;
}

export const DEFAULT_ADDITIONAL_SERVICES: AdditionalOption[] = [
  { id: 'jamur_kaca', name: 'Pembersih Jamur Kaca', price: 25000 },
  { id: 'semir_ban', name: 'Semir Ban Ekstra Kilap', price: 15000 },
  { id: 'fogging', name: 'Fogging Anti-Bakteri Kabin', price: 35000 },
  { id: 'tar_remover', name: 'Hilangkan Noda Aspal/Tar', price: 30000 },
  { id: 'ruang_mesin', name: 'Pembersihan Ruang Mesin', price: 30000 },
];

export interface Business {
  id: number;
  name: string;
  ownerUserId: number;
  address: string;
  phone: string;
  logoUrl?: string;
  status: 'ACTIVE' | 'SUSPENDED';
  createdAt: number;
}

export interface User {
  id: number;
  username: string;
  email?: string;
  passwordHash: string;
  fullName: string;
  phone: string;
  role: UserRole;
  businessId: number | null;
  isActive: boolean;
  isPermanentMaster?: boolean;
  createdAt: number;
}

export interface Employee {
  id: number;
  businessId: number;
  userId?: number | null;
  name: string;
  phone: string;
  position: string;
  status: 'ACTIVE' | 'INACTIVE';
  currentProfitPercentage: number; // Confidential
  createdAt: number;
}

export interface StaffProfitSetting {
  id: number;
  businessId: number;
  employeeId: number;
  percentage: number;
  effectiveDate: number;
  updatedBy: string;
  notes: string;
}

export interface Service {
  id: number;
  businessId: number;
  name: string;
  category: string;
  price: number;
  description: string;
  estimatedDurationMinutes: number;
  isActive: boolean;
  createdAt: number;
}

export interface Customer {
  id: number;
  businessId: number;
  name: string;
  phone: string;
  email: string;
  notes: string;
  pointsBalance: number;
  createdAt: number;
}

export interface Vehicle {
  id: number;
  businessId: number;
  customerId: number;
  licensePlate: string;
  brandModel: string;
  vehicleType: string;
  color: string;
  notes: string;
  createdAt: number;
}

export interface Transaction {
  id: number;
  businessId: number;
  invoiceNo: string;
  queueNumber: number;
  customerId: number;
  vehicleId: number;
  serviceId: number;
  serviceName: string;
  servicePrice: number;
  additionalServices: string;
  additionalAmount: number;
  discountAmount: number;
  totalAmount: number;
  staffShareAmount: number; // Confidential
  ownerShareAmount: number; // Confidential
  assignedStaffNames: string;
  status: string; // 'COMPLETED' | 'CANCELLED'
  queueStatus: VehicleQueueStatus;
  paymentMethod: string; // 'QRIS' | 'CASH' | 'TRANSFER' | 'MEMBERSHIP'
  usedMembershipId?: number | null;
  pointsUsed: number;
  pointsEarned: number;
  cashierUserId: number;
  cashierName: string;
  notes: string;
  createdAt: number;
}

export interface TransactionStaff {
  id: number;
  transactionId: number;
  employeeId: number;
  employeeName: string;
  profitPercentage: number;
  commissionAmount: number;
}

export interface VehicleStatusHistory {
  id: number;
  businessId: number;
  vehicleId: number;
  transactionId?: number | null;
  status: VehicleQueueStatus;
  updatedBy: string;
  notes: string;
  timestamp: number;
}

export interface Attendance {
  id: number;
  businessId: number;
  employeeId: number;
  employeeName: string;
  date: string; // YYYY-MM-DD
  checkInTime: string;
  checkOutTime: string;
  status: AttendanceStatus;
  notes: string;
}

export interface AuditLog {
  id: number;
  businessId: number | null;
  userId: number;
  userName: string;
  userRole: string;
  action: string;
  details: string;
  timestamp: number;
}

export interface MembershipPackage {
  id: number;
  businessId: number;
  name: string;
  price: number;
  totalVisits: number;
  validityDays: number;
  serviceName: string;
  description: string;
  isActive: boolean;
  createdAt: number;
}

export interface CustomerMembership {
  id: number;
  businessId: number;
  customerId: number;
  packageId: number;
  packageName: string;
  totalQuota: number;
  remainingQuota: number;
  purchasePrice: number;
  purchasedAt: number;
  expiresAt: number;
  status: 'ACTIVE' | 'EXPIRED' | 'DEPLETED';
}

export interface PointRule {
  id: number;
  businessId: number;
  spendAmountPerPoint: number;
  pointsEarned: number;
  pointRedeemValue: number;
  isEnabled: boolean;
  updatedAt: number;
}

export interface CustomerPointHistory {
  id: number;
  businessId: number;
  customerId: number;
  transactionId?: number | null;
  pointsChange: number;
  type: 'EARN' | 'REDEEM' | 'BONUS' | 'ADJUSTMENT';
  description: string;
  createdAt: number;
}

export type DatePeriodFilter = 'TODAY' | 'YESTERDAY' | 'THIS_WEEK' | 'THIS_MONTH' | 'CUSTOM';

export interface SalesReportSummary {
  totalTransactions: number;
  grossRevenue: number;
  totalDiscount: number;
  netRevenue: number;
  totalCash: number;
  totalTransfer: number;
  totalQris: number;
  totalOther: number;
}

export interface StaffProfitReportItem {
  employeeId: number;
  employeeName: string;
  position: string;
  vehicleCount: number;
  serviceCount: number;
  totalServiceSales: number;
  snapshotPercentage: number;
  totalStaffShare: number;
  totalOwnerShare: number;
}

export interface VehicleReportItem {
  vehicle: Vehicle;
  customerName: string;
  customerPhone: string;
  totalVisits: number;
  lastVisitTimestamp: number | null;
  lastServiceName: string;
  totalSpent: number;
}

export interface ServicePopularityItem {
  serviceId: number;
  serviceName: string;
  category: string;
  useCount: number;
  totalRevenue: number;
  uniqueVehiclesCount: number;
  revenueContributionPercentage: number;
}
