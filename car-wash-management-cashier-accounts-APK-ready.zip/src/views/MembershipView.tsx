import React, { useState } from 'react';
import {
  CreditCard,
  Gift,
  Plus,
  Edit,
  Sparkles,
  CheckCircle2,
  Calendar,
  Award,
  Users,
  AlertCircle,
} from 'lucide-react';
import { MembershipPackage, CustomerMembership, PointRule, Customer } from '../types';
import { CarWashStorage } from '../data/storage';
import {
  AddPackageModal,
  PurchaseMembershipModal,
  EditPointRuleModal,
} from '../components/MembershipModals';

interface MembershipViewProps {
  storage: CarWashStorage;
  packages: MembershipPackage[];
  customerMemberships: CustomerMembership[];
  pointRule: PointRule | null;
  customers: Customer[];
}

export const MembershipView: React.FC<MembershipViewProps> = ({
  storage,
  packages,
  customerMemberships,
  pointRule,
  customers,
}) => {
  const [activeTab, setActiveTab] = useState<'packages' | 'active_members' | 'points_rule'>('packages');

  // Modals state
  const [isAddPackageOpen, setIsAddPackageOpen] = useState(false);
  const [purchasingPackage, setPurchasingPackage] = useState<MembershipPackage | null>(null);
  const [isEditRuleOpen, setIsEditRuleOpen] = useState(false);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-base font-extrabold text-slate-900">Program Membership & Poin Loyalitas</h2>
          <p className="text-xs text-slate-500">
            Katalog paket cuci langganan, kuota berkala, dan diskon reward poin otomatis
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'packages' && (
            <button
              onClick={() => setIsAddPackageOpen(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Buat Paket Cuci</span>
            </button>
          )}

          {activeTab === 'points_rule' && (
            <button
              onClick={() => setIsEditRuleOpen(true)}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Edit className="w-4 h-4" />
              <span>Konfigurasi Poin</span>
            </button>
          )}
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center space-x-1.5 bg-white p-2.5 rounded-2xl border border-slate-200/90 shadow-xs overflow-x-auto">
        {[
          { id: 'packages', label: 'Paket Langganan', icon: CreditCard },
          { id: 'active_members', label: `Member Aktif (${customerMemberships.length})`, icon: Users },
          { id: 'points_rule', label: 'Aturan Poin Loyalitas', icon: Gift },
        ].map(item => {
          const Icon = item.icon;
          const isSel = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                isSel ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: PACKAGES */}
      {activeTab === 'packages' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {packages.map(pkg => (
            <div
              key={pkg.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between hover:border-emerald-300 transition-all space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 text-[11px] font-black uppercase tracking-wider border border-emerald-200">
                    Paket {pkg.totalVisits}x Cuci
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    Masa Berlaku: {pkg.validityDays} Hari
                  </span>
                </div>

                <h3 className="font-extrabold text-base text-slate-900">{pkg.name}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {pkg.description || 'Paket hemat cuci mobil berkala dengan garansi kilap.'}
                </p>

                <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 space-y-1 text-xs text-emerald-900">
                  <p>
                    Layanan Pokok: <strong>{pkg.serviceName}</strong>
                  </p>
                  <p>
                    Harga per Datang: ~<strong>Rp {Math.round(pkg.price / pkg.totalVisits).toLocaleString('id-ID')}</strong>
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Harga Paket:</span>
                  <p className="text-lg font-black text-emerald-700">
                    Rp {pkg.price.toLocaleString('id-ID')}
                  </p>
                </div>

                <button
                  onClick={() => setPurchasingPackage(pkg)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
                >
                  Aktifkan ke Member
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: ACTIVE CUSTOMER MEMBERSHIPS */}
      {activeTab === 'active_members' && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Daftar Langganan Member Aktif</h3>
          {customerMemberships.length === 0 ? (
            <p className="text-center text-xs text-slate-400 py-10">Belum ada pelanggan yang membeli paket.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {customerMemberships.map(m => {
                const isExpired = m.expiresAt < Date.now();
                return (
                  <div
                    key={m.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-sm text-slate-900">{m.customerName}</span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isExpired
                              ? 'bg-red-100 text-red-700'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {isExpired ? 'Kedaluwarsa' : 'Aktif'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">{m.packageName}</p>
                      <p className="text-[11px] text-slate-400">
                        Berlaku s/d:{' '}
                        {new Date(m.expiresAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric',
                        })}
                      </p>
                    </div>

                    <div className="text-right sm:self-center">
                      <span className="text-xs text-slate-500 font-medium">Sisa Kuota:</span>
                      <p className="text-xl font-black text-emerald-700">
                        {m.remainingQuota} / {m.totalQuota} <span className="text-xs font-normal text-slate-500">Kunjungan</span>
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: POINT RULES */}
      {activeTab === 'points_rule' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Rule Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-xl bg-amber-100 text-amber-800">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Kalkulasi Program Poin</h3>
                  <p className="text-xs text-slate-500">Reward loyalitas otomatis saat pembayaran kasir</p>
                </div>
              </div>

              <span
                className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                  pointRule?.isEnabled ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                }`}
              >
                {pointRule?.isEnabled ? 'Aktif' : 'Nonaktif'}
              </span>
            </div>

            <div className="space-y-3 pt-2">
              <div className="p-3.5 bg-slate-50 rounded-xl flex items-center justify-between text-xs">
                <span className="text-slate-600">Perolehan Poin:</span>
                <strong className="text-slate-900 font-bold">
                  Tiap Belanja Rp {pointRule?.spendAmountPerPoint.toLocaleString('id-ID')} = {pointRule?.pointsEarned} Poin
                </strong>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl flex items-center justify-between text-xs">
                <span className="text-slate-600">Nilai Tukar Diskon:</span>
                <strong className="text-amber-800 font-black">
                  1 Poin = Potongan Rp {pointRule?.pointRedeemValue.toLocaleString('id-ID')}
                </strong>
              </div>
            </div>

            <button
              onClick={() => setIsEditRuleOpen(true)}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Ubah Parameter Aturan Poin
            </button>
          </div>

          {/* Top Loyalty Customers */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-xl bg-purple-100 text-purple-700">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">Peringkat Pelanggan Terloyal</h3>
                <p className="text-xs text-slate-500">Pelanggan dengan saldo poin dan kunjungan tertinggi</p>
              </div>
            </div>

            <div className="divide-y divide-slate-100">
              {[...customers]
                .sort((a, b) => b.pointsBalance - a.pointsBalance)
                .slice(0, 5)
                .map((c, idx) => (
                  <div key={c.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-2.5">
                      <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-[10px]">
                        {idx + 1}
                      </span>
                      <div>
                        <p className="font-bold text-slate-900">{c.name}</p>
                        <p className="text-[10px] text-slate-400">{c.phone}</p>
                      </div>
                    </div>
                    <span className="font-extrabold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                      {c.pointsBalance} Poin
                    </span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <AddPackageModal
        isOpen={isAddPackageOpen}
        onClose={() => setIsAddPackageOpen(false)}
        onConfirm={data => storage.addMembershipPackage(data)}
      />

      <PurchaseMembershipModal
        isOpen={!!purchasingPackage}
        onClose={() => setPurchasingPackage(null)}
        pkg={purchasingPackage}
        customers={customers}
        onConfirm={(cid, pkg) => storage.purchaseMembership(cid, pkg)}
      />

      <EditPointRuleModal
        isOpen={isEditRuleOpen}
        onClose={() => setIsEditRuleOpen(false)}
        pointRule={pointRule}
        onConfirm={updates => storage.updatePointRule(updates)}
      />
    </div>
  );
};
