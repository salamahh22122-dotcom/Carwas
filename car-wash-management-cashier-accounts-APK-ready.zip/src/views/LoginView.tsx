import React, { useState } from 'react';
import {
  Car,
  Shield,
  Mail,
  Lock,
  ArrowRight,
  AlertCircle,
  Eye,
  EyeOff,
} from 'lucide-react';
import { CarWashStorage } from '../data/storage';
import { User } from '../types';

interface LoginViewProps {
  storage: CarWashStorage;
  onLoginSuccess: (user: User) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ storage, onLoginSuccess }) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Email format validation helper
  const validateEmailFormat = (input: string): boolean => {
    if (!input.includes('@')) return true; // Username allowed
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(input.trim());
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedIdentifier = identifier.trim();
    const trimmedPassword = password.trim();

    // Client-side validations
    if (!trimmedIdentifier) {
      setError('Silakan masukkan alamat email atau username akun Anda.');
      return;
    }

    if (trimmedIdentifier.includes('@') && !validateEmailFormat(trimmedIdentifier)) {
      setError('Format email tidak valid. Pastikan penulisan sesuai standar (contoh: user@domain.com).');
      return;
    }

    if (!trimmedPassword) {
      setError('Silakan masukkan password akun Anda.');
      return;
    }

    setIsLoading(true);

    // Call storage authentication
    setTimeout(() => {
      const result = storage.login(trimmedIdentifier, trimmedPassword);
      setIsLoading(false);

      if (result.success && result.user) {
        onLoginSuccess(result.user);
      } else {
        setError(result.message || 'Login gagal. Silakan periksa kembali email dan password Anda.');
      }
    }, 200);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8 relative overflow-hidden">
      {/* Background Accent Gradients */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-sky-500/10 via-sky-500/5 to-transparent pointer-events-none blur-3xl" />
      <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md sm:max-w-lg space-y-6 relative z-10 my-auto">
        {/* Brand Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/10 border border-white/15 text-white shadow-xl backdrop-blur-md">
            <Car className="w-8 h-8 text-sky-400" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Car Wash Management
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Sistem Operasional Kasir POS, Pipeline Cuci & Tata Kelola Keuangan
            </p>
          </div>
        </div>

        {/* Main Login Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200/80 space-y-6">
          <div className="space-y-1.5 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h2 className="text-lg sm:text-xl font-black text-slate-900">Masuk ke Akun</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-sky-100 text-sky-800 uppercase tracking-wider">
                Portal Resmi
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Gunakan email atau username terdaftar beserta password Anda.
            </p>
          </div>

          {/* Error Notification */}
          {error && (
            <div
              id="login_error_alert"
              role="alert"
              className="p-3.5 rounded-2xl bg-red-50 border border-red-200/90 text-red-700 text-xs font-semibold flex items-start gap-2.5 animate-in fade-in slide-in-from-top-1 duration-200"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <div className="leading-relaxed">{error}</div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            {/* Email / Username Field */}
            <div className="space-y-1.5">
              <label
                htmlFor="login_identifier_input"
                className="block text-xs font-bold text-slate-700"
              >
                Email atau Username <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  id="login_identifier_input"
                  name="identifier"
                  type="text"
                  autoComplete="username"
                  required
                  placeholder="nama@email.com atau username"
                  value={identifier}
                  onChange={e => {
                    setIdentifier(e.target.value);
                    if (error) setError(null);
                  }}
                  className="w-full pl-10 pr-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 hover:bg-slate-50/80 focus:bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-medium transition-all"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="login_password_input"
                  className="block text-xs font-bold text-slate-700"
                >
                  Password <span className="text-red-500">*</span>
                </label>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="login_password_input"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  placeholder="Masukkan password Anda"
                  value={password}
                  onChange={e => {
                    setPassword(e.target.value);
                    if (error) setError(null);
                  }}
                  className="w-full pl-10 pr-11 py-2.5 text-xs sm:text-sm bg-slate-50 hover:bg-slate-50/80 focus:bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-medium transition-all"
                />
                <button
                  type="button"
                  id="toggle_password_visibility_btn"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Sembunyikan password' : 'Lihat password'}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              id="submit_login_btn"
              disabled={isLoading}
              className="w-full py-3 bg-sky-600 hover:bg-sky-700 active:bg-sky-800 disabled:opacity-70 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Masuk Sekarang</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Security Guarantee Note */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-center gap-2 text-xs text-slate-500">
            <Shield className="w-4 h-4 text-sky-600 shrink-0" />
            <span>Sistem Otentikasi Terenkripsi & Terproteksi</span>
          </div>
        </div>

        {/* Footer info */}
        <div className="text-center text-xs text-slate-400 space-y-1">
          <p>© 2026 Car Wash Management System • All Rights Reserved</p>
          <p className="text-[11px] text-slate-400">
            Akses Berjenjang: Master Admin • Owner • Admin • Kasir • Staff
          </p>
        </div>
      </div>
    </div>
  );
};
