import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  DollarSign,
  Car,
  CheckCircle2,
  Clock,
  Sparkles,
  Users,
  Plus,
  ArrowRight,
  Receipt,
  Calendar,
  Star,
  Award,
  ShieldAlert,
  ArrowUpRight,
  Filter,
  Check,
} from 'lucide-react';
import {
  User,
  Business,
  Transaction,
  Employee,
  Service,
  Customer,
  Vehicle,
  VehicleStatusHistory,
  DatePeriodFilter,
  QUEUE_STATUSES,
  VehicleQueueStatus,
} from '../types';
import { CarWashStorage } from '../data/storage';

interface DashboardViewProps {
  storage: CarWashStorage;
  currentUser: User;
  currentBusiness: Business | null;
  transactions: Transaction[];
  employees: Employee[];
  services: Service[];
  customers: Customer[];
  vehicles: Vehicle[];
  queueHistory: VehicleStatusHistory[];
  onNavigateTab: (tab: string) => void;
  onOpenNewTxModal: () => void;
  onOpenReceipt: (tx: Transaction) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  storage,
  currentUser,
  currentBusiness,
  transactions,
  employees,
  services,
  customers,
  vehicles,
  queueHistory,
  onNavigateTab,
  onOpenNewTxModal,
  onOpenReceipt,
}) => {
  const [period, setPeriod] = useState<DatePeriodFilter>('TODAY');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [showCustomPicker, setShowCustomPicker] = useState(false);

  const canViewProfit = storage.canViewFinancials(currentUser.role);
  const canManageStaff = storage.canManageEmployees(currentUser.role);

  // Filtered transactions for selected period
  const filteredTxs = useMemo(() => {
    return storage.filterTransactionsByPeriod(transactions, period, customStart, customEnd);
  }, [storage, transactions, period, customStart, customEnd]);

  // Today & Month transactions
  const todayTxs = useMemo(() => {
    return storage.filterTransactionsByPeriod(transactions, 'TODAY');
  }, [storage, transactions]);

  const monthTxs = useMemo(() => {
    return storage.filterTransactionsByPeriod(transactions, 'THIS_MONTH');
  }, [storage, transactions]);

  // Financial KPIs
  const omzetHariIni = useMemo(() => todayTxs.reduce((sum, t) => sum + t.totalAmount, 0), [todayTxs]);
  const omzetBulanIni = useMemo(() => monthTxs.reduce((sum, t) => sum + t.totalAmount, 0), [monthTxs]);
  const omzetPeriode = useMemo(() => filteredTxs.reduce((sum, t) => sum + t.totalAmount, 0), [filteredTxs]);
  const ownerProfitPeriode = useMemo(() => filteredTxs.reduce((sum, t) => sum + t.ownerShareAmount, 0), [filteredTxs]);
  const staffSharePeriode = useMemo(() => filteredTxs.reduce((sum, t) => sum + t.staffShareAmount, 0), [filteredTxs]);

  // Live Vehicle status counts across all registered vehicles
  const statusCounts = useMemo(() => {
    const counts = {
      WAITING: 0,
      WASHING: 0,
      DRYING: 0,
      FINISHED: 0,
      PICKED_UP: 0,
    };
    for (const v of vehicles) {
      const latest = queueHistory.find(q => q.vehicleId === v.id)?.status || 'WAITING';
      counts[latest] = (counts[latest] || 0) + 1;
    }
    return counts;
  }, [vehicles, queueHistory]);

  const activeInProcess = statusCounts.WAITING + statusCounts.WASHING + statusCounts.DRYING;

  // Popular service and top staff for the selected period
  const popularServices = useMemo(() => {
    return storage.calculateServicePopularityReport(services, filteredTxs);
  }, [storage, services, filteredTxs]);

  const staffReports = useMemo(() => {
    return storage.calculateStaffProfitReport(filteredTxs, employees);
  }, [storage, filteredTxs, employees]);

  const topService = popularServices[0];
  const topStaff = staffReports[0];

  // Visual ratio for staff vs owner profit
  const totalShareSum = ownerProfitPeriode + staffSharePeriode;
  const staffPercentRatio = totalShareSum > 0 ? (staffSharePeriode / totalShareSum) * 100 : 30;

  // Unique vehicles serviced in the selected period
  const uniqueVehiclesInPeriod = useMemo(() => {
    return new Set(filteredTxs.map(t => t.vehicleId)).size;
  }, [filteredTxs]);

  // Active status filter for the queue preview section
  const [selectedStatusLane, setSelectedStatusLane] = useState<'ALL' | 'WAITING' | 'WASHING' | 'FINISHED' | 'PICKED_UP'>('ALL');

  // Vehicles with their latest status and active transaction
  const vehiclesWithStatus = useMemo(() => {
    return vehicles.map(v => {
      const latestStatus = queueHistory.find(q => q.vehicleId === v.id)?.status || 'WAITING';
      const activeTx = transactions.find(t => t.vehicleId === v.id && t.queueStatus !== 'PICKED_UP')
        || transactions.find(t => t.vehicleId === v.id);
      const cust = customers.find(c => c.id === v.customerId);
      return {
        vehicle: v,
        status: latestStatus,
        activeTx,
        customer: cust,
      };
    });
  }, [vehicles, queueHistory, transactions, customers]);

  const handleAdvanceStatus = (vehicleId: number, currentStatus: VehicleQueueStatus, txId?: number) => {
    const next = storage.getNextQueueStatus(currentStatus);
    if (next) {
      storage.updateVehicleQueueStatus(vehicleId, next, txId);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Executive Header Banner */}
      <div className="rounded-2xl bg-slate-900 text-white p-6 sm:p-7 border border-slate-800 shadow-sm relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-800 text-sky-400 text-xs font-bold border border-slate-700/60">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sistem Kasir & Alur Operasional Cuci</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              {currentBusiness?.name || 'CleanAuto Car Wash'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              {currentBusiness?.address} • Telp: {currentBusiness?.phone}
            </p>
          </div>

          {/* Header Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            {currentUser.role !== 'STAFF' && (
              <button
                type="button"
                id="dashboard_open_pos_btn"
                onClick={onOpenNewTxModal}
                className="px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-xs shadow-xs transition-all flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Kasir POS Baru</span>
              </button>
            )}
            <button
              type="button"
              id="dashboard_open_queue_btn"
              onClick={() => onNavigateTab('antrian')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Car className="w-4 h-4 text-sky-400" />
              <span>
                Antrian Aktif: <strong className="text-sky-300 font-extrabold ml-0.5">{activeInProcess} Unit</strong>
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Analytics Time Period Bar */}
      <div className="bg-white p-3 sm:p-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-sky-600" />
          <span className="text-xs font-bold text-slate-800">Periode Data:</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'TODAY', label: 'Hari Ini' },
            { id: 'YESTERDAY', label: 'Kemarin' },
            { id: 'THIS_WEEK', label: 'Minggu Ini' },
            { id: 'THIS_MONTH', label: 'Bulan Ini' },
            { id: 'CUSTOM', label: 'Kustom' },
          ].map(item => {
            const isSel = period === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setPeriod(item.id as DatePeriodFilter);
                  if (item.id === 'CUSTOM') setShowCustomPicker(true);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isSel
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom Date Range Picker */}
      {showCustomPicker && period === 'CUSTOM' && (
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl flex flex-wrap items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Tanggal Mulai:</span>
            <input
              type="date"
              value={customStart}
              onChange={e => setCustomStart(e.target.value)}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-sky-500"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Tanggal Selesai:</span>
            <input
              type="date"
              value={customEnd}
              onChange={e => setCustomEnd(e.target.value)}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-sky-500"
            />
          </div>
          <button
            onClick={() => setShowCustomPicker(false)}
            className="px-4 py-1.5 bg-slate-900 text-white font-bold rounded-xl cursor-pointer hover:bg-slate-800"
          >
            Terapkan Filter
          </button>
        </div>
      )}

      {/* Primary KPI Metric Cards (Real Data Filtered by Period) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* 1. Omzet Periode */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Omzet Periode</span>
            <div className="p-2 rounded-xl bg-sky-50 text-sky-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-sky-900 tracking-tight">
            Rp {omzetPeriode.toLocaleString('id-ID')}
          </p>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{filteredTxs.length} transaksi pada periode ini</span>
          </div>
        </div>

        {/* 2. Jumlah Transaksi */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Jumlah Transaksi</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 tracking-tight">
            {filteredTxs.length} <span className="text-xs font-bold text-slate-500">Transaksi</span>
          </p>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>Filter: {period === 'TODAY' ? 'Hari Ini' : period === 'THIS_WEEK' ? 'Minggu Ini' : period === 'THIS_MONTH' ? 'Bulan Ini' : period === 'YESTERDAY' ? 'Kemarin' : 'Kustom'}</span>
          </div>
        </div>

        {/* 3. Jumlah Kendaraan */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Jumlah Kendaraan</span>
            <div className="p-2 rounded-xl bg-slate-100 text-slate-700">
              <Car className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 tracking-tight">
            {uniqueVehiclesInPeriod} <span className="text-xs font-bold text-slate-500">Unit Terlayani</span>
          </p>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Users className="w-3.5 h-3.5 text-slate-400" />
            <span>Total terdaftar: {vehicles.length} kendaraan</span>
          </div>
        </div>

        {/* 4. Total Bagi Hasil Staff (Owner/Master only) */}
        {canViewProfit ? (
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-700">Total Bagi Hasil Staff</span>
              <div className="p-2 rounded-xl bg-purple-50 text-purple-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-purple-700 tracking-tight">
              Rp {staffSharePeriode.toLocaleString('id-ID')}
            </p>
            <div className="flex items-center gap-1.5 text-xs text-purple-600 font-semibold">
              <Award className="w-3.5 h-3.5 text-purple-500" />
              <span>Komisi staf periode terpilih</span>
            </div>
          </div>
        ) : (
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Pelanggan Aktif</span>
              <div className="p-2 rounded-xl bg-sky-50 text-sky-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 tracking-tight">{customers.length} Orang</p>
            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
              <span>Database pelanggan car wash</span>
            </div>
          </div>
        )}

        {/* 5. Bagian Owner (Owner/Master only) */}
        {canViewProfit ? (
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">Bagian Owner</span>
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-emerald-700 tracking-tight">
              Rp {ownerProfitPeriode.toLocaleString('id-ID')}
            </p>
            <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-semibold">
              <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
              <span>Hak bersih pemilik usaha</span>
            </div>
          </div>
        ) : (
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-2">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Layanan Tersedia</span>
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                <Sparkles className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 tracking-tight">{services.length} Menu</p>
            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
              <span>Menu cuci aktif</span>
            </div>
          </div>
        )}
      </div>

      {/* 4 Status Pengerjaan Kendaraan (Menunggu, Sedang Dicuci, Selesai Dicuci, Sudah Dijemput) */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Alur Status Pengerjaan Kendaraan (Real-Time)</h3>
            <p className="text-xs text-slate-500">Pantau pergerakan fisik mobil: Menunggu, Sedang dicuci, Selesai dicuci, hingga Sudah dijemput</p>
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('antrian')}
            className="text-xs font-bold text-sky-700 hover:text-sky-800 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
          >
            <span>Buka Manajemen Antrian Lengkap</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Menunggu */}
          <div
            onClick={() => setSelectedStatusLane(selectedStatusLane === 'WAITING' ? 'ALL' : 'WAITING')}
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              selectedStatusLane === 'WAITING' ? 'ring-2 ring-orange-500 shadow-sm' : 'hover:shadow-xs'
            } bg-orange-50/70 border-orange-200`}
          >
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black text-orange-700">
                {statusCounts.WAITING}
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
            </div>
            <p className="text-xs font-bold mt-1 text-slate-900">Menunggu</p>
            <p className="text-[11px] text-orange-700/80 font-medium">Antrian di bay masuk</p>
          </div>

          {/* Sedang dicuci */}
          <div
            onClick={() => setSelectedStatusLane(selectedStatusLane === 'WASHING' ? 'ALL' : 'WASHING')}
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              selectedStatusLane === 'WASHING' ? 'ring-2 ring-sky-500 shadow-sm' : 'hover:shadow-xs'
            } bg-sky-50/70 border-sky-200`}
          >
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black text-sky-700">
                {statusCounts.WASHING + statusCounts.DRYING}
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
            </div>
            <p className="text-xs font-bold mt-1 text-slate-900">Sedang Dicuci</p>
            <p className="text-[11px] text-sky-700/80 font-medium">Cuci salju & pengeringan</p>
          </div>

          {/* Selesai dicuci */}
          <div
            onClick={() => setSelectedStatusLane(selectedStatusLane === 'FINISHED' ? 'ALL' : 'FINISHED')}
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              selectedStatusLane === 'FINISHED' ? 'ring-2 ring-emerald-500 shadow-sm' : 'hover:shadow-xs'
            } bg-emerald-50/70 border-emerald-200`}
          >
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black text-emerald-700">
                {statusCounts.FINISHED}
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            </div>
            <p className="text-xs font-bold mt-1 text-slate-900">Selesai Dicuci</p>
            <p className="text-[11px] text-emerald-700/80 font-medium">Bersih, menunggu diambil</p>
          </div>

          {/* Sudah dijemput */}
          <div
            onClick={() => setSelectedStatusLane(selectedStatusLane === 'PICKED_UP' ? 'ALL' : 'PICKED_UP')}
            className={`p-4 rounded-xl border transition-all cursor-pointer ${
              selectedStatusLane === 'PICKED_UP' ? 'ring-2 ring-slate-500 shadow-sm' : 'hover:shadow-xs'
            } bg-slate-100/70 border-slate-200`}
          >
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black text-slate-700">
                {statusCounts.PICKED_UP}
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500" />
            </div>
            <p className="text-xs font-bold mt-1 text-slate-900">Sudah Dijemput</p>
            <p className="text-[11px] text-slate-600 font-medium">Kendaraan telah keluar</p>
          </div>
        </div>

        {/* Interactive Live Vehicles in Selected Status */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-700">
              {selectedStatusLane === 'ALL'
                ? 'Daftar Kendaraan Aktif di Lokasi Cuci:'
                : `Kendaraan Berstatus: ${
                    selectedStatusLane === 'WAITING'
                      ? 'Menunggu'
                      : selectedStatusLane === 'WASHING'
                      ? 'Sedang Dicuci'
                      : selectedStatusLane === 'FINISHED'
                      ? 'Selesai Dicuci'
                      : 'Sudah Dijemput'
                  }`}
            </span>
            {selectedStatusLane !== 'ALL' && (
              <button
                type="button"
                onClick={() => setSelectedStatusLane('ALL')}
                className="text-[11px] font-semibold text-sky-700 hover:underline cursor-pointer"
              >
                Tampilkan Semua Status
              </button>
            )}
          </div>

          {vehiclesWithStatus.filter(item => {
            if (selectedStatusLane === 'ALL') return item.status !== 'PICKED_UP';
            if (selectedStatusLane === 'WASHING') return item.status === 'WASHING' || item.status === 'DRYING';
            return item.status === selectedStatusLane;
          }).length === 0 ? (
            <p className="text-xs text-slate-400 py-3 text-center italic bg-slate-50 rounded-xl">
              Tidak ada kendaraan pada status ini saat ini.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {vehiclesWithStatus
                .filter(item => {
                  if (selectedStatusLane === 'ALL') return item.status !== 'PICKED_UP';
                  if (selectedStatusLane === 'WASHING') return item.status === 'WASHING' || item.status === 'DRYING';
                  return item.status === selectedStatusLane;
                })
                .slice(0, 6)
                .map(item => {
                  const qStatusInfo = QUEUE_STATUSES[item.status];
                  const nextStatus = storage.getNextQueueStatus(item.status);
                  return (
                    <div
                      key={item.vehicle.id}
                      className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex flex-col justify-between gap-3 transition-colors"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-black text-xs tracking-wider bg-slate-900 text-white px-2.5 py-1 rounded-md">
                            {item.vehicle.licensePlate}
                          </span>
                          <span
                            className="px-2 py-0.5 rounded-md text-[10px] font-bold"
                            style={{ backgroundColor: qStatusInfo?.bg, color: qStatusInfo?.color }}
                          >
                            {item.status === 'WAITING'
                              ? 'Menunggu'
                              : item.status === 'WASHING' || item.status === 'DRYING'
                              ? 'Sedang Dicuci'
                              : item.status === 'FINISHED'
                              ? 'Selesai Dicuci'
                              : 'Sudah Dijemput'}
                          </span>
                        </div>

                        <p className="text-xs font-bold text-slate-800 mt-2">
                          {item.vehicle.brandModel} • <span className="text-slate-500 font-normal">{item.customer?.name || 'Pelanggan Umum'}</span>
                        </p>
                        {item.activeTx && (
                          <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                            Layanan: {item.activeTx.serviceName} • Staf: {item.activeTx.assignedStaffNames}
                          </p>
                        )}
                      </div>

                      {nextStatus && (
                        <button
                          type="button"
                          onClick={() => handleAdvanceStatus(item.vehicle.id, item.status, item.activeTx?.id)}
                          className="w-full py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <span>Lanjut ke: {
                            nextStatus === 'WASHING'
                              ? 'Sedang Dicuci'
                              : nextStatus === 'DRYING'
                              ? 'Pengeringan'
                              : nextStatus === 'FINISHED'
                              ? 'Selesai Dicuci'
                              : 'Sudah Dijemput'
                          }</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      </div>

      {/* Confidential Profit Breakdown Card (Owner & Master ONLY) */}
      {canViewProfit && omzetPeriode > 0 && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-purple-700" />
              <h3 className="text-sm font-bold text-slate-900">
                Alokasi Bagi Hasil (Bagi Hasil Staf vs Owner)
              </h3>
            </div>
            <span className="text-xs font-extrabold text-slate-800 bg-slate-100 px-2.5 py-1 rounded-lg">
              Total Omzet: Rp {omzetPeriode.toLocaleString('id-ID')}
            </span>
          </div>

          {/* Visual Percentage Distribution Bar */}
          <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden flex">
            <div
              className="h-full bg-emerald-600 transition-all"
              style={{ width: `${100 - staffPercentRatio}%` }}
              title={`Hak Owner (${(100 - staffPercentRatio).toFixed(1)}%)`}
            />
            <div
              className="h-full bg-purple-600 transition-all"
              style={{ width: `${staffPercentRatio}%` }}
              title={`Komisi Staff (${staffPercentRatio.toFixed(1)}%)`}
            />
          </div>

          <div className="flex flex-wrap items-center justify-between text-xs pt-1 gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
              <span className="text-slate-600 font-semibold">Hak Bersih Owner:</span>
              <strong className="text-emerald-700 font-extrabold">
                Rp {ownerProfitPeriode.toLocaleString('id-ID')} ({ (100 - staffPercentRatio).toFixed(1) }%)
              </strong>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-600" />
              <span className="text-slate-600 font-semibold">Total Komisi Staf:</span>
              <strong className="text-purple-700 font-extrabold">
                Rp {staffSharePeriode.toLocaleString('id-ID')} ({ staffPercentRatio.toFixed(1) }%)
              </strong>
            </div>
          </div>
        </div>
      )}

      {/* Top Selling Service & Most Productive Staff */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Top Service */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-amber-500 font-bold text-xs">
            <Star className="w-4 h-4 fill-amber-500" />
            <span className="text-slate-900 font-bold text-sm">Layanan Paling Diminati</span>
          </div>
          {topService ? (
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-100">
              <div>
                <p className="font-bold text-slate-900 text-sm">{topService.serviceName}</p>
                <p className="text-xs text-slate-500">{topService.category}</p>
              </div>
              <div className="text-right">
                <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-800 font-bold text-xs">
                  {topService.useCount}x Dipesan
                </span>
                <p className="text-xs font-bold text-slate-700 mt-1">
                  Rp {topService.totalRevenue.toLocaleString('id-ID')}
                </p>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-3">Belum ada data pesanan pada periode ini.</p>
          )}
        </div>

        {/* Top Staff */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-purple-600 font-bold text-xs">
            <Users className="w-4 h-4" />
            <span className="text-slate-900 font-bold text-sm">Staff Paling Produktif</span>
          </div>
          {topStaff && topStaff.serviceCount > 0 ? (
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-100">
              <div>
                <p className="font-bold text-slate-900 text-sm">{topStaff.employeeName}</p>
                <p className="text-xs text-slate-500">{topStaff.position}</p>
              </div>
              <div className="text-right">
                <span className="px-2.5 py-1 rounded-lg bg-purple-100 text-purple-800 font-bold text-xs">
                  {topStaff.serviceCount} Layanan
                </span>
                {canViewProfit && (
                  <p className="text-xs font-bold text-purple-700 mt-1">
                    Komisi: Rp {topStaff.totalStaffShare.toLocaleString('id-ID')}
                  </p>
                )}
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-3">Belum ada pengerjaan staff pada periode ini.</p>
          )}
        </div>
      </div>

      {/* Quick Action Hub */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-900">Pusat Navigasi Pintar</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={onOpenNewTxModal}
            className="p-4 rounded-xl bg-white border border-slate-200/90 hover:border-sky-500 hover:bg-sky-50/40 transition-all flex flex-col items-center justify-center gap-2 shadow-xs cursor-pointer group"
          >
            <div className="p-2 rounded-xl bg-sky-100 text-sky-700 group-hover:scale-105 transition-transform">
              <Receipt className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-800">Kasir POS Baru</span>
          </button>

          {canManageStaff && (
            <button
              onClick={() => onNavigateTab('karyawan')}
              className="p-4 rounded-xl bg-white border border-slate-200/90 hover:border-purple-500 hover:bg-purple-50/40 transition-all flex flex-col items-center justify-center gap-2 shadow-xs cursor-pointer group"
            >
              <div className="p-2 rounded-xl bg-purple-100 text-purple-700 group-hover:scale-105 transition-transform">
                <Users className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-slate-800">Staf & Komisi</span>
            </button>
          )}

          <button
            onClick={() => onNavigateTab('layanan')}
            className="p-4 rounded-xl bg-white border border-slate-200/90 hover:border-emerald-500 hover:bg-emerald-50/40 transition-all flex flex-col items-center justify-center gap-2 shadow-xs cursor-pointer group"
          >
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-800">Katalog Layanan</span>
          </button>

          <button
            onClick={() => onNavigateTab('pelanggan')}
            className="p-4 rounded-xl bg-white border border-slate-200/90 hover:border-cyan-500 hover:bg-cyan-50/40 transition-all flex flex-col items-center justify-center gap-2 shadow-xs cursor-pointer group"
          >
            <div className="p-2 rounded-xl bg-cyan-100 text-cyan-700 group-hover:scale-105 transition-transform">
              <Car className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-slate-800">Pelanggan & Nopol</span>
          </button>
        </div>
      </div>

      {/* Recent Transactions Preview */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Transaksi Kasir Terkini</h3>
            <p className="text-xs text-slate-500">Daftar transaksi kasir yang selesai diproses</p>
          </div>
          <button
            onClick={() => onNavigateTab('pos')}
            className="text-xs font-bold text-sky-700 hover:text-sky-800 flex items-center gap-1 cursor-pointer"
          >
            <span>Buka Kasir Lengkap</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {transactions.length === 0 ? (
          <p className="text-center text-xs text-slate-400 py-6">Belum ada transaksi.</p>
        ) : (
          <div className="divide-y divide-slate-100">
            {transactions.slice(0, 5).map(tx => {
              const customer = customers.find(c => c.id === tx.customerId);
              const vehicle = vehicles.find(v => v.id === tx.vehicleId);
              return (
                <div
                  key={tx.id}
                  onClick={() => onOpenReceipt(tx)}
                  className="py-3 flex items-center justify-between hover:bg-slate-50 px-2 rounded-xl transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center font-bold text-xs border border-sky-100">
                      #{tx.queueNumber}
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-xs text-slate-900">{tx.invoiceNo}</span>
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 uppercase">
                          {tx.paymentMethod}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">
                        <strong className="text-slate-800">{vehicle?.licensePlate || '-'}</strong> • {tx.serviceName}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {customer?.name || 'Pelanggan'} • Staf: {tx.assignedStaffNames || '-'}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-black text-xs text-slate-900">
                      Rp {tx.totalAmount.toLocaleString('id-ID')}
                    </span>
                    {canViewProfit && (
                      <p className="text-[10px] text-emerald-700 font-bold mt-0.5">
                        Owner: Rp {tx.ownerShareAmount.toLocaleString('id-ID')}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
