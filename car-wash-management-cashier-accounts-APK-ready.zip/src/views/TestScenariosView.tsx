import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Play,
  RotateCcw,
  ShieldCheck,
  Percent,
  Receipt,
  Eye,
  EyeOff,
  BarChart3,
  Users,
  Award,
} from 'lucide-react';
import { User, Employee, Transaction } from '../types';
import { CarWashStorage } from '../data/storage';

interface TestScenariosViewProps {
  storage: CarWashStorage;
  currentUser: User;
  employees: Employee[];
  transactions: Transaction[];
  onSwitchUser: (userId: number) => void;
}

interface TestResult {
  id: string;
  name: string;
  description: string;
  status: 'PENDING' | 'RUNNING' | 'PASSED' | 'FAILED';
  details: string[];
  actualData?: any;
}

export const TestScenariosView: React.FC<TestScenariosViewProps> = ({
  storage,
  currentUser,
  employees,
  transactions,
  onSwitchUser,
}) => {
  const [testResults, setTestResults] = useState<Record<string, TestResult>>({
    scenario_1: {
      id: 'scenario_1',
      name: '1. Transaksi dengan Bagi Hasil Staff',
      description: 'Membuat transaksi baru Rp100.000 dengan Staff komisi 30%. Memverifikasi Staff dapat Rp30.000 dan Owner Rp70.000 tersimpan di snapshot.',
      status: 'PENDING',
      details: [],
    },
    scenario_2: {
      id: 'scenario_2',
      name: '2. Immutability Persentase Bagi Hasil (Snapshot Historis)',
      description: 'Mengubah persentase Staff (misal jadi 45%). Memverifikasi transaksi lama tetap memakai persentase awal (30%) dan transaksi baru memakai persentase baru (45%).',
      status: 'PENDING',
      details: [],
    },
    scenario_3: {
      id: 'scenario_3',
      name: '3. Proteksi Akses Role Kasir (Confidentiality)',
      description: 'Memverifikasi hak akses role KASIR: tidak boleh melihat persentase komisi staff, tidak boleh melihat nominal komisi staff, dan tidak boleh mengakses laporan keuangan.',
      status: 'PENDING',
      details: [],
    },
    scenario_4: {
      id: 'scenario_4',
      name: '4. Akses Penuh Role Owner (All Reports & KPIs)',
      description: 'Memverifikasi hak akses role OWNER: dapat melihat seluruh 9 KPI dashboard, omzet, pembagian hasil, dan seluruh 7 laporan bisnis.',
      status: 'PENDING',
      details: [],
    },
    scenario_5: {
      id: 'scenario_5',
      name: '5. Otentikasi & Akun Master Tunggal Permanen (mdqputra@gmail.com)',
      description: 'Memverifikasi sistem hanya memiliki 1 akun Master (mdqputra@gmail.com), validasi email & password, proteksi password aman, dan redirection ke Dashboard Master.',
      status: 'PENDING',
      details: [],
    },
  });

  const [isRunningAll, setIsRunningAll] = useState(false);

  // 1. RUN SCENARIO 1: Transaksi dengan bagi hasil
  const runScenario1 = () => {
    const details: string[] = [];
    try {
      const activeStaff = employees.find(e => e.status === 'ACTIVE') || employees[0];
      if (!activeStaff) throw new Error('Tidak ada staf aktif untuk test.');

      // Temporarily set staff percentage to 30% for test
      const testPercentage = 30;
      storage.updateEmployeeProfitPercentage(activeStaff.id, testPercentage);
      details.push(`[Setup] Set komisi ${activeStaff.name} = ${testPercentage}%`);

      const initialTxCount = storage.transactions.length;
      const testTxPrice = 100000;

      const res = storage.createTransaction({
        customerId: storage.customers[0]?.id || 1,
        vehicleId: storage.vehicles[0]?.id || 1,
        serviceId: storage.services[0]?.id || 1,
        additionalOptionIds: [],
        assignedStaffIds: [activeStaff.id],
        paymentMethod: 'TUNAI',
        cashAmount: 100000,
        redeemPoints: 0,
        useMembershipQuota: false,
      });

      if (!res.success || !res.transaction) {
        throw new Error(`Gagal membuat transaksi: ${res.message}`);
      }

      const tx = res.transaction;
      const expectedStaffShare = Math.round((testTxPrice * testPercentage) / 100);
      const expectedOwnerShare = testTxPrice - expectedStaffShare;

      details.push(`[Eksekusi] Transaksi dibuat: ${tx.invoiceNo} (Nilai: Rp${tx.totalAmount.toLocaleString('id-ID')})`);
      details.push(`[Verifikasi] Hak Komisi Staff: Rp${tx.staffShareAmount.toLocaleString('id-ID')} (Ekspektasi: Rp${expectedStaffShare.toLocaleString('id-ID')})`);
      details.push(`[Verifikasi] Hak Bersih Owner: Rp${tx.ownerShareAmount.toLocaleString('id-ID')} (Ekspektasi: Rp${expectedOwnerShare.toLocaleString('id-ID')})`);

      // Verify TransactionStaff snapshot record
      const allTs = storage.getTransactionStaffRecords();
      const tsRecord = allTs.find(ts => ts.transactionId === tx.id && ts.employeeId === activeStaff.id);

      if (!tsRecord) {
        throw new Error('Record TransactionStaff snapshot tidak ditemukan di storage!');
      }

      details.push(`[Snapshot] Tersimpan di TransactionStaff: snapshot % = ${tsRecord.profitPercentage}%, nominal = Rp${tsRecord.profitAmount}`);

      const passed =
        tx.staffShareAmount === expectedStaffShare &&
        tx.ownerShareAmount === expectedOwnerShare &&
        tsRecord.profitPercentage === testPercentage;

      setTestResults(prev => ({
        ...prev,
        scenario_1: {
          ...prev.scenario_1,
          status: passed ? 'PASSED' : 'FAILED',
          details,
          actualData: { tx, tsRecord },
        },
      }));
    } catch (err: any) {
      details.push(`[ERROR] ${err.message}`);
      setTestResults(prev => ({
        ...prev,
        scenario_1: {
          ...prev.scenario_1,
          status: 'FAILED',
          details,
        },
      }));
    }
  };

  // 2. RUN SCENARIO 2: Ubah persentase Staff, cek transaksi lama tidak berubah
  const runScenario2 = () => {
    const details: string[] = [];
    try {
      const activeStaff = employees.find(e => e.status === 'ACTIVE') || employees[0];
      if (!activeStaff) throw new Error('Tidak ada staf aktif.');

      // Step A: Create TX 1 with 30%
      storage.updateEmployeeProfitPercentage(activeStaff.id, 30);
      const res1 = storage.createTransaction({
        customerId: storage.customers[0]?.id || 1,
        vehicleId: storage.vehicles[0]?.id || 1,
        serviceId: storage.services[0]?.id || 1,
        additionalOptionIds: [],
        assignedStaffIds: [activeStaff.id],
        paymentMethod: 'TUNAI',
        cashAmount: 100000,
        redeemPoints: 0,
        useMembershipQuota: false,
      });
      if (!res1.transaction) throw new Error('Gagal membuat transaksi 1');
      const tx1 = res1.transaction;
      details.push(`[Langkah 1] Buat Transaksi Lama (${tx1.invoiceNo}) dengan komisi 30% -> Hak Staff: Rp${tx1.staffShareAmount.toLocaleString('id-ID')}`);

      // Step B: Change employee percentage to 50%
      storage.updateEmployeeProfitPercentage(activeStaff.id, 50);
      details.push(`[Langkah 2] Update skema Staff ${activeStaff.name} menjadi 50%`);

      // Step C: Check old transaction
      const oldTxInStorage = storage.transactions.find(t => t.id === tx1.id);
      const allTs = storage.getTransactionStaffRecords();
      const oldTs = allTs.find(ts => ts.transactionId === tx1.id && ts.employeeId === activeStaff.id);

      details.push(`[Langkah 3] Cek Transaksi Lama setelah update: Hak Staff tetap Rp${oldTxInStorage?.staffShareAmount.toLocaleString('id-ID')}, Snapshot tetap ${oldTs?.profitPercentage}%`);

      // Step D: Create TX 2 with new 50%
      const res2 = storage.createTransaction({
        customerId: storage.customers[0]?.id || 1,
        vehicleId: storage.vehicles[0]?.id || 1,
        serviceId: storage.services[0]?.id || 1,
        additionalOptionIds: [],
        assignedStaffIds: [activeStaff.id],
        paymentMethod: 'TUNAI',
        cashAmount: 100000,
        redeemPoints: 0,
        useMembershipQuota: false,
      });
      if (!res2.transaction) throw new Error('Gagal membuat transaksi 2');
      const tx2 = res2.transaction;
      const newTs = allTs.find(ts => ts.transactionId === tx2.id && ts.employeeId === activeStaff.id);

      details.push(`[Langkah 4] Buat Transaksi Baru (${tx2.invoiceNo}) -> Hak Staff: Rp${tx2.staffShareAmount.toLocaleString('id-ID')}, Snapshot: ${newTs?.profitPercentage}%`);

      const passed =
        oldTxInStorage?.staffShareAmount === 30000 &&
        oldTs?.profitPercentage === 30 &&
        tx2.staffShareAmount === 50000 &&
        newTs?.profitPercentage === 50;

      setTestResults(prev => ({
        ...prev,
        scenario_2: {
          ...prev.scenario_2,
          status: passed ? 'PASSED' : 'FAILED',
          details,
          actualData: { oldTxStaffShare: oldTxInStorage?.staffShareAmount, newTxStaffShare: tx2.staffShareAmount },
        },
      }));
    } catch (err: any) {
      details.push(`[ERROR] ${err.message}`);
      setTestResults(prev => ({
        ...prev,
        scenario_2: {
          ...prev.scenario_2,
          status: 'FAILED',
          details,
        },
      }));
    }
  };

  // 3. RUN SCENARIO 3: Cek role Kasir tidak bisa melihat bagi hasil
  const runScenario3 = () => {
    const details: string[] = [];
    try {
      const kasirCanViewFinancials = storage.canViewFinancials('KASIR');
      const kasirCanManageProfit = storage.canManageProfitShare('KASIR');
      const adminCanViewFinancials = storage.canViewFinancials('ADMIN');
      const staffCanViewFinancials = storage.canViewFinancials('STAFF');

      details.push(`[RBAC Check] storage.canViewFinancials('KASIR') = ${kasirCanViewFinancials} (Ekspektasi: false)`);
      details.push(`[RBAC Check] storage.canManageProfitShare('KASIR') = ${kasirCanManageProfit} (Ekspektasi: false)`);
      details.push(`[RBAC Check] storage.canViewFinancials('ADMIN') = ${adminCanViewFinancials} (Ekspektasi: false)`);
      details.push(`[RBAC Check] storage.canViewFinancials('STAFF') = ${staffCanViewFinancials} (Ekspektasi: false)`);

      // Find kasir user
      const kasirUser = storage.users.find(u => u.role === 'KASIR');
      details.push(`[User Audit] Akun Kasir terverifikasi: ${kasirUser?.fullName || 'Kasir'} (@${kasirUser?.username})`);

      const passed =
        !kasirCanViewFinancials &&
        !kasirCanManageProfit &&
        !adminCanViewFinancials &&
        !staffCanViewFinancials;

      setTestResults(prev => ({
        ...prev,
        scenario_3: {
          ...prev.scenario_3,
          status: passed ? 'PASSED' : 'FAILED',
          details,
        },
      }));
    } catch (err: any) {
      details.push(`[ERROR] ${err.message}`);
      setTestResults(prev => ({
        ...prev,
        scenario_3: {
          ...prev.scenario_3,
          status: 'FAILED',
          details,
        },
      }));
    }
  };

  // 4. RUN SCENARIO 4: Cek role Owner bisa melihat semua laporan
  const runScenario4 = () => {
    const details: string[] = [];
    try {
      const ownerCanViewFinancials = storage.canViewFinancials('OWNER');
      const masterCanViewFinancials = storage.canViewFinancials('MASTER');
      const ownerCanManageProfit = storage.canManageProfitShare('OWNER');

      details.push(`[RBAC Check] storage.canViewFinancials('OWNER') = ${ownerCanViewFinancials} (Ekspektasi: true)`);
      details.push(`[RBAC Check] storage.canViewFinancials('MASTER') = ${masterCanViewFinancials} (Ekspektasi: true)`);
      details.push(`[RBAC Check] storage.canManageProfitShare('OWNER') = ${ownerCanManageProfit} (Ekspektasi: true)`);

      // Calculate sample reports
      const staffReports = storage.calculateStaffProfitReport(storage.transactions, storage.employees);
      const serviceReports = storage.calculateServicePopularityReport(storage.services, storage.transactions);
      const vehicleReports = storage.calculateVehicleReport(storage.vehicles, storage.customers, storage.transactions);

      details.push(`[Kalkulasi Laporan] Laporan Staff: ${staffReports.length} data staf dihitung`);
      details.push(`[Kalkulasi Laporan] Laporan Layanan: ${serviceReports.length} menu layanan`);
      details.push(`[Kalkulasi Laporan] Laporan Kendaraan: ${vehicleReports.length} kendaraan pelanggan`);

      const passed =
        ownerCanViewFinancials &&
        masterCanViewFinancials &&
        ownerCanManageProfit &&
        staffReports.length > 0;

      setTestResults(prev => ({
        ...prev,
        scenario_4: {
          ...prev.scenario_4,
          status: passed ? 'PASSED' : 'FAILED',
          details,
        },
      }));
    } catch (err: any) {
      details.push(`[ERROR] ${err.message}`);
      setTestResults(prev => ({
        ...prev,
        scenario_4: {
          ...prev.scenario_4,
          status: 'FAILED',
          details,
        },
      }));
    }
  };

  // 5. RUN SCENARIO 5: Otentikasi & Akun Master Tunggal Permanen
  const runScenario5 = () => {
    const details: string[] = [];
    try {
      details.push('[Test 5.1] Memverifikasi hanya ada 1 akun role MASTER di sistem...');
      const masterUsers = storage.users.filter(u => u.role === 'MASTER');
      if (masterUsers.length !== 1) {
        throw new Error(`Ditemukan ${masterUsers.length} akun Master. Sistem harus HANYA memiliki 1 akun Master!`);
      }
      details.push(`[Verifikasi] Terverifikasi tepat 1 akun Master (ID: ${masterUsers[0].id}, Username: "${masterUsers[0].username}").`);

      details.push('[Test 5.2] Memverifikasi Email Akun Master permanen...');
      const master = masterUsers[0];
      if (master.email?.toLowerCase() !== 'mdqputra@gmail.com') {
        throw new Error(`Email Master salah: "${master.email}". Seharusnya "mdqputra@gmail.com"`);
      }
      details.push(`[Verifikasi] Email Master sesuai: ${master.email}`);

      details.push('[Test 5.3] Memverifikasi login Master dengan email dan password benar...');
      const loginSuccess = storage.login('mdqputra@gmail.com', '990830Ok');
      if (!loginSuccess.success || !loginSuccess.user || loginSuccess.user.role !== 'MASTER') {
        throw new Error(`Login Master gagal: ${loginSuccess.message}`);
      }
      details.push(`[Verifikasi] Login Master berhasil: "${loginSuccess.message}" (Role: ${loginSuccess.user.role})`);

      details.push('[Test 5.4] Memverifikasi proteksi password salah pada akun Master...');
      const loginWrongPass = storage.login('mdqputra@gmail.com', 'PasswordSalah123');
      if (loginWrongPass.success) {
        throw new Error('Sistem mengizinkan login dengan password salah!');
      }
      details.push(`[Verifikasi] Proteksi password aktif: Ditolak dengan pesan "${loginWrongPass.message}"`);

      details.push('[Test 5.5] Memverifikasi validasi format email invalid...');
      const loginBadEmail = storage.login('format-salah@', '990830Ok');
      if (loginBadEmail.success) {
        throw new Error('Sistem mengizinkan login dengan format email tidak valid!');
      }
      details.push(`[Verifikasi] Validasi format email bekerja: "${loginBadEmail.message}"`);

      details.push('[Test 5.6] Memverifikasi user non-aktif / email tidak terdaftar...');
      const loginUnknown = storage.login('tidak_ada@cleanauto.com', 'password123');
      if (loginUnknown.success) {
        throw new Error('Sistem mengizinkan login akun yang tidak terdaftar!');
      }
      details.push(`[Verifikasi] Validasi akun tidak terdaftar bekerja: "${loginUnknown.message}"`);

      details.push('[Snapshot] SEMUA 6 UJI ATURAN MASTER & LOGIN VALID DAN SESUAI KETENTUAN!');
      setTestResults(prev => ({
        ...prev,
        scenario_5: {
          ...prev.scenario_5,
          status: 'PASSED',
          details,
        },
      }));
    } catch (err: any) {
      details.push(`[ERROR] ${err.message}`);
      setTestResults(prev => ({
        ...prev,
        scenario_5: {
          ...prev.scenario_5,
          status: 'FAILED',
          details,
        },
      }));
    }
  };

  // RUN ALL TESTS
  const runAllTests = () => {
    setIsRunningAll(true);
    runScenario1();
    runScenario2();
    runScenario3();
    runScenario4();
    runScenario5();
    setIsRunningAll(false);
  };

  // Find user accounts for quick test simulation
  const ownerUser = storage.users.find(u => u.role === 'OWNER') || storage.users[0];
  const kasirUser = storage.users.find(u => u.role === 'KASIR');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 text-[10px] font-black uppercase tracking-wider border border-emerald-200">
              Quality Assurance & Verification Suite
            </span>
          </div>
          <h2 className="text-base font-extrabold text-slate-900 mt-2">
            Skenario Test Integritas Car Wash
          </h2>
          <p className="text-xs text-slate-500">
            Validasi otomatis: Bagi hasil, snapshot persentase historis, kerahasiaan Kasir, dan hak akses Owner
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={runAllTests}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Jalankan Semua Test (1-Click)</span>
          </button>
        </div>
      </div>

      {/* Quick Switch Role Bar for Testing */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-sky-600" />
          <span className="text-xs font-bold text-slate-900">Simulasi Cepat Role:</span>
          <span className="text-xs text-slate-500">
            Saat ini login sebagai: <strong className="text-slate-900">{currentUser.fullName} ({currentUser.role})</strong>
          </span>
        </div>

        <div className="flex items-center gap-2">
          {kasirUser && (
            <button
              type="button"
              onClick={() => onSwitchUser(kasirUser.id)}
              className="px-3 py-1.5 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
            >
              <EyeOff className="w-3.5 h-3.5" />
              <span>Simulasi Login Kasir ({kasirUser.fullName})</span>
            </button>
          )}

          {ownerUser && (
            <button
              type="button"
              onClick={() => onSwitchUser(ownerUser.id)}
              className="px-3 py-1.5 rounded-xl bg-sky-100 hover:bg-sky-200 text-sky-900 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Simulasi Login Owner ({ownerUser.fullName})</span>
            </button>
          )}
        </div>
      </div>

      {/* Test Scenarios List */}
      <div className="space-y-4">
        {(Object.values(testResults) as TestResult[]).map(test => {
          const isPassed = test.status === 'PASSED';
          const isFailed = test.status === 'FAILED';
          const isPending = test.status === 'PENDING';

          return (
            <div
              key={test.id}
              className={`p-5 rounded-2xl border transition-all space-y-4 ${
                isPassed
                  ? 'bg-emerald-50/40 border-emerald-200'
                  : isFailed
                  ? 'bg-red-50/40 border-red-200'
                  : 'bg-white border-slate-200/90 shadow-xs'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start space-x-3">
                  <div className="mt-0.5">
                    {isPassed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    ) : isFailed ? (
                      <XCircle className="w-5 h-5 text-red-600" />
                    ) : (
                      <div className="w-5 h-5 rounded-full border-2 border-slate-300" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-slate-900">{test.name}</h3>
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{test.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <span
                    className={`px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-wider ${
                      isPassed
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : isFailed
                        ? 'bg-red-100 text-red-800 border border-red-300'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {test.status}
                  </span>

                  <button
                    type="button"
                    onClick={() => {
                      if (test.id === 'scenario_1') runScenario1();
                      if (test.id === 'scenario_2') runScenario2();
                      if (test.id === 'scenario_3') runScenario3();
                      if (test.id === 'scenario_4') runScenario4();
                      if (test.id === 'scenario_5') runScenario5();
                    }}
                    className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-900 text-xs font-bold rounded-xl border border-slate-200 shadow-xs cursor-pointer"
                  >
                    Uji Skenario Ini
                  </button>
                </div>
              </div>

              {/* Execution Details Log */}
              {test.details.length > 0 && (
                <div className="bg-slate-900 text-slate-200 p-3.5 rounded-xl text-[11px] font-mono space-y-1">
                  {test.details.map((line, idx) => (
                    <div
                      key={idx}
                      className={
                        line.startsWith('[Verifikasi]') || line.startsWith('[Snapshot]')
                          ? 'text-emerald-400 font-bold'
                          : line.startsWith('[ERROR]')
                          ? 'text-red-400 font-bold'
                          : 'text-slate-300'
                      }
                    >
                      {line}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
