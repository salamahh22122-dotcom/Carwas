import React, { useState, useMemo } from 'react';
import {
  Clock,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Users,
  LogIn,
  LogOut,
  Download,
  Filter,
  UserCheck,
  Search,
} from 'lucide-react';
import { Employee, Attendance, DatePeriodFilter } from '../types';
import { CarWashStorage } from '../data/storage';

interface AttendanceViewProps {
  storage: CarWashStorage;
  employees: Employee[];
  attendanceList: Attendance[];
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  storage,
  employees,
  attendanceList,
}) => {
  const [viewMode, setViewMode] = useState<'HARIAN' | 'REKAP'>('HARIAN');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [period, setPeriod] = useState<DatePeriodFilter>('THIS_MONTH');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [showCustomPicker, setShowCustomPicker] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Note dialog state for Izin/Sakit
  const [permitNoteModal, setPermitNoteModal] = useState<{ empId: number; empName: string; status: 'PERMIT' | 'SICK' } | null>(null);
  const [permitNoteText, setPermitNoteText] = useState('');

  // Today's date string
  const todayStr = new Date().toISOString().split('T')[0];

  const handleRecordAttendance = (
    empId: number,
    status: Attendance['status'],
    notes?: string
  ) => {
    storage.recordAttendance({
      employeeId: empId,
      date: selectedDate,
      status,
      checkInTime: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      notes,
    });
  };

  const handleConfirmPermit = () => {
    if (!permitNoteModal) return;
    handleRecordAttendance(permitNoteModal.empId, permitNoteModal.status, permitNoteText);
    setPermitNoteModal(null);
    setPermitNoteText('');
  };

  const handleCheckOut = (attId: number) => {
    const time = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    storage.checkOutAttendance(attId, time);
  };

  // Filter attendance for selected date (Daily Mode)
  const dateAttendance = attendanceList.filter(a => a.date === selectedDate);
  const presentCount = dateAttendance.filter(a => a.status === 'PRESENT').length;
  const lateCount = dateAttendance.filter(a => a.status === 'LATE').length;
  const permitCount = dateAttendance.filter(a => a.status === 'PERMIT' || a.status === 'SICK').length;

  // Filter attendance for Period (Owner Recap Mode)
  const periodAttendance = useMemo(() => {
    return storage.filterAttendanceByPeriod(attendanceList, period, customStart, customEnd);
  }, [storage, attendanceList, period, customStart, customEnd]);

  // Per-staff attendance statistics for selected period
  const staffRecap = useMemo(() => {
    return employees.map(emp => {
      const logs = periodAttendance.filter(a => a.employeeId === emp.id);
      const present = logs.filter(a => a.status === 'PRESENT').length;
      const late = logs.filter(a => a.status === 'LATE').length;
      const permit = logs.filter(a => a.status === 'PERMIT' || a.status === 'SICK').length;
      const totalDays = logs.length;
      const disciplineRate = totalDays > 0 ? ((present) / totalDays) * 100 : 100;

      return {
        employee: emp,
        totalDays,
        present,
        late,
        permit,
        disciplineRate,
      };
    });
  }, [employees, periodAttendance]);

  // Export CSV for Owner Recap
  const handleExportCSV = () => {
    let csv = 'Nama Staff,Jabatan,Total Hari Terdata,Hadir Tepat Waktu,Terlambat,Izin / Sakit,Tingkat Kehadiran (%)\n';
    staffRecap.forEach(st => {
      csv += `"${st.employee.name}","${st.employee.position}",${st.totalDays},${st.present},${st.late},${st.permit},${st.disciplineRate.toFixed(1)}%\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `Rekap_Absensi_CleanAuto_${period}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-base font-extrabold text-slate-900">Presensi & Rekap Absensi Staff</h2>
          <p className="text-xs text-slate-500">
            Check-in masuk kerja, check-out kepulangan shift, dan rekapitulasi kehadiran berkala owner
          </p>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-xl self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setViewMode('HARIAN')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              viewMode === 'HARIAN' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Presensi Harian
          </button>
          <button
            type="button"
            onClick={() => setViewMode('REKAP')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              viewMode === 'REKAP' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Rekap Periode Owner
          </button>
        </div>
      </div>

      {/* ======================================================================= */}
      {/* MODE 1: PRESENSI HARIAN (CHECK-IN & CHECK-OUT) */}
      {/* ======================================================================= */}
      {viewMode === 'HARIAN' && (
        <div className="space-y-5">
          {/* Date Selector */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-sky-600" />
              <span className="text-xs font-bold text-slate-800">Tanggal Presensi:</span>
              <input
                type="date"
                value={selectedDate}
                onChange={e => setSelectedDate(e.target.value)}
                className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-sky-500 font-bold text-slate-900"
              />
            </div>

            <div className="flex items-center gap-2">
              {selectedDate === todayStr && (
                <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-extrabold border border-emerald-200">
                  Hari Ini
                </span>
              )}
            </div>
          </div>

          {/* KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex items-center space-x-3.5">
              <div className="p-3 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Hadir Tepat Waktu</p>
                <p className="text-xl font-black text-emerald-700">{presentCount} Orang</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex items-center space-x-3.5">
              <div className="p-3 rounded-xl bg-amber-50 text-amber-600 border border-amber-100">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Terlambat</p>
                <p className="text-xl font-black text-amber-700">{lateCount} Orang</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex items-center space-x-3.5">
              <div className="p-3 rounded-xl bg-purple-50 text-purple-600 border border-purple-100">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Izin / Sakit</p>
                <p className="text-xl font-black text-purple-700">{permitCount} Orang</p>
              </div>
            </div>
          </div>

          {/* Employee Attendance Table */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                Status Presensi Staff ({selectedDate === todayStr ? 'Hari Ini' : selectedDate})
              </h3>
              <span className="text-xs text-slate-500">
                {employees.filter(e => e.status === 'ACTIVE').length} staff aktif terdaftar
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {employees
                .filter(e => e.status === 'ACTIVE')
                .map(emp => {
                  const record = dateAttendance.find(a => a.employeeId === emp.id);

                  return (
                    <div
                      key={emp.id}
                      className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/60 px-2 rounded-xl transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-black text-sm">
                          {emp.name.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-xs text-slate-900">{emp.name}</h4>
                          <p className="text-[11px] text-slate-500">{emp.position}</p>
                          {record?.notes && (
                            <p className="text-[10px] text-purple-700 mt-0.5 italic">Catatan: {record.notes}</p>
                          )}
                        </div>
                      </div>

                      {record ? (
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <span
                              className={`px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                                record.status === 'PRESENT'
                                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                  : record.status === 'LATE'
                                  ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                  : 'bg-purple-50 text-purple-800 border border-purple-200'
                              }`}
                            >
                              {record.status === 'PRESENT'
                                ? 'Hadir'
                                : record.status === 'LATE'
                                ? 'Terlambat'
                                : 'Izin / Sakit'}
                            </span>
                            <p className="text-xs text-slate-600 font-medium mt-1">
                              Masuk: <strong>{record.checkInTime || '-'}</strong>
                              {record.checkOutTime && (
                                <span> • Pulang: <strong className="text-emerald-700">{record.checkOutTime}</strong></span>
                              )}
                            </p>
                          </div>

                          {!record.checkOutTime ? (
                            <button
                              type="button"
                              onClick={() => handleCheckOut(record.id)}
                              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                            >
                              <LogOut className="w-3.5 h-3.5" />
                              <span>Absen Pulang (Check-Out)</span>
                            </button>
                          ) : (
                            <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                              Sudah Check-Out
                            </span>
                          )}
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <button
                            type="button"
                            onClick={() => handleRecordAttendance(emp.id, 'PRESENT')}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs flex items-center gap-1"
                          >
                            <LogIn className="w-3.5 h-3.5" />
                            <span>Check-In Hadir</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRecordAttendance(emp.id, 'LATE')}
                            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
                          >
                            Terlambat
                          </button>
                          <button
                            type="button"
                            onClick={() => setPermitNoteModal({ empId: emp.id, empName: emp.name, status: 'PERMIT' })}
                            className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
                          >
                            Izin / Sakit
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* MODE 2: REKAP ABSENSI OWNER (PER STAFF & PERIODE) */}
      {/* ======================================================================= */}
      {viewMode === 'REKAP' && (
        <div className="space-y-5">
          {/* Period Filter Bar */}
          <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-sky-600" />
              <span className="text-xs font-bold text-slate-900">Periode Rekap:</span>
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: 'TODAY', label: 'Hari Ini' },
                { id: 'YESTERDAY', label: 'Kemarin' },
                { id: 'THIS_WEEK', label: 'Minggu Ini' },
                { id: 'THIS_MONTH', label: 'Bulan Ini' },
                { id: 'CUSTOM', label: 'Kustom Tanggal' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setPeriod(item.id as DatePeriodFilter);
                    if (item.id === 'CUSTOM') setShowCustomPicker(true);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    period === item.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleExportCSV}
              className="px-3.5 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Rekap (CSV)</span>
            </button>
          </div>

          {/* Custom Date Range Picker */}
          {showCustomPicker && period === 'CUSTOM' && (
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl flex flex-wrap items-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-700">Tanggal Mulai:</span>
                <input
                  type="date"
                  value={customStart}
                  onChange={e => setCustomStart(e.target.value)}
                  className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-sky-500"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-700">Tanggal Selesai:</span>
                <input
                  type="date"
                  value={customEnd}
                  onChange={e => setCustomEnd(e.target.value)}
                  className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-sky-500"
                />
              </div>
              <button
                onClick={() => setShowCustomPicker(false)}
                className="px-4 py-1.5 bg-slate-900 text-white font-bold rounded-xl cursor-pointer hover:bg-slate-800"
              >
                Terapkan Filter
              </button>
            </div>
          )}

          {/* Rekap Table Per Staff */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Rekapitulasi Kehadiran per Staff</h3>
              <p className="text-xs text-slate-500">
                Owner dapat melihat total hari hadir, keterlambatan, dan tingkat kedisiplinan kerja setiap karyawan
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="p-3">Nama Staff</th>
                    <th className="p-3">Jabatan</th>
                    <th className="p-3 text-center">Total Presensi</th>
                    <th className="p-3 text-center">Hadir Tepat Waktu</th>
                    <th className="p-3 text-center">Terlambat</th>
                    <th className="p-3 text-center">Izin / Sakit</th>
                    <th className="p-3 text-right">Tingkat Kedisiplinan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {staffRecap.map(item => (
                    <tr key={item.employee.id} className="hover:bg-slate-50">
                      <td className="p-3 font-bold text-slate-900 text-sm">{item.employee.name}</td>
                      <td className="p-3 text-slate-500">{item.employee.position}</td>
                      <td className="p-3 text-center font-bold text-slate-700">{item.totalDays} Hari</td>
                      <td className="p-3 text-center font-bold text-emerald-600">{item.present}x</td>
                      <td className="p-3 text-center font-bold text-amber-600">{item.late}x</td>
                      <td className="p-3 text-center font-bold text-purple-600">{item.permit}x</td>
                      <td className="p-3 text-right">
                        <span className={`px-2.5 py-1 rounded-md text-xs font-black ${
                          item.disciplineRate >= 90
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {item.disciplineRate.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Daily Logs Table */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Catatan Detail Presensi Harian</h3>
            <div className="divide-y divide-slate-100">
              {periodAttendance.length === 0 ? (
                <p className="text-xs text-slate-400 py-3 text-center italic">Tidak ada catatan presensi pada periode ini.</p>
              ) : (
                periodAttendance.map(log => {
                  const emp = employees.find(e => e.id === log.employeeId);
                  return (
                    <div key={log.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-slate-900">{emp?.name || 'Staff'}</span>
                        <span className="text-slate-400 text-[11px] ml-2 font-mono">{log.date}</span>
                        {log.notes && <p className="text-[11px] text-slate-500 italic mt-0.5">{log.notes}</p>}
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-[11px] text-slate-600">
                          Masuk: <strong>{log.checkInTime || '-'}</strong> • Pulang: <strong>{log.checkOutTime || '-'}</strong>
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                          log.status === 'PRESENT'
                            ? 'bg-emerald-100 text-emerald-800'
                            : log.status === 'LATE'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {log.status === 'PRESENT' ? 'Hadir' : log.status === 'LATE' ? 'Terlambat' : 'Izin / Sakit'}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal Izin / Sakit */}
      {permitNoteModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-xl border border-slate-200">
            <h4 className="text-sm font-black text-slate-900">Catatan Izin / Sakit: {permitNoteModal.empName}</h4>
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-600">Alasan Izin / Sakit:</label>
              <textarea
                value={permitNoteText}
                onChange={e => setPermitNoteText(e.target.value)}
                placeholder="Contoh: Sakit demam, izin keperluan keluarga..."
                rows={3}
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-sky-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPermitNoteModal(null)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmPermit}
                className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl cursor-pointer shadow-xs"
              >
                Simpan Presensi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
