import React, { useState } from 'react';
import {
  Settings,
  Building2,
  Database,
  Download,
  Upload,
  RefreshCw,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Lock,
} from 'lucide-react';
import { Business, User, ROLE_PERMISSIONS, RolePermissionConfig } from '../types';
import { CarWashStorage } from '../data/storage';

interface BusinessSettingsViewProps {
  storage: CarWashStorage;
  currentBusiness: Business | null;
  currentUser: User;
}

export const BusinessSettingsView: React.FC<BusinessSettingsViewProps> = ({
  storage,
  currentBusiness,
  currentUser,
}) => {
  const [name, setName] = useState(currentBusiness?.name || '');
  const [address, setAddress] = useState(currentBusiness?.address || '');
  const [phone, setPhone] = useState(currentBusiness?.phone || '');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);

  const canEdit = currentUser.role === 'OWNER' || currentUser.role === 'MASTER';

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBusiness) return;
    storage.updateBusiness(currentBusiness.id, {
      name: name.trim(),
      address: address.trim(),
      phone: phone.trim(),
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleExportBackup = () => {
    const jsonStr = storage.exportDatabaseJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_CleanAuto_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const content = event.target?.result as string;
        const res = storage.importDatabaseJson(content);
        if (res.success) {
          setRestoreMessage('Database berhasil dipulihkan dari file backup!');
        } else {
          setRestoreMessage(`Gagal memulihkan: ${res.message}`);
        }
      } catch (err) {
        setRestoreMessage('Format file JSON tidak valid.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetDatabase = () => {
    if (confirm('PERINGATAN: Seluruh data transaksi, antrian, dan pelanggan akan dikembalikan ke data awal demo! Lanjutkan?')) {
      storage.resetToDefaults();
      setRestoreMessage('Database berhasil direset ke kondisi awal.');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-base font-extrabold text-slate-900">Pengaturan Usaha & Keamanan Sistem</h2>
          <p className="text-xs text-slate-500">
            Profil cabang, pencadangan database JSON, dan matriks hak akses per peran pengguna
          </p>
        </div>
      </div>

      {restoreMessage && (
        <div className="p-4 rounded-xl bg-sky-50 border border-sky-200 text-sky-800 text-xs font-bold flex items-center justify-between">
          <span>{restoreMessage}</span>
          <button onClick={() => setRestoreMessage(null)} className="underline cursor-pointer">
            Tutup
          </button>
        </div>
      )}

      {/* Profile Form */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-sky-50 text-sky-700 border border-sky-100">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-900">Profil Unit Usaha Car Wash</h3>
            <p className="text-xs text-slate-500">Informasi yang tercetak pada kop struk transaksi pelanggan</p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-4 pt-2">
          {savedSuccess && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Profil berhasil disimpan!</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Nama Usaha</label>
            <input
              type="text"
              disabled={!canEdit}
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-sky-500 disabled:bg-slate-50 font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Alamat Lengkap</label>
            <input
              type="text"
              disabled={!canEdit}
              value={address}
              onChange={e => setAddress(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-sky-500 disabled:bg-slate-50 font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Nomor Telepon / WhatsApp</label>
            <input
              type="text"
              disabled={!canEdit}
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-sky-500 disabled:bg-slate-50 font-medium"
            />
          </div>

          {canEdit && (
            <button
              type="submit"
              className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
            >
              Simpan Perubahan Profil
            </button>
          )}
        </form>
      </div>

      {/* Backup & Restore Section */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-purple-50 text-purple-700 border border-purple-100">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-900">Cadangkan & Pulihkan Database</h3>
            <p className="text-xs text-slate-500">Unduh atau pulihkan seluruh database lokal (JSON format)</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            onClick={handleExportBackup}
            className="p-4 rounded-xl border border-slate-200 hover:border-slate-400 hover:bg-slate-50 flex flex-col items-center justify-center gap-2 transition-all cursor-pointer shadow-xs"
          >
            <Download className="w-5 h-5 text-slate-700" />
            <span className="font-bold text-xs text-slate-800">Export Backup (JSON)</span>
            <span className="text-[10px] text-slate-400">Unduh data offline</span>
          </button>

          <label className="p-4 rounded-xl border border-slate-200 hover:border-sky-400 hover:bg-sky-50/50 flex flex-col items-center justify-center gap-2 transition-all cursor-pointer shadow-xs">
            <Upload className="w-5 h-5 text-sky-600" />
            <span className="font-bold text-xs text-slate-800">Import Restore (JSON)</span>
            <span className="text-[10px] text-slate-400">Pulihkan dari file</span>
            <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
          </label>

          <button
            onClick={handleResetDatabase}
            className="p-4 rounded-xl border border-red-200 hover:bg-red-50 flex flex-col items-center justify-center gap-2 transition-all cursor-pointer shadow-xs"
          >
            <RefreshCw className="w-5 h-5 text-red-600" />
            <span className="font-bold text-xs text-red-700">Reset ke Demo Awal</span>
            <span className="text-[10px] text-red-400">Kembalikan data default</span>
          </button>
        </div>
      </div>

      {/* RBAC Matrix */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-100">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-900">Matriks Hak Akses Per Peran (RBAC)</h3>
            <p className="text-xs text-slate-500">Kebijakan privasi dan pembatasan fungsi sistem</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
              <tr>
                <th className="p-3">Peran / Role</th>
                <th className="p-3 text-center">Bagi Hasil Rahasia</th>
                <th className="p-3 text-center">Laporan Omzet</th>
                <th className="p-3 text-center">Manajemen Staf</th>
                <th className="p-3 text-center">Kasir POS</th>
                <th className="p-3 text-center">Alur Antrian</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {Object.entries(ROLE_PERMISSIONS).map(([role, p]) => {
                const perm = p as RolePermissionConfig;
                return (
                  <tr key={role} className="hover:bg-slate-50">
                    <td className="p-3 font-bold text-slate-900">{role}</td>
                    <td className="p-3 text-center">{perm.canViewProfitShare ? '✅ Ya' : '🔒 Terkunci'}</td>
                    <td className="p-3 text-center">{perm.canViewFinancialReports ? '✅ Ya' : '🔒 Terkunci'}</td>
                    <td className="p-3 text-center">{perm.canManageEmployees ? '✅ Ya' : '🔒 Terkunci'}</td>
                    <td className="p-3 text-center">{perm.canOperatePos ? '✅ Ya' : '❌ Tidak'}</td>
                    <td className="p-3 text-center">{perm.canManageQueue ? '✅ Ya' : '❌ Tidak'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
