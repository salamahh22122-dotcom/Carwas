import React, { useState, useMemo } from 'react';
import {
  Users,
  UserPlus,
  Edit,
  History,
  Lock,
  Search,
  Phone,
  Briefcase,
  CheckCircle2,
  XCircle,
  Percent,
  Trash2,
} from 'lucide-react';
import { Employee, StaffProfitSetting } from '../types';
import { CarWashStorage } from '../data/storage';
import {
  AddEmployeeModal,
  EditEmployeeModal,
  ProfitHistoryModal,
} from '../components/StaffModals';
import { CashierAccountModal } from '../components/CashierAccountModal';

interface EmployeeViewProps {
  storage: CarWashStorage;
  employees: Employee[];
  canViewProfit: boolean;
  canManageProfit: boolean;
  canManageStaff: boolean;
}

export const EmployeeView: React.FC<EmployeeViewProps> = ({
  storage,
  employees,
  canViewProfit,
  canManageProfit,
  canManageStaff,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');

  // Modals state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isCashierAccountOpen, setIsCashierAccountOpen] = useState(false);
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);
  const [historyEmp, setHistoryEmp] = useState<Employee | null>(null);
  const [historyList, setHistoryList] = useState<StaffProfitSetting[]>([]);

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchSearch =
        emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.phone.includes(searchQuery);
      const matchStatus = statusFilter === 'ALL' || emp.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [employees, searchQuery, statusFilter]);

  const cashierAccounts = storage.users.filter(
    user => user.role === 'KASIR' && user.businessId === storage.currentBusiness?.id
  );
  const canCreateCashier = storage.currentUser?.role === 'OWNER';

  const activeCount = employees.filter(e => e.status === 'ACTIVE').length;
  const avgProfit =
    employees.length > 0
      ? (employees.reduce((sum, e) => sum + e.currentProfitPercentage, 0) / employees.length).toFixed(0)
      : 0;

  const handleOpenHistory = (emp: Employee) => {
    setHistoryEmp(emp);
    const list = storage.getStaffProfitHistory(emp.id);
    setHistoryList(list);
  };

  const handleToggleStatus = (emp: Employee) => {
    const nextStatus = emp.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    storage.updateEmployee(emp.id, { status: nextStatus });
  };

  const handleDelete = (emp: Employee) => {
    if (confirm(`Yakin ingin menghapus data staff "${emp.name}"?`)) {
      storage.deleteEmployee(emp.id);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900">Manajemen Staf & Skema Bagi Hasil</h2>
          <p className="text-xs text-slate-500">
            Kelola data petugas cuci, penugasan antrian, dan persentase komisi rahasia
          </p>
        </div>

        {canManageStaff && (
          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            {canCreateCashier && (
              <button
                onClick={() => setIsCashierAccountOpen(true)}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>+ Daftar Akun Kasir</span>
              </button>
            )}
            <button
              onClick={() => setIsAddOpen(true)}
              className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>+ Tambah Staff Baru</span>
            </button>
          </div>
        )}
      </div>

      {/* Owner-only cashier account management */}
      {canCreateCashier && (
        <div className="bg-white rounded-2xl border border-emerald-200 shadow-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-emerald-100 bg-emerald-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Akun Kasir Bisnis</h3>
              <p className="text-[11px] text-slate-500 mt-0.5">Kelola akun login Kasir yang terikat ke bisnis ini.</p>
            </div>
            <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800">{cashierAccounts.length} akun</span>
          </div>

          {cashierAccounts.length === 0 ? (
            <div className="p-5 text-xs text-slate-400">Belum ada akun Kasir untuk bisnis ini.</div>
          ) : (
            <div className="divide-y divide-slate-100">
              {cashierAccounts.map(account => (
                <div key={account.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                      {account.fullName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-900">{account.fullName}</p>
                      <p className="text-[11px] text-slate-500">@{account.username}{account.email ? ` • ${account.email}` : ''}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${account.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'}`}>
                      {account.isActive ? 'Aktif' : 'Nonaktif'}
                    </span>
                    <button
                      onClick={() => storage.toggleUserStatus(account.id)}
                      className="text-[11px] font-bold text-slate-600 hover:text-slate-900 underline"
                    >
                      {account.isActive ? 'Nonaktifkan' : 'Aktifkan'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-sky-50 text-sky-600">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Total Petugas</p>
            <p className="text-xl font-extrabold text-slate-900">{employees.length} Orang</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-emerald-50 text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Petugas Aktif</p>
            <p className="text-xl font-extrabold text-emerald-700">{activeCount} Siap Tugas</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-purple-50 text-purple-600">
            <Percent className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Rata-rata Komisi</p>
            {canViewProfit ? (
              <p className="text-xl font-extrabold text-purple-700">{avgProfit}% / Cuci</p>
            ) : (
              <p className="text-xs text-slate-400 font-bold flex items-center gap-1">
                <Lock className="w-3.5 h-3.5" /> Dirahasiakan
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Search & Status Filter */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari nama staff, jabatan..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
          />
        </div>

        <div className="flex items-center space-x-1.5">
          {(['ALL', 'ACTIVE', 'INACTIVE'] as const).map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                statusFilter === st
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st === 'ALL' ? 'Semua' : st === 'ACTIVE' ? 'Aktif' : 'Nonaktif'}
            </button>
          ))}
        </div>
      </div>

      {/* Staff List Grid */}
      {filteredEmployees.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 text-slate-400 text-xs">
          Tidak ada staff ditemukan.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEmployees.map(emp => (
            <div
              key={emp.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-all space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-11 h-11 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-black text-base">
                      {emp.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{emp.name}</h3>
                      <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                        <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                        {emp.position}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      emp.status === 'ACTIVE'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {emp.status === 'ACTIVE' ? 'Aktif' : 'Nonaktif'}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-xs text-slate-600">
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{emp.phone}</span>
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Bergabung:{' '}
                    {new Date(emp.joinedDate).toLocaleDateString('id-ID', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </p>
                </div>

                {/* Profit sharing badge */}
                <div className="p-3 rounded-xl bg-purple-50/70 border border-purple-100 flex items-center justify-between text-xs">
                  <span className="text-purple-900 font-semibold">Skema Bagi Hasil:</span>
                  {canViewProfit ? (
                    <span className="font-extrabold text-purple-700 text-sm">
                      {emp.currentProfitPercentage}% per Mobil
                    </span>
                  ) : (
                    <span className="text-slate-400 text-xs flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5" /> Dirahasiakan
                    </span>
                  )}
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2">
                  {canViewProfit && (
                    <button
                      onClick={() => handleOpenHistory(emp)}
                      className="p-1.5 text-purple-600 hover:text-purple-800 hover:bg-purple-50 rounded-lg transition-colors cursor-pointer"
                      title="Riwayat Perubahan Komisi"
                    >
                      <History className="w-4 h-4" />
                    </button>
                  )}

                  {canManageStaff && (
                    <button
                      onClick={() => setEditingEmp(emp)}
                      className="p-1.5 text-sky-600 hover:text-sky-800 hover:bg-sky-50 rounded-lg transition-colors cursor-pointer"
                      title="Edit Data Staff"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  )}

                  {canManageStaff && (
                    <button
                      onClick={() => handleDelete(emp)}
                      className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                      title="Hapus Staff"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {canManageStaff && (
                  <button
                    onClick={() => handleToggleStatus(emp)}
                    className="text-[11px] font-bold text-slate-500 hover:text-slate-800 underline cursor-pointer"
                  >
                    {emp.status === 'ACTIVE' ? 'Nonaktifkan' : 'Aktifkan'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      <CashierAccountModal
        isOpen={isCashierAccountOpen}
        onClose={() => setIsCashierAccountOpen(false)}
        onConfirm={data =>
          storage.createCashierAccount({
            fullName: data.fullName,
            username: data.username,
            email: data.email,
            phone: data.phone,
            passwordPlain: data.password,
          })
        }
      />


      <AddEmployeeModal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        onConfirm={data => storage.addEmployee(data)}
      />

      <EditEmployeeModal
        isOpen={!!editingEmp}
        onClose={() => setEditingEmp(null)}
        employee={editingEmp}
        canManageProfit={canManageProfit}
        onConfirm={(id, updates, notes) => storage.updateEmployee(id, updates, notes)}
      />

      <ProfitHistoryModal
        isOpen={!!historyEmp}
        onClose={() => setHistoryEmp(null)}
        employeeName={historyEmp?.name || ''}
        historyList={historyList}
      />
    </div>
  );
};
