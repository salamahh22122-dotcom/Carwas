import React, { useState, useMemo } from 'react';
import { Sparkles, Plus, Edit, Trash2, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { Service } from '../types';
import { CarWashStorage } from '../data/storage';
import { ServiceModal } from '../components/ServiceModals';

interface ServicesViewProps {
  storage: CarWashStorage;
  services: Service[];
}

export const ServicesView: React.FC<ServicesViewProps> = ({ storage, services }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);

  const categories = useMemo(() => {
    const set = new Set(services.map(s => s.category));
    return ['ALL', ...Array.from(set)];
  }, [services]);

  const filteredServices = useMemo(() => {
    if (selectedCategory === 'ALL') return services;
    return services.filter(s => s.category === selectedCategory);
  }, [services, selectedCategory]);

  const handleToggleActive = (s: Service) => {
    storage.updateService(s.id, { isActive: !s.isActive });
  };

  const handleDelete = (s: Service) => {
    if (confirm(`Hapus layanan "${s.name}"?`)) {
      storage.deleteService(s.id);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900">Katalog Paket & Layanan Cuci</h2>
          <p className="text-xs text-slate-500">
            Daftar harga cuci mobil, motor, detailing interior, salon, dan hidrolik kolong
          </p>
        </div>

        <button
          onClick={() => setIsAddOpen(true)}
          className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Tambah Layanan Baru</span>
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center gap-1.5 bg-white p-2 rounded-2xl border border-slate-200 shadow-xs">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              selectedCategory === cat
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {cat === 'ALL' ? 'Semua Kategori' : cat}
          </button>
        ))}
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredServices.map(srv => (
          <div
            key={srv.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-all space-y-4"
          >
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-sky-50 text-sky-700">
                  {srv.category}
                </span>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    srv.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {srv.isActive ? 'Tersedia' : 'Nonaktif'}
                </span>
              </div>

              <h3 className="font-bold text-sm text-slate-900">{srv.name}</h3>
              <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                {srv.description || 'Layanan pembersihan dan perawatan kendaraan komprehensif.'}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-3">
              <div className="flex items-baseline justify-between">
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> ~{srv.estimatedDurationMinutes} Menit
                </span>
                <span className="text-base font-extrabold text-sky-700">
                  Rp {srv.price.toLocaleString('id-ID')}
                </span>
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => handleToggleActive(srv)}
                  className="text-[11px] font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  {srv.isActive ? 'Nonaktifkan' : 'Aktifkan'}
                </button>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => setEditingService(srv)}
                    className="p-1.5 text-sky-600 hover:bg-sky-50 rounded-lg transition-colors cursor-pointer"
                    title="Edit Layanan"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(srv)}
                    className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                    title="Hapus Layanan"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <ServiceModal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        onConfirm={data => storage.addService(data)}
      />

      <ServiceModal
        isOpen={!!editingService}
        onClose={() => setEditingService(null)}
        service={editingService}
        onConfirm={data => {
          if (editingService) storage.updateService(editingService.id, data);
        }}
      />
    </div>
  );
};
