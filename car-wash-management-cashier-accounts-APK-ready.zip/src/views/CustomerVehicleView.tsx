import React, { useState, useMemo } from 'react';
import {
  Users,
  Car,
  Search,
  Plus,
  Gift,
  Phone,
  Award,
  Sparkles,
  MessageCircle,
  History,
  X,
  Receipt,
  Calendar,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import { Customer, Vehicle, CustomerMembership, PointRule, Transaction } from '../types';
import { CarWashStorage } from '../data/storage';
import { AdjustPointsModal } from '../components/MembershipModals';

interface CustomerVehicleViewProps {
  storage: CarWashStorage;
  customers: Customer[];
  vehicles: Vehicle[];
  customerMemberships: CustomerMembership[];
  pointRule: PointRule | null;
  transactions?: Transaction[];
  onOpenQuickCustomer: () => void;
}

export const CustomerVehicleView: React.FC<CustomerVehicleViewProps> = ({
  storage,
  customers,
  vehicles,
  customerMemberships,
  pointRule,
  transactions = [],
  onOpenQuickCustomer,
}) => {
  const [activeTab, setActiveTab] = useState<'customers' | 'vehicles'>('customers');
  const [searchQuery, setSearchQuery] = useState('');
  const [adjustCustomer, setAdjustCustomer] = useState<Customer | null>(null);
  const [selectedVehicleForHistory, setSelectedVehicleForHistory] = useState<Vehicle | null>(null);

  // Filter Customers based on Name, Phone, or License Plate
  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) return customers;
    const q = searchQuery.toLowerCase().trim();
    return customers.filter(c => {
      const matchName = c.name.toLowerCase().includes(q);
      const matchPhone = c.phone.replace(/[^0-9]/g, '').includes(q.replace(/[^0-9]/g, ''));
      const custVehicles = vehicles.filter(v => v.customerId === c.id);
      const matchPlate = custVehicles.some(
        v => v.licensePlate.toLowerCase().includes(q) || v.brandModel.toLowerCase().includes(q)
      );
      return matchName || matchPhone || matchPlate;
    });
  }, [customers, vehicles, searchQuery]);

  // Filter Vehicles based on License Plate, Brand/Model, Color, or Owner Name/Phone
  const filteredVehicles = useMemo(() => {
    if (!searchQuery.trim()) return vehicles;
    const q = searchQuery.toLowerCase().trim();
    return vehicles.filter(v => {
      const matchPlate = v.licensePlate.toLowerCase().includes(q);
      const matchBrand = v.brandModel.toLowerCase().includes(q);
      const matchColor = v.color.toLowerCase().includes(q);
      const owner = customers.find(c => c.id === v.customerId);
      const matchOwnerName = owner ? owner.name.toLowerCase().includes(q) : false;
      const matchOwnerPhone = owner ? owner.phone.includes(q) : false;
      return matchPlate || matchBrand || matchColor || matchOwnerName || matchOwnerPhone;
    });
  }, [vehicles, customers, searchQuery]);

  // Wash history for selected vehicle
  const vehicleWashHistory = useMemo(() => {
    if (!selectedVehicleForHistory) return [];
    return transactions
      .filter(t => t.vehicleId === selectedVehicleForHistory.id)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [selectedVehicleForHistory, transactions]);

  // Vehicle stats
  const vehicleStats = useMemo(() => {
    if (!selectedVehicleForHistory) return { totalCount: 0, totalSpend: 0, lastDate: '-' };
    const history = transactions.filter(t => t.vehicleId === selectedVehicleForHistory.id);
    const totalSpend = history.reduce((sum, t) => sum + t.totalAmount, 0);
    const lastDate =
      history.length > 0
        ? new Date(history[0].createdAt).toLocaleDateString('id-ID', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
          })
        : '-';
    return {
      totalCount: history.length,
      totalSpend,
      lastDate,
    };
  }, [selectedVehicleForHistory, transactions]);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-base font-extrabold text-slate-900">Database Pelanggan & Kendaraan</h2>
          <p className="text-xs text-slate-500">
            Rekam jejak kunjungan, riwayat cuci kendaraan, staf pencuci, dan saldo poin reward
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenQuickCustomer}
          className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Tambah Pelanggan & Mobil</span>
        </button>
      </div>

      {/* Tabs & Search Bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('customers')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'customers'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Pelanggan Terdaftar ({customers.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('vehicles')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'vehicles'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Car className="w-4 h-4" />
            <span>Plat Kendaraan ({vehicles.length})</span>
          </button>
        </div>

        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari nama, nomor HP, plat nomor..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-sky-500 font-medium"
          />
        </div>
      </div>

      {/* ======================================================================= */}
      {/* TAB 1: CUSTOMERS */}
      {/* ======================================================================= */}
      {activeTab === 'customers' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCustomers.length === 0 ? (
            <div className="col-span-full bg-white p-8 text-center rounded-2xl border border-slate-200/90 shadow-xs">
              <p className="text-xs text-slate-500">Tidak ada data pelanggan yang cocok dengan pencarian.</p>
            </div>
          ) : (
            filteredCustomers.map(cust => {
              const custVehicles = vehicles.filter(v => v.customerId === cust.id);
              const activeMb = customerMemberships.find(
                m => m.customerId === cust.id && m.remainingQuota > 0 && m.expiresAt > Date.now()
              );
              const waUrl = cust.phone
                ? `https://wa.me/${cust.phone.replace(/[^0-9]/g, '')}`
                : null;

              return (
                <div
                  key={cust.id}
                  className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-all space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-extrabold text-sm text-slate-900">{cust.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <p className="text-xs text-slate-500 flex items-center gap-1 font-mono">
                            <Phone className="w-3.5 h-3.5 text-slate-400" />
                            {cust.phone}
                          </p>
                          {waUrl && (
                            <a
                              href={waUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-md"
                            >
                              <MessageCircle className="w-3 h-3" /> Chat WA
                            </a>
                          )}
                        </div>
                      </div>

                      <span className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 text-xs font-bold border border-sky-100">
                        {cust.totalVisits}x Datang
                      </span>
                    </div>

                    {/* Registered vehicles tags with clickable history */}
                    <div>
                      <p className="text-[11px] font-bold text-slate-500 mb-1.5">Kendaraan & Riwayat Cuci:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {custVehicles.length > 0 ? (
                          custVehicles.map(v => (
                            <button
                              type="button"
                              key={v.id}
                              onClick={() => setSelectedVehicleForHistory(v)}
                              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-sky-900 text-white text-[11px] font-mono font-bold tracking-wider cursor-pointer transition-colors flex items-center gap-1"
                              title="Klik untuk melihat riwayat cuci"
                            >
                              <span>{v.licensePlate}</span>
                              <span className="text-slate-400 font-sans font-normal text-[10px]">
                                ({v.brandModel})
                              </span>
                              <History className="w-3 h-3 text-sky-400 ml-0.5" />
                            </button>
                          ))
                        ) : (
                          <span className="text-xs text-slate-400 italic">Belum ada mobil terdaftar</span>
                        )}
                      </div>
                    </div>

                    {/* Membership & Loyalty Point row */}
                    <div className="pt-2 border-t border-slate-100 space-y-2">
                      {activeMb && (
                        <div className="p-2.5 rounded-xl bg-emerald-50/80 border border-emerald-200 text-xs flex items-center justify-between text-emerald-900">
                          <span className="font-bold flex items-center gap-1">
                            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                            {activeMb.packageName}
                          </span>
                          <span className="font-black text-emerald-700">{activeMb.remainingQuota}x kuota cuci</span>
                        </div>
                      )}

                      <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs flex items-center justify-between text-amber-900">
                        <div className="flex items-center gap-1.5">
                          <Gift className="w-4 h-4 text-amber-600" />
                          <span className="text-amber-800 font-medium">Saldo Reward:</span>
                          <strong className="font-extrabold text-amber-900">{cust.pointsBalance} Poin</strong>
                        </div>

                        <button
                          type="button"
                          onClick={() => setAdjustCustomer(cust)}
                          className="text-[11px] font-bold text-amber-700 hover:text-amber-900 underline cursor-pointer"
                        >
                          Ubah Poin
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        /* ======================================================================= */
        /* TAB 2: VEHICLES */
        /* ======================================================================= */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVehicles.length === 0 ? (
            <div className="col-span-full bg-white p-8 text-center rounded-2xl border border-slate-200/90 shadow-xs">
              <p className="text-xs text-slate-500">Tidak ada kendaraan yang cocok dengan pencarian.</p>
            </div>
          ) : (
            filteredVehicles.map(v => {
              const owner = customers.find(c => c.id === v.customerId);
              const historyCount = transactions.filter(t => t.vehicleId === v.id).length;

              return (
                <div
                  key={v.id}
                  className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-all space-y-4"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-black text-sm tracking-widest bg-slate-900 text-white px-3 py-1 rounded-lg">
                        {v.licensePlate}
                      </span>
                      <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold">
                        {v.type === 'CAR' ? 'Mobil' : 'Motor'}
                      </span>
                    </div>

                    <p className="text-xs font-bold text-slate-800 mt-3">
                      {v.brandModel} • <span className="text-slate-500 font-normal">Warna {v.color}</span>
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1 border border-slate-100">
                    <p className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Pemilik Kendaraan</p>
                    <p className="font-bold text-slate-900">{owner?.name || 'Pelanggan Umum'}</p>
                    <p className="text-[11px] text-slate-500 font-mono">{owner?.phone || '-'}</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedVehicleForHistory(v)}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                  >
                    <History className="w-3.5 h-3.5 text-sky-400" />
                    <span>Lihat Riwayat Cuci ({historyCount}x)</span>
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ======================================================================= */}
      {/* MODAL: RIWAYAT CUCI KENDARAAN */}
      {/* ======================================================================= */}
      {selectedVehicleForHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 rounded-xl bg-slate-900 text-white font-mono font-black text-sm">
                  {selectedVehicleForHistory.licensePlate}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    Riwayat Cuci: {selectedVehicleForHistory.brandModel}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedVehicleForHistory.type === 'CAR' ? 'Mobil' : 'Motor'} • Warna {selectedVehicleForHistory.color}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedVehicleForHistory(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Stats Bar */}
            <div className="px-6 py-3 bg-sky-50/50 border-b border-sky-100 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-500">Total Kunjungan:</span>{' '}
                <strong className="text-sky-800 font-extrabold">{vehicleStats.totalCount} Kali</strong>
              </div>
              <div>
                <span className="text-slate-500">Kunjungan Terakhir:</span>{' '}
                <strong className="text-slate-800">{vehicleStats.lastDate}</strong>
              </div>
              <div>
                <span className="text-slate-500">Total Biaya Akumulatif:</span>{' '}
                <strong className="text-emerald-700 font-black">
                  Rp {vehicleStats.totalSpend.toLocaleString('id-ID')}
                </strong>
              </div>
            </div>

            {/* Modal History List */}
            <div className="p-6 overflow-y-auto space-y-3 divide-y divide-slate-100">
              {vehicleWashHistory.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  <Receipt className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                  <p>Belum ada riwayat transaksi cuci untuk plat nomor ini.</p>
                </div>
              ) : (
                vehicleWashHistory.map(tx => {
                  const dateStr = new Date(tx.createdAt).toLocaleDateString('id-ID', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <div key={tx.id} className="pt-3 first:pt-0 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="font-mono text-xs font-bold text-sky-700">{tx.invoiceNo}</span>
                          <span className="text-slate-400 text-xs">•</span>
                          <span className="text-slate-500 text-xs">{dateStr}</span>
                        </div>
                        <span className="text-sm font-black text-slate-900">
                          Rp {tx.totalAmount.toLocaleString('id-ID')}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-slate-800">{tx.serviceName}</span>
                          {tx.additionalAmount > 0 && (
                            <span className="text-slate-500 text-[11px] ml-1">
                              (+Addon Rp {tx.additionalAmount.toLocaleString('id-ID')})
                            </span>
                          )}
                          {tx.discountAmount > 0 && (
                            <span className="text-red-600 text-[11px] ml-1 font-semibold">
                              (Diskon -Rp {tx.discountAmount.toLocaleString('id-ID')})
                            </span>
                          )}
                        </div>

                        <span className="text-[11px] text-slate-500 font-medium">
                          Metode: <strong className="text-slate-700">{tx.paymentMethod}</strong>
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-slate-700">Staff yang Mengerjakan:</span>
                          <span className="text-slate-900 font-bold">{tx.assignedStaffNames}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="font-semibold text-slate-600">Status:</span>
                          <span className={`px-2 py-0.5 rounded font-black text-[10px] ${
                            tx.status === 'PICKED_UP'
                              ? 'bg-emerald-100 text-emerald-800'
                              : tx.status === 'FINISHED'
                              ? 'bg-sky-100 text-sky-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {tx.status === 'PICKED_UP'
                              ? 'Sudah Dijemput'
                              : tx.status === 'FINISHED'
                              ? 'Selesai'
                              : tx.status === 'WASHING'
                              ? 'Sedang Dicuci'
                              : 'Menunggu'}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedVehicleForHistory(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Point Adjustment Modal */}
      <AdjustPointsModal
        isOpen={!!adjustCustomer}
        onClose={() => setAdjustCustomer(null)}
        customer={adjustCustomer}
        onConfirm={(cid, delta, desc) => storage.adjustCustomerPoints(cid, delta, desc)}
      />
    </div>
  );
};
