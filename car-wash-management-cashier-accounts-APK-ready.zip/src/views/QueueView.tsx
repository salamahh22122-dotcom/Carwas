import React, { useState, useMemo } from 'react';
import {
  Car,
  Clock,
  ArrowRight,
  History,
  Receipt,
  MessageCircle,
  CheckCircle2,
  AlertCircle,
  Filter,
  Plus,
  Search,
  User,
  Check,
} from 'lucide-react';
import {
  Vehicle,
  Customer,
  Transaction,
  VehicleStatusHistory,
  QueueStatus,
  QUEUE_STATUSES,
} from '../types';
import { CarWashStorage } from '../data/storage';

interface QueueViewProps {
  storage: CarWashStorage;
  vehicles: Vehicle[];
  customers: Customer[];
  transactions: Transaction[];
  queueHistory: VehicleStatusHistory[];
  onOpenNewTxModal: () => void;
  onOpenReceipt: (tx: Transaction) => void;
  onOpenQueueHistory: (veh: Vehicle) => void;
}

const STAGES: QueueStatus[] = ['WAITING', 'WASHING', 'DRYING', 'FINISHED', 'PICKED_UP'];

export const QueueView: React.FC<QueueViewProps> = ({
  storage,
  vehicles,
  customers,
  transactions,
  queueHistory,
  onOpenNewTxModal,
  onOpenReceipt,
  onOpenQueueHistory,
}) => {
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ACTIVE');
  const [searchQuery, setSearchQuery] = useState('');

  // Derive latest status and associated active transaction for each vehicle
  const vehiclesWithStatus = useMemo(() => {
    return vehicles.map(veh => {
      const cust = customers.find(c => c.id === veh.customerId) || null;
      // Get most recent status entry
      const latestHistory = queueHistory.find(q => q.vehicleId === veh.id);
      const currentStatus: QueueStatus = latestHistory?.status || 'WAITING';

      // Find active or most recent transaction for this vehicle
      const latestTx = transactions.find(t => t.vehicleId === veh.id) || null;

      return {
        vehicle: veh,
        customer: cust,
        currentStatus,
        latestHistory,
        latestTx,
      };
    });
  }, [vehicles, customers, queueHistory, transactions]);

  // Filter vehicles based on tab & search
  const filteredList = useMemo(() => {
    let list = vehiclesWithStatus;
    if (selectedStatusFilter === 'ACTIVE') {
      list = list.filter(v => v.currentStatus !== 'PICKED_UP');
    } else if (selectedStatusFilter !== 'ALL') {
      list = list.filter(v => v.currentStatus === selectedStatusFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter(
        item =>
          item.vehicle.licensePlate.toLowerCase().includes(q) ||
          item.vehicle.brandModel.toLowerCase().includes(q) ||
          (item.customer?.name && item.customer.name.toLowerCase().includes(q))
      );
    }

    return list;
  }, [vehiclesWithStatus, selectedStatusFilter, searchQuery]);

  // Counts for badge tabs
  const counts = useMemo(() => {
    const c = {
      ACTIVE: 0,
      WAITING: 0,
      WASHING: 0,
      DRYING: 0,
      FINISHED: 0,
      PICKED_UP: 0,
    };
    for (const item of vehiclesWithStatus) {
      if (item.currentStatus !== 'PICKED_UP') c.ACTIVE++;
      c[item.currentStatus] = (c[item.currentStatus] || 0) + 1;
    }
    return c;
  }, [vehiclesWithStatus]);

  // Handle sequential status change
  const handleAdvanceStatus = (vehicleId: number, nextStatus: QueueStatus) => {
    storage.updateVehicleStatus(vehicleId, nextStatus, undefined, `Perubahan status ke ${nextStatus}`);
  };

  const getNextStatusConfig = (current: QueueStatus) => {
    switch (current) {
      case 'WAITING':
        return { next: 'WASHING' as QueueStatus, label: 'Mulai Cuci', color: 'bg-sky-600 hover:bg-sky-700' };
      case 'WASHING':
        return { next: 'DRYING' as QueueStatus, label: 'Masuk Pengeringan', color: 'bg-purple-600 hover:bg-purple-700' };
      case 'DRYING':
        return { next: 'FINISHED' as QueueStatus, label: 'Tandai Selesai Cuci', color: 'bg-emerald-600 hover:bg-emerald-700' };
      case 'FINISHED':
        return { next: 'PICKED_UP' as QueueStatus, label: 'Serahkan ke Pelanggan', color: 'bg-slate-800 hover:bg-slate-900' };
      case 'PICKED_UP':
        return null;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-base font-extrabold text-slate-900">Alur & Pengerjaan Antrian Kendaraan</h2>
          <p className="text-xs text-slate-500">
            Pantau tahapan cuci, pengeringan, hingga kendaraan siap diserahkan ke pelanggan
          </p>
        </div>

        <button
          onClick={onOpenNewTxModal}
          className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Masukkan Kendaraan Baru</span>
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
            {[
              { id: 'ACTIVE', label: `Aktif di Area (${counts.ACTIVE})` },
              { id: 'WAITING', label: `1. Menunggu (${counts.WAITING})` },
              { id: 'WASHING', label: `2. Dicuci (${counts.WASHING})` },
              { id: 'DRYING', label: `3. Pengeringan (${counts.DRYING})` },
              { id: 'FINISHED', label: `4. Selesai (${counts.FINISHED})` },
              { id: 'PICKED_UP', label: `5. Diambil (${counts.PICKED_UP})` },
              { id: 'ALL', label: `Semua (${vehicles.length})` },
            ].map(tab => {
              const isSel = selectedStatusFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedStatusFilter(tab.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    isSel
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Cari nopol atau nama..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-sky-500"
            />
          </div>
        </div>
      </div>

      {/* Pipeline Cards Grid */}
      {filteredList.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 text-slate-400 text-xs">
          Tidak ada antrian kendaraan pada kategori ini.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredList.map(item => {
            const { vehicle, customer, currentStatus, latestTx } = item;
            const statusMeta = QUEUE_STATUSES[currentStatus];
            const nextConfig = getNextStatusConfig(currentStatus);
            const currentStageIndex = STAGES.indexOf(currentStatus);

            const waUrl = customer?.phone
              ? `https://wa.me/${customer.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  `Halo Bapak/Ibu ${customer.name}, kendaraan Anda ${vehicle.licensePlate} (${vehicle.brandModel}) saat ini berstatus: *${statusMeta.displayName}* di CleanAuto Car Wash.`
                )}`
              : null;

            return (
              <div
                key={vehicle.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between overflow-hidden"
              >
                <div className="p-5 space-y-4">
                  {/* Top Status & Queue Badge */}
                  <div className="flex items-center justify-between">
                    <span
                      className="text-[11px] font-extrabold uppercase px-2.5 py-1 rounded-lg tracking-wider"
                      style={{ backgroundColor: statusMeta.bg, color: statusMeta.color }}
                    >
                      {statusMeta.displayName}
                    </span>

                    {latestTx && (
                      <span className="text-xs font-mono font-black text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
                        Antrian #{latestTx.queueNumber}
                      </span>
                    )}
                  </div>

                  {/* License Plate & Model */}
                  <div>
                    <div className="inline-block bg-slate-950 text-white font-mono font-black text-sm tracking-widest px-3 py-1.5 rounded-lg border border-slate-800 shadow-xs">
                      {vehicle.licensePlate}
                    </div>
                    <p className="text-xs font-bold text-slate-800 mt-2">
                      {vehicle.brandModel} • <span className="text-slate-500 font-medium">{vehicle.color} ({vehicle.type})</span>
                    </p>
                  </div>

                  {/* 5-Step Visual Progress Bar */}
                  <div className="space-y-1.5">
                    <div className="grid grid-cols-5 gap-1">
                      {STAGES.map((stg, idx) => {
                        const isDone = idx <= currentStageIndex;
                        const isCurrent = idx === currentStageIndex;
                        return (
                          <div
                            key={stg}
                            className={`h-1.5 rounded-full transition-colors ${
                              isDone ? 'bg-sky-600' : 'bg-slate-200'
                            }`}
                            title={QUEUE_STATUSES[stg].displayName}
                          />
                        );
                      })}
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                      <span>Masuk</span>
                      <span>Cuci</span>
                      <span>Kering</span>
                      <span>Selesai</span>
                      <span>Diambil</span>
                    </div>
                  </div>

                  {/* Customer Info Card */}
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs flex items-center justify-between">
                    <div>
                      <p className="font-bold text-slate-800">{customer?.name || 'Pelanggan Umum'}</p>
                      <p className="text-[11px] text-slate-500">{customer?.phone || '-'}</p>
                    </div>

                    {waUrl && (
                      <a
                        href={waUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors flex items-center gap-1 text-[11px] font-bold"
                        title="Kirim Update Status WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Kirim WA</span>
                      </a>
                    )}
                  </div>

                  {/* Assigned Staff & Service */}
                  <div className="text-xs space-y-1 text-slate-600 border-t border-slate-100 pt-3">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Layanan:</span>
                      <strong className="text-slate-900 font-bold">{latestTx?.serviceName || 'Cuci Reguler'}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Petugas Cuci:</span>
                      <strong className="text-purple-700 font-bold">{latestTx?.assignedStaffNames || 'Belum ditugaskan'}</strong>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Footer */}
                <div className="p-4 bg-slate-50 border-t border-slate-100 space-y-2.5">
                  {/* Advance button */}
                  {nextConfig ? (
                    <button
                      onClick={() => handleAdvanceStatus(vehicle.id, nextConfig.next)}
                      className={`w-full py-2.5 px-3 rounded-xl text-white font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer ${nextConfig.color}`}
                    >
                      <span>{nextConfig.label}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <div className="py-2.5 text-center text-xs font-bold text-slate-500 bg-slate-200/80 rounded-xl flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Kendaraan Sudah Diserahkan</span>
                    </div>
                  )}

                  {/* Secondary buttons: History & Receipt */}
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <button
                      onClick={() => onOpenQueueHistory(vehicle)}
                      className="text-slate-600 hover:text-slate-900 font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <History className="w-3.5 h-3.5 text-slate-400" />
                      <span>Log Riwayat</span>
                    </button>

                    {latestTx && (
                      <button
                        onClick={() => onOpenReceipt(latestTx)}
                        className="text-sky-700 hover:text-sky-800 font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Receipt className="w-3.5 h-3.5 text-sky-500" />
                        <span>Lihat Struk</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
