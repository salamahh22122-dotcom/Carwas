import React, { useState } from 'react';
import { Building2, UserPlus, Shield, Activity, Users, CheckCircle2, ArrowRight } from 'lucide-react';
import { User, Business, AuditLog } from '../types';
import { CarWashStorage } from '../data/storage';
import { CreateOwnerModal } from '../components/CreateOwnerModal';

interface MasterViewProps {
  storage: CarWashStorage;
  currentUser: User;
  businesses: Business[];
  users: User[];
  auditLogs: AuditLog[];
  onSwitchBusiness: (b: Business) => void;
}

export const MasterView: React.FC<MasterViewProps> = ({
  storage,
  currentUser,
  businesses,
  users,
  auditLogs,
  onSwitchBusiness,
}) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  if (currentUser.role !== 'MASTER') {
    return (
      <div className="bg-white p-12 text-center rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
        <Shield className="w-8 h-8 text-red-500 mx-auto" />
        <h3 className="font-extrabold text-slate-900 text-sm">Akses Ditolak</h3>
        <p className="text-xs text-slate-500">Hanya Master Administrator yang berhak mengelola akun Owner multi-cabang.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-1 rounded-lg bg-purple-50 text-purple-700 text-[10px] font-black uppercase tracking-wider border border-purple-200">
              Master Admin Control Center
            </span>
          </div>
          <h2 className="text-base font-extrabold text-slate-900 mt-2">Multi-Tenant Car Wash Management</h2>
          <p className="text-xs text-slate-500">
            Kelola pendaftaran Owner baru, unit usaha cabang, dan audit trail aktivitas seluruh sistem
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>+ Buat Akun Owner & Unit Usaha</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex items-center space-x-3.5">
          <div className="p-3 rounded-xl bg-purple-50 text-purple-700 border border-purple-100">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Unit Usaha Terdaftar</p>
            <p className="text-2xl font-black text-slate-900">{businesses.length} Bisnis</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex items-center space-x-3.5">
          <div className="p-3 rounded-xl bg-sky-50 text-sky-700 border border-sky-100">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Total Akun Sistem</p>
            <p className="text-2xl font-black text-slate-900">{users.length} Akun</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex items-center space-x-3.5">
          <div className="p-3 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-100">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Audit Trail Tercatat</p>
            <p className="text-2xl font-black text-slate-900">{auditLogs.length} Aktivitas</p>
          </div>
        </div>
      </div>

      {/* Businesses List */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Daftar Unit Usaha Car Wash Aktif</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {businesses.map(b => {
            const bUsers = users.filter(u => u.businessId === b.id);
            const ownerUser = bUsers.find(u => u.role === 'OWNER');

            return (
              <div
                key={b.id}
                className="p-5 rounded-xl border border-slate-200/90 bg-white shadow-xs space-y-4 flex flex-col justify-between hover:border-slate-300 transition-all"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h4 className="font-extrabold text-sm text-slate-900">{b.name}</h4>
                    <button
                      type="button"
                      onClick={() => storage.toggleBusinessStatus(b.id)}
                      className={`text-[10px] font-black px-2.5 py-1 rounded-full border cursor-pointer transition-all ${
                        b.status === 'ACTIVE'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-red-50 text-red-800 border-red-200 hover:bg-red-100'
                      }`}
                      title="Klik untuk ubah status aktif/suspend"
                    >
                      {b.status === 'ACTIVE' ? '● Aktif (Klik Suspend)' : '✕ Suspended (Klik Aktifkan)'}
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 font-medium">{b.address}</p>
                  <p className="text-[11px] text-slate-400">Owner: <strong className="text-slate-700">{ownerUser?.fullName || 'Belum diatur'}</strong></p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-medium">{bUsers.length} pengguna terhubung</span>
                  <button
                    onClick={() => onSwitchBusiness(b)}
                    className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>Masuk ke Unit Usaha</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Audit Trail Log */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Catatan Aktivitas Sistem (Audit Trail)</h3>
        <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
          {auditLogs.map(log => (
            <div key={log.id} className="py-2.5 flex items-center justify-between text-xs">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[10px] uppercase font-mono">
                    {log.action}
                  </span>
                  <span className="text-slate-600 font-medium">{log.details}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">Oleh: <strong>{log.performedBy}</strong></p>
              </div>

              <span className="text-[11px] text-slate-400 font-mono">
                {new Date(log.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>

      <CreateOwnerModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onConfirm={data => storage.createOwnerAndBusiness(data)}
      />
    </div>
  );
};
