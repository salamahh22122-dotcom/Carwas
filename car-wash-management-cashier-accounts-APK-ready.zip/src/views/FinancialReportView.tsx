import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  DollarSign,
  Users,
  Award,
  Calendar,
  Download,
  Receipt,
  Car,
  PieChart,
  ShieldAlert,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileSpreadsheet,
  Filter,
  Sparkles,
  Layers,
  CreditCard,
  UserCheck,
} from 'lucide-react';
import {
  User,
  Transaction,
  Employee,
  Service,
  Customer,
  Vehicle,
  Attendance,
  DatePeriodFilter,
} from '../types';
import { CarWashStorage } from '../data/storage';

interface FinancialReportViewProps {
  storage: CarWashStorage;
  currentUser: User;
  transactions: Transaction[];
  employees: Employee[];
  services: Service[];
  customers: Customer[];
  vehicles: Vehicle[];
  attendance?: Attendance[];
}

type ReportTabType = 'penjualan' | 'layanan' | 'kendaraan' | 'staff' | 'pembayaran' | 'bagi_hasil' | 'absensi';

export const FinancialReportView: React.FC<FinancialReportViewProps> = ({
  storage,
  currentUser,
  transactions,
  employees,
  services,
  customers,
  vehicles,
  attendance = [],
}) => {
  const [period, setPeriod] = useState<DatePeriodFilter>('THIS_MONTH');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [showCustomPicker, setShowCustomPicker] = useState(false);
  const [activeTab, setActiveTab] = useState<ReportTabType>('penjualan');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStaffFilter, setSelectedStaffFilter] = useState<string>('ALL');

  const canViewFinancials = storage.canViewFinancials(currentUser.role);

  // Filter transactions by period
  const filteredTxs = useMemo(() => {
    return storage.filterTransactionsByPeriod(transactions, period, customStart, customEnd);
  }, [storage, transactions, period, customStart, customEnd]);

  // Filter attendance by period
  const filteredAttendance = useMemo(() => {
    return storage.filterAttendanceByPeriod(attendance, period, customStart, customEnd);
  }, [storage, attendance, period, customStart, customEnd]);

  // Aggregate stats
  const totalGross = useMemo(() => {
    return filteredTxs.reduce((sum, t) => sum + t.servicePrice + (t.additionalAmount || 0), 0);
  }, [filteredTxs]);

  const totalDiscount = useMemo(() => {
    return filteredTxs.reduce((sum, t) => sum + (t.discountAmount || 0), 0);
  }, [filteredTxs]);

  const totalNet = useMemo(() => {
    return filteredTxs.reduce((sum, t) => sum + t.totalAmount, 0);
  }, [filteredTxs]);

  const totalOwnerShare = useMemo(() => {
    return filteredTxs.reduce((sum, t) => sum + t.ownerShareAmount, 0);
  }, [filteredTxs]);

  const totalStaffShare = useMemo(() => {
    return filteredTxs.reduce((sum, t) => sum + t.staffShareAmount, 0);
  }, [filteredTxs]);

  // 1. Staff profit report
  const staffReports = useMemo(() => {
    return storage.calculateStaffProfitReport(filteredTxs, employees);
  }, [storage, filteredTxs, employees]);

  // 2. Service popularity report
  const serviceReports = useMemo(() => {
    return storage.calculateServicePopularityReport(services, filteredTxs);
  }, [storage, services, filteredTxs]);

  // 3. Vehicle report
  const vehicleReports = useMemo(() => {
    return storage.calculateVehicleReport(vehicles, customers, filteredTxs);
  }, [storage, vehicles, customers, filteredTxs]);

  // 4. Payment breakdown
  const paymentBreakdown = useMemo(() => {
    const map: Record<string, { count: number; total: number }> = {};
    for (const tx of filteredTxs) {
      const pm = tx.paymentMethod || 'TUNAI';
      if (!map[pm]) {
        map[pm] = { count: 0, total: 0 };
      }
      map[pm].count += 1;
      map[pm].total += tx.totalAmount;
    }
    return map;
  }, [filteredTxs]);

  // 5. Transaction staff details list for Bagi Hasil audit
  const transactionStaffDetails = useMemo(() => {
    const allTs = storage.getTransactionStaffRecords();
    return filteredTxs.map(tx => {
      const staffList = allTs.filter(ts => ts.transactionId === tx.id);
      const veh = vehicles.find(v => v.id === tx.vehicleId);
      const cust = customers.find(c => c.id === tx.customerId);
      return {
        transaction: tx,
        vehicle: veh,
        customer: cust,
        staffDetails: staffList,
      };
    });
  }, [storage, filteredTxs, vehicles, customers]);

  // 6. Attendance summary per staff
  const staffAttendanceSummary = useMemo(() => {
    return employees.map(emp => {
      const empLogs = filteredAttendance.filter(a => a.employeeId === emp.id);
      const presentCount = empLogs.filter(a => a.status === 'PRESENT').length;
      const lateCount = empLogs.filter(a => a.status === 'LATE').length;
      const permitCount = empLogs.filter(a => a.status === 'PERMIT' || a.status === 'SICK').length;
      const totalAttended = presentCount + lateCount;
      const disciplineRate = empLogs.length > 0 ? (presentCount / empLogs.length) * 100 : 100;

      return {
        employee: emp,
        totalLogs: empLogs.length,
        presentCount,
        lateCount,
        permitCount,
        totalAttended,
        disciplineRate,
      };
    });
  }, [employees, filteredAttendance]);

  // Export CSV handler according to active tab
  const handleExportCSV = () => {
    let csvContent = '';
    const dateNow = new Date().toISOString().split('T')[0];

    if (activeTab === 'penjualan') {
      csvContent = 'No Invoice,Tanggal,Plat Nomor,Layanan,Harga Layanan,Tambahan,Diskon,Total Bayar,Metode,Staff Bertugas,Bagian Owner (Rp),Bagi Hasil Staff (Rp)\n';
      filteredTxs.forEach(tx => {
        const veh = vehicles.find(v => v.id === tx.vehicleId);
        const d = new Date(tx.createdAt).toLocaleDateString('id-ID');
        csvContent += `"${tx.invoiceNo}","${d}","${veh?.licensePlate || '-'}","${tx.serviceName}",${tx.servicePrice},${tx.additionalAmount || 0},${tx.discountAmount || 0},${tx.totalAmount},"${tx.paymentMethod}","${tx.assignedStaffNames}",${tx.ownerShareAmount},${tx.staffShareAmount}\n`;
      });
    } else if (activeTab === 'layanan') {
      csvContent = 'Nama Layanan,Kategori,Harga Standar,Frekuensi Dipesan,Mobil Unik,Total Omzet (Rp),Kontribusi (%)\n';
      serviceReports.forEach(s => {
        csvContent += `"${s.serviceName}","${s.category}",${s.price || 0},${s.useCount},${s.uniqueVehiclesCount},${s.totalRevenue},${s.revenueContributionPercentage.toFixed(2)}%\n`;
      });
    } else if (activeTab === 'kendaraan') {
      csvContent = 'Plat Nomor,Tipe,Merek Model,Warna,Pemilik,No HP,Frekuensi Cuci,Kunjungan Terakhir,Layanan Terakhir,Total Belanja (Rp)\n';
      vehicleReports.forEach(v => {
        const lastDate = v.lastVisitTimestamp ? new Date(v.lastVisitTimestamp).toLocaleDateString('id-ID') : '-';
        csvContent += `"${v.vehicle.licensePlate}","${v.vehicle.type}","${v.vehicle.brandModel}","${v.vehicle.color}","${v.customerName}","${v.customerPhone}",${v.totalVisits},"${lastDate}","${v.lastServiceName}",${v.totalSpent}\n`;
      });
    } else if (activeTab === 'staff') {
      csvContent = 'Nama Staff,Jabatan,Jumlah Kendaraan,Jumlah Layanan,Total Penjualan (Rp),Skema Komisi (%),Nominal Bagi Hasil Staff (Rp),Nominal Bagian Owner (Rp)\n';
      staffReports.forEach(st => {
        csvContent += `"${st.employeeName}","${st.position}",${st.vehicleCount},${st.serviceCount},${st.totalServiceSales},${st.snapshotPercentage}%,${st.totalStaffShare},${st.totalOwnerShare}\n`;
      });
    } else if (activeTab === 'pembayaran') {
      csvContent = 'Metode Pembayaran,Jumlah Transaksi,Total Nominal (Rp),Porsi Omzet (%)\n';
      Object.entries(paymentBreakdown).forEach(([method, rawVal]) => {
        const val = rawVal as { count: number; total: number };
        const pct = totalNet > 0 ? ((val.total / totalNet) * 100).toFixed(2) : '0';
        csvContent += `"${method}",${val.count},${val.total},${pct}%\n`;
      });
    } else if (activeTab === 'bagi_hasil') {
      csvContent = 'No Invoice,Tanggal,Plat Nomor,Total Transaksi (Rp),Staff,Persentase Tersimpan (%),Komisi Staff (Rp),Hak Owner (Rp)\n';
      filteredTxs.forEach(tx => {
        const veh = vehicles.find(v => v.id === tx.vehicleId);
        const d = new Date(tx.createdAt).toLocaleDateString('id-ID');
        csvContent += `"${tx.invoiceNo}","${d}","${veh?.licensePlate || '-'}","${tx.totalAmount}","${tx.assignedStaffNames}",${tx.staffShareAmount},${tx.ownerShareAmount}\n`;
      });
    } else if (activeTab === 'absensi') {
      csvContent = 'Nama Staff,Jabatan,Total Hadir,Terlambat,Izin/Sakit,Tingkat Kehadiran (%)\n';
      staffAttendanceSummary.forEach(att => {
        csvContent += `"${att.employee.name}","${att.employee.position}",${att.presentCount},${att.lateCount},${att.permitCount},${att.disciplineRate.toFixed(1)}%\n`;
      });
    }

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `Laporan_${activeTab.toUpperCase()}_CleanAuto_${period}_${dateNow}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // RBAC Gating: Non-owner / non-master cannot access financial reports
  if (!canViewFinancials) {
    return (
      <div className="bg-white p-12 text-center rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
        <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-extrabold text-slate-900">Akses Laporan Finansial & Bagi Hasil Terkunci</h2>
        <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
          Sesuai aturan keamanan bisnis, staf Kasir dan Karyawan umum <strong>TIDAK DIPERKENANKAN</strong> melihat
          persentase maupun nominal bagi hasil staf, omzet bersih, atau margin keuntungan Owner.
          Hanya peran <strong>Owner</strong> dan <strong>Master Administrator</strong> yang memiliki izin akses modul ini.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-extrabold text-slate-900">Pusat Laporan Bisnis & Bagi Hasil (Owner)</h2>
            <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 text-[10px] font-black uppercase tracking-wider">
              Khusus Owner / Master
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Analisis lengkap: Penjualan, Layanan, Kendaraan, Staff, Pembayaran, Audit Bagi Hasil, dan Absensi
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportCSV}
          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export Tab ({activeTab.replace('_', ' ').toUpperCase()}) CSV</span>
        </button>
      </div>

      {/* Period Filter Bar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-sky-600" />
          <span className="text-xs font-bold text-slate-900">Periode Laporan:</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'TODAY', label: 'Hari Ini' },
            { id: 'YESTERDAY', label: 'Kemarin' },
            { id: 'THIS_WEEK', label: 'Minggu Ini' },
            { id: 'THIS_MONTH', label: 'Bulan Ini' },
            { id: 'CUSTOM', label: 'Kustom Tanggal' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => {
                setPeriod(item.id as DatePeriodFilter);
                if (item.id === 'CUSTOM') setShowCustomPicker(true);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                period === item.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Custom Date Range Picker */}
      {showCustomPicker && period === 'CUSTOM' && (
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl flex flex-wrap items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Tanggal Mulai:</span>
            <input
              type="date"
              value={customStart}
              onChange={e => setCustomStart(e.target.value)}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-sky-500"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Tanggal Selesai:</span>
            <input
              type="date"
              value={customEnd}
              onChange={e => setCustomEnd(e.target.value)}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-sky-500"
            />
          </div>
          <button
            onClick={() => setShowCustomPicker(false)}
            className="px-4 py-1.5 bg-slate-900 text-white font-bold rounded-xl cursor-pointer hover:bg-slate-800"
          >
            Terapkan Filter
          </button>
        </div>
      )}

      {/* 7 Report Navigation Tabs */}
      <div className="flex items-center space-x-1.5 bg-white p-2 rounded-2xl border border-slate-200/90 shadow-xs overflow-x-auto">
        {[
          { id: 'penjualan', label: '1. Penjualan', icon: Receipt },
          { id: 'layanan', label: '2. Layanan', icon: Sparkles },
          { id: 'kendaraan', label: '3. Kendaraan', icon: Car },
          { id: 'staff', label: '4. Staff', icon: Users },
          { id: 'pembayaran', label: '5. Pembayaran', icon: CreditCard },
          { id: 'bagi_hasil', label: '6. Bagi Hasil Staff', icon: Award },
          { id: 'absensi', label: '7. Absensi', icon: UserCheck },
        ].map(t => {
          const Icon = t.icon;
          const isAct = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => {
                setActiveTab(t.id as ReportTabType);
                setSearchQuery('');
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                isAct
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* 1. LAPORAN PENJUALAN */}
      {/* ========================================================================= */}
      {activeTab === 'penjualan' && (
        <div className="space-y-4">
          {/* Executive KPI Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
              <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Total Penjualan Kotor</p>
              <p className="text-2xl font-black text-slate-900">Rp {totalGross.toLocaleString('id-ID')}</p>
              <p className="text-[11px] text-slate-500 font-medium">Sebelum potongan diskon</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
              <p className="text-xs text-red-600 font-bold uppercase tracking-wider">Potongan Diskon & Poin</p>
              <p className="text-2xl font-black text-red-600">-Rp {totalDiscount.toLocaleString('id-ID')}</p>
              <p className="text-[11px] text-slate-500 font-medium">{filteredTxs.filter(t => t.discountAmount > 0).length} transaksi terdiskon</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
              <p className="text-xs text-sky-700 font-bold uppercase tracking-wider">Omzet Penjualan Bersih</p>
              <p className="text-2xl font-black text-sky-700">Rp {totalNet.toLocaleString('id-ID')}</p>
              <p className="text-[11px] text-slate-500 font-medium">{filteredTxs.length} transaksi selesai</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
              <p className="text-xs text-emerald-700 font-bold uppercase tracking-wider">Hak Bersih Owner</p>
              <p className="text-2xl font-black text-emerald-700">Rp {totalOwnerShare.toLocaleString('id-ID')}</p>
              <p className="text-[11px] text-emerald-600 font-semibold">
                Komisi Staf: Rp {totalStaffShare.toLocaleString('id-ID')}
              </p>
            </div>
          </div>

          {/* Search bar & Table */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-slate-900">Rincian Seluruh Transaksi Penjualan</h3>
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Cari invoice, plat, layanan..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-sky-500"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="p-3">No. Invoice</th>
                    <th className="p-3">Waktu</th>
                    <th className="p-3">Plat & Mobil</th>
                    <th className="p-3">Layanan</th>
                    <th className="p-3 text-right">Diskon</th>
                    <th className="p-3 text-right">Total Bersih</th>
                    <th className="p-3 text-center">Metode</th>
                    <th className="p-3">Staff Bertugas</th>
                    <th className="p-3 text-right">Bagi Staff</th>
                    <th className="p-3 text-right">Hak Owner</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTxs
                    .filter(t => {
                      if (!searchQuery) return true;
                      const q = searchQuery.toLowerCase();
                      const veh = vehicles.find(v => v.id === t.vehicleId);
                      return (
                        t.invoiceNo.toLowerCase().includes(q) ||
                        t.serviceName.toLowerCase().includes(q) ||
                        t.assignedStaffNames.toLowerCase().includes(q) ||
                        (veh && veh.licensePlate.toLowerCase().includes(q))
                      );
                    })
                    .map(t => {
                      const veh = vehicles.find(v => v.id === t.vehicleId);
                      const timeStr = new Date(t.createdAt).toLocaleDateString('id-ID', {
                        day: '2-digit',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      });
                      return (
                        <tr key={t.id} className="hover:bg-slate-50/70">
                          <td className="p-3 font-mono font-bold text-sky-700">{t.invoiceNo}</td>
                          <td className="p-3 text-slate-500 text-[11px] whitespace-nowrap">{timeStr}</td>
                          <td className="p-3">
                            <span className="font-mono font-bold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded">
                              {veh?.licensePlate || '-'}
                            </span>
                            <span className="text-[11px] text-slate-500 block">{veh?.brandModel}</span>
                          </td>
                          <td className="p-3">
                            <span className="font-bold text-slate-800">{t.serviceName}</span>
                            {t.additionalAmount > 0 && (
                              <span className="text-[10px] text-slate-500 block">+ Addon Rp {t.additionalAmount.toLocaleString('id-ID')}</span>
                            )}
                          </td>
                          <td className="p-3 text-right text-red-600 font-semibold">
                            {t.discountAmount > 0 ? `-Rp ${t.discountAmount.toLocaleString('id-ID')}` : '-'}
                          </td>
                          <td className="p-3 text-right font-black text-slate-900">
                            Rp {t.totalAmount.toLocaleString('id-ID')}
                          </td>
                          <td className="p-3 text-center">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                              {t.paymentMethod}
                            </span>
                          </td>
                          <td className="p-3 text-slate-700 text-[11px] font-medium">{t.assignedStaffNames}</td>
                          <td className="p-3 text-right font-bold text-purple-700">
                            Rp {t.staffShareAmount.toLocaleString('id-ID')}
                          </td>
                          <td className="p-3 text-right font-black text-emerald-700">
                            Rp {t.ownerShareAmount.toLocaleString('id-ID')}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. LAPORAN LAYANAN */}
      {/* ========================================================================= */}
      {activeTab === 'layanan' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Performa & Popularitas Layanan Cuci</h3>
              <p className="text-xs text-slate-500">
                Analisis frekuensi pemesanan, jumlah unit kendaraan yang dilayani, dan kontribusi omzet tiap menu
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="p-3">Nama Layanan</th>
                    <th className="p-3">Kategori</th>
                    <th className="p-3 text-center">Frekuensi Dipesan</th>
                    <th className="p-3 text-center">Kendaraan Unik</th>
                    <th className="p-3 text-right">Total Pendapatan (Rp)</th>
                    <th className="p-3 text-right">Kontribusi Omzet</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {serviceReports.map(srv => (
                    <tr key={srv.serviceId} className="hover:bg-slate-50">
                      <td className="p-3">
                        <span className="font-bold text-slate-900 text-sm block">{srv.serviceName}</span>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-semibold text-[10px]">
                          {srv.category}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <span className="font-black text-sky-700 text-sm">{srv.useCount}x</span>
                      </td>
                      <td className="p-3 text-center font-bold text-slate-700">
                        {srv.uniqueVehiclesCount} Unit
                      </td>
                      <td className="p-3 text-right font-black text-slate-900">
                        Rp {srv.totalRevenue.toLocaleString('id-ID')}
                      </td>
                      <td className="p-3 text-right">
                        <span className="px-2 py-1 rounded-md bg-amber-50 text-amber-800 font-black border border-amber-200">
                          {srv.revenueContributionPercentage.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. LAPORAN KENDARAAN */}
      {/* ========================================================================= */}
      {activeTab === 'kendaraan' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Performa & Riwayat Kunjungan Kendaraan</h3>
                <p className="text-xs text-slate-500">
                  Data frekuensi kedatangan mobil/motor pelanggan, riwayat layanan, dan total belanja akumulatif
                </p>
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Cari plat, merek, nama pemilik..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-sky-500"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="p-3">Plat Nomor</th>
                    <th className="p-3">Tipe / Merek</th>
                    <th className="p-3">Nama Pemilik</th>
                    <th className="p-3">No. HP</th>
                    <th className="p-3 text-center">Kunjungan Cuci</th>
                    <th className="p-3">Kunjungan Terakhir</th>
                    <th className="p-3">Layanan Terakhir</th>
                    <th className="p-3 text-right">Total Belanja (Rp)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {vehicleReports
                    .filter(v => {
                      if (!searchQuery) return true;
                      const q = searchQuery.toLowerCase();
                      return (
                        v.vehicle.licensePlate.toLowerCase().includes(q) ||
                        v.vehicle.brandModel.toLowerCase().includes(q) ||
                        v.customerName.toLowerCase().includes(q) ||
                        v.customerPhone.includes(q)
                      );
                    })
                    .map(v => (
                      <tr key={v.vehicle.id} className="hover:bg-slate-50">
                        <td className="p-3">
                          <span className="font-mono font-black text-xs bg-slate-900 text-white px-2 py-0.5 rounded">
                            {v.vehicle.licensePlate}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="font-bold text-slate-800">{v.vehicle.brandModel}</span>
                          <span className="text-[10px] text-slate-500 block">{v.vehicle.type} • {v.vehicle.color}</span>
                        </td>
                        <td className="p-3 font-bold text-slate-900">{v.customerName}</td>
                        <td className="p-3 text-slate-500 font-mono text-[11px]">{v.customerPhone}</td>
                        <td className="p-3 text-center font-black text-sky-700">{v.totalVisits}x Datang</td>
                        <td className="p-3 text-slate-600 text-[11px]">
                          {v.lastVisitTimestamp ? new Date(v.lastVisitTimestamp).toLocaleDateString('id-ID') : '-'}
                        </td>
                        <td className="p-3 text-slate-700 font-medium">{v.lastServiceName}</td>
                        <td className="p-3 text-right font-black text-emerald-700">
                          Rp {v.totalSpent.toLocaleString('id-ID')}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. LAPORAN STAFF */}
      {/* ========================================================================= */}
      {activeTab === 'staff' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Produktivitas & Kontribusi Penjualan Tiap Staff</h3>
              <p className="text-xs text-slate-500">
                Owner dapat melihat jumlah layanan dan total penjualan setiap Staff serta nominal bagi hasilnya.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="p-3">Nama Staff</th>
                    <th className="p-3">Jabatan</th>
                    <th className="p-3 text-center">Mobil Dilayani</th>
                    <th className="p-3 text-center">Jumlah Layanan</th>
                    <th className="p-3 text-right">Total Penjualan Dihasilkan</th>
                    <th className="p-3 text-center">Skema Komisi (%)</th>
                    <th className="p-3 text-right">Nominal Bagi Hasil Staff</th>
                    <th className="p-3 text-right">Nominal Bagian Owner</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {staffReports.map(st => (
                    <tr key={st.employeeId} className="hover:bg-slate-50">
                      <td className="p-3 font-bold text-slate-900 text-sm">{st.employeeName}</td>
                      <td className="p-3 text-slate-500">{st.position}</td>
                      <td className="p-3 text-center font-bold text-slate-700">{st.vehicleCount} Kendaraan</td>
                      <td className="p-3 text-center font-black text-sky-700">{st.serviceCount}x Layanan</td>
                      <td className="p-3 text-right font-bold text-slate-900">
                        Rp {st.totalServiceSales.toLocaleString('id-ID')}
                      </td>
                      <td className="p-3 text-center">
                        <span className="px-2.5 py-1 rounded-md bg-purple-100 text-purple-800 font-black border border-purple-200">
                          {st.snapshotPercentage}%
                        </span>
                      </td>
                      <td className="p-3 text-right font-black text-purple-700 text-sm">
                        Rp {st.totalStaffShare.toLocaleString('id-ID')}
                      </td>
                      <td className="p-3 text-right font-black text-emerald-700 text-sm">
                        Rp {st.totalOwnerShare.toLocaleString('id-ID')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. LAPORAN PEMBAYARAN */}
      {/* ========================================================================= */}
      {activeTab === 'pembayaran' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Visual Breakdown */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Pangsa Metode Pembayaran</h3>
              <div className="space-y-3">
                {Object.entries(paymentBreakdown).map(([method, rawData]) => {
                  const data = rawData as { count: number; total: number };
                  const pct = totalNet > 0 ? (data.total / totalNet) * 100 : 0;
                  return (
                    <div key={method} className="space-y-1">
                      <div className="flex justify-between text-xs font-bold">
                        <span className="text-slate-800">{method}</span>
                        <span className="text-slate-900">Rp {data.total.toLocaleString('id-ID')} ({pct.toFixed(1)}%)</span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-sky-600 rounded-full transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Table Breakdown */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Detail Volume Transaksi per Metode</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                    <tr>
                      <th className="p-3">Metode</th>
                      <th className="p-3 text-center">Transaksi</th>
                      <th className="p-3 text-right">Total Nominal</th>
                      <th className="p-3 text-right">Rata-rata/Trx</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {Object.entries(paymentBreakdown).map(([method, rawData]) => {
                      const data = rawData as { count: number; total: number };
                      const avg = data.count > 0 ? Math.round(data.total / data.count) : 0;
                      return (
                        <tr key={method} className="hover:bg-slate-50">
                          <td className="p-3 font-bold text-slate-900">{method}</td>
                          <td className="p-3 text-center font-bold text-sky-700">{data.count}x</td>
                          <td className="p-3 text-right font-black text-slate-900">
                            Rp {data.total.toLocaleString('id-ID')}
                          </td>
                          <td className="p-3 text-right font-semibold text-slate-600">
                            Rp {avg.toLocaleString('id-ID')}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. LAPORAN BAGI HASIL STAFF (AUDIT HISTORIS) */}
      {/* ========================================================================= */}
      {activeTab === 'bagi_hasil' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900">Audit Transaksi Bagi Hasil Staff (Snapshot Historis)</h3>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black">
                    Integritas Terjamin
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Aturan bisnis: Menggunakan persentase yang tersimpan saat transaksi dibuat.
                  Jika persentase Staff diubah di masa depan, transaksi lama tidak ikut berubah.
                </p>
              </div>

              {/* Filter Staff */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-700">Filter Staff:</span>
                <select
                  value={selectedStaffFilter}
                  onChange={e => setSelectedStaffFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold focus:outline-sky-500"
                >
                  <option value="ALL">Semua Staff</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.name}>{emp.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="p-3">No. Invoice</th>
                    <th className="p-3">Tanggal Transaksi</th>
                    <th className="p-3">Plat Nomor</th>
                    <th className="p-3 text-right">Nilai Transaksi (Rp)</th>
                    <th className="p-3">Staff Bertugas</th>
                    <th className="p-3 text-center">Persentase Tersimpan Saat Transaksi</th>
                    <th className="p-3 text-right">Hak Komisi Staff (Rp)</th>
                    <th className="p-3 text-right">Hak Bersih Owner (Rp)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactionStaffDetails
                    .filter(item => {
                      if (selectedStaffFilter === 'ALL') return true;
                      return item.transaction.assignedStaffNames.toLowerCase().includes(selectedStaffFilter.toLowerCase());
                    })
                    .map(item => {
                      const tx = item.transaction;
                      const dateStr = new Date(tx.createdAt).toLocaleDateString('id-ID', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      });
                      const storedPercentageStr = item.staffDetails.length > 0
                        ? item.staffDetails.map(sd => `${sd.employeeName} (${sd.profitPercentage}%)`).join(', ')
                        : `${tx.assignedStaffNames} (${(tx.totalAmount > 0 ? (tx.staffShareAmount / tx.totalAmount) * 100 : 0).toFixed(0)}%)`;

                      return (
                        <tr key={tx.id} className="hover:bg-slate-50">
                          <td className="p-3 font-mono font-bold text-sky-700">{tx.invoiceNo}</td>
                          <td className="p-3 text-slate-500 text-[11px] whitespace-nowrap">{dateStr}</td>
                          <td className="p-3">
                            <span className="font-mono font-bold bg-slate-100 px-1.5 py-0.5 rounded text-slate-900">
                              {item.vehicle?.licensePlate || '-'}
                            </span>
                          </td>
                          <td className="p-3 text-right font-black text-slate-900">
                            Rp {tx.totalAmount.toLocaleString('id-ID')}
                          </td>
                          <td className="p-3 text-slate-700 font-semibold">{tx.assignedStaffNames}</td>
                          <td className="p-3 text-center">
                            <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 font-black text-[11px] border border-purple-200">
                              {storedPercentageStr}
                            </span>
                          </td>
                          <td className="p-3 text-right font-black text-purple-700 text-sm">
                            Rp {tx.staffShareAmount.toLocaleString('id-ID')}
                          </td>
                          <td className="p-3 text-right font-black text-emerald-700 text-sm">
                            Rp {tx.ownerShareAmount.toLocaleString('id-ID')}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. LAPORAN ABSENSI */}
      {/* ========================================================================= */}
      {activeTab === 'absensi' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Rekap Kehadiran & Jam Kerja Staff (Per Periode)</h3>
              <p className="text-xs text-slate-500">
                Owner dapat memantau kedisiplinan check-in / check-out seluruh staf dalam rentang tanggal terpilih
              </p>
            </div>

            {/* Rekap Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="p-3">Nama Staff</th>
                    <th className="p-3">Jabatan</th>
                    <th className="p-3 text-center">Total Presensi</th>
                    <th className="p-3 text-center">Hadir Tepat Waktu</th>
                    <th className="p-3 text-center">Terlambat</th>
                    <th className="p-3 text-center">Izin / Sakit</th>
                    <th className="p-3 text-right">Tingkat Kehadiran (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {staffAttendanceSummary.map(att => (
                    <tr key={att.employee.id} className="hover:bg-slate-50">
                      <td className="p-3 font-bold text-slate-900 text-sm">{att.employee.name}</td>
                      <td className="p-3 text-slate-500">{att.employee.position}</td>
                      <td className="p-3 text-center font-bold text-slate-700">{att.totalLogs} Hari</td>
                      <td className="p-3 text-center font-bold text-emerald-600">{att.presentCount}x Hadir</td>
                      <td className="p-3 text-center font-bold text-amber-600">{att.lateCount}x Terlambat</td>
                      <td className="p-3 text-center font-bold text-purple-600">{att.permitCount}x Izin</td>
                      <td className="p-3 text-right font-black">
                        <span className={`px-2.5 py-1 rounded-md text-xs font-black ${
                          att.disciplineRate >= 90
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {att.disciplineRate.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Detailed Attendance Logs for Period */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Log Detail Presensi Harian</h4>
            <div className="divide-y divide-slate-100">
              {filteredAttendance.length === 0 ? (
                <p className="text-xs text-slate-400 py-3 text-center italic">Tidak ada rekaman presensi pada periode ini.</p>
              ) : (
                filteredAttendance.map(log => {
                  const emp = employees.find(e => e.id === log.employeeId);
                  return (
                    <div key={log.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-slate-900">{emp?.name || 'Staff'}</span>
                        <span className="text-slate-400 text-[11px] ml-2 font-mono">{log.date}</span>
                        {log.notes && <p className="text-[11px] text-slate-500 italic mt-0.5">{log.notes}</p>}
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-[11px] text-slate-600">
                          Masuk: <strong>{log.checkInTime || '-'}</strong> • Pulang: <strong>{log.checkOutTime || '-'}</strong>
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                          log.status === 'PRESENT'
                            ? 'bg-emerald-100 text-emerald-800'
                            : log.status === 'LATE'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {log.status === 'PRESENT' ? 'Hadir' : log.status === 'LATE' ? 'Terlambat' : 'Izin'}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
