import React, { useState, useMemo } from 'react';
import {
  Receipt,
  Car,
  Search,
  Plus,
  Check,
  Percent,
  Sparkles,
  Lock,
  Users,
  CreditCard,
  Banknote,
  QrCode,
  AlertCircle,
  Clock,
  History,
  Tag,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import {
  Customer,
  Vehicle,
  Service,
  Employee,
  AdditionalOption,
  DEFAULT_ADDITIONAL_SERVICES,
  Transaction,
  CustomerMembership,
  PointRule,
} from '../types';
import { CarWashStorage } from '../data/storage';

interface PosViewProps {
  storage: CarWashStorage;
  customers: Customer[];
  vehicles: Vehicle[];
  services: Service[];
  employees: Employee[];
  transactions: Transaction[];
  customerMemberships: CustomerMembership[];
  pointRule: PointRule | null;
  canViewProfit: boolean;
  onOpenQuickCustomer: () => void;
  onOpenReceipt: (tx: Transaction) => void;
}

export const PosView: React.FC<PosViewProps> = ({
  storage,
  customers,
  vehicles,
  services,
  employees,
  transactions,
  customerMemberships,
  pointRule,
  canViewProfit,
  onOpenQuickCustomer,
  onOpenReceipt,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'create' | 'history'>('create');
  const [searchHistoryQuery, setSearchHistoryQuery] = useState('');

  // POS Form State
  const [searchPlate, setSearchPlate] = useState('');
  const [vehicleTypeFilter, setVehicleTypeFilter] = useState<'ALL' | 'CAR' | 'MOTORCYCLE'>('ALL');
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(vehicles[0] || null);
  const [selectedService, setSelectedService] = useState<Service | null>(
    services.find(s => s.isActive) || services[0] || null
  );
  const [selectedStaff, setSelectedStaff] = useState<Employee[]>(
    employees.filter(e => e.status === 'ACTIVE').slice(0, 1)
  );
  const [selectedAddons, setSelectedAddons] = useState<AdditionalOption[]>([]);
  const [discountInput, setDiscountInput] = useState('0');
  const [useMembershipQuota, setUseMembershipQuota] = useState(false);
  const [pointsToRedeem, setPointsToRedeem] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('QRIS');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  // Matching vehicles based on plate search & filter
  const matchingVehicles = useMemo(() => {
    let list = vehicles;
    if (vehicleTypeFilter !== 'ALL') {
      list = list.filter(v => v.type === vehicleTypeFilter);
    }
    if (!searchPlate.trim()) return list.slice(0, 6);
    const q = searchPlate.trim().toLowerCase();
    return list.filter(
      v => v.licensePlate.toLowerCase().includes(q) || v.brandModel.toLowerCase().includes(q)
    );
  }, [searchPlate, vehicleTypeFilter, vehicles]);

  const currentCustomer = useMemo(() => {
    if (!selectedVehicle) return null;
    return customers.find(c => c.id === selectedVehicle.customerId) || null;
  }, [selectedVehicle, customers]);

  const activeMembership = useMemo(() => {
    if (!currentCustomer) return null;
    const now = Date.now();
    return customerMemberships.find(
      m => m.customerId === currentCustomer.id && m.remainingQuota > 0 && m.expiresAt > now
    );
  }, [currentCustomer, customerMemberships]);

  // Pricing calculations
  const servicePrice = selectedService?.price || 0;
  const addonsTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
  const manualDiscount = parseFloat(discountInput) || 0;
  const pointRate = pointRule?.pointRedeemValue || 1000;
  const pointDiscount = pointRule?.isEnabled ? pointsToRedeem * pointRate : 0;
  const membershipDiscount = useMembershipQuota && activeMembership ? servicePrice : 0;
  const totalDiscount = Math.min(servicePrice + addonsTotal, manualDiscount + pointDiscount + membershipDiscount);
  const finalTotal = Math.max(0, servicePrice + addonsTotal - totalDiscount);

  // Profit sharing preview for owner/master
  const staffPortion = selectedStaff.length > 0 ? finalTotal / selectedStaff.length : 0;
  const totalStaffShare = selectedStaff.reduce((sum, emp) => {
    return sum + (staffPortion * emp.currentProfitPercentage) / 100.0;
  }, 0);
  const ownerShare = Math.max(0, finalTotal - totalStaffShare);

  const toggleStaff = (emp: Employee) => {
    if (selectedStaff.some(e => e.id === emp.id)) {
      setSelectedStaff(selectedStaff.filter(e => e.id !== emp.id));
    } else {
      setSelectedStaff([...selectedStaff, emp]);
    }
  };

  const toggleAddon = (opt: AdditionalOption) => {
    if (selectedAddons.some(a => a.id === opt.id)) {
      setSelectedAddons(selectedAddons.filter(a => a.id !== opt.id));
    } else {
      setSelectedAddons([...selectedAddons, opt]);
    }
  };

  const handleProcessTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVehicle || !currentCustomer) {
      setFormError('Pilih kendaraan & pelanggan terlebih dahulu.');
      return;
    }
    if (!selectedService) {
      setFormError('Pilih layanan pokok cuci.');
      return;
    }
    if (selectedStaff.length === 0) {
      setFormError('Kasir WAJIB memilih minimal 1 Staf / Petugas yang mengerjakan!');
      return;
    }

    setFormError(null);
    const res = storage.createTransaction({
      customerId: currentCustomer.id,
      vehicleId: selectedVehicle.id,
      service: selectedService,
      assignedStaff: selectedStaff,
      additionalItems: selectedAddons,
      discountAmount: totalDiscount,
      paymentMethod,
      notes: notes.trim(),
      usedMembershipId: useMembershipQuota ? activeMembership?.id : null,
      pointsToRedeem: pointsToRedeem > 0 ? pointsToRedeem : undefined,
    });

    if (res.success && res.transaction) {
      onOpenReceipt(res.transaction);
      // Reset form
      setSelectedAddons([]);
      setDiscountInput('0');
      setNotes('');
      setUseMembershipQuota(false);
      setPointsToRedeem(0);
    }
  };

  // Filter transaction history
  const filteredHistory = useMemo(() => {
    if (!searchHistoryQuery.trim()) return transactions;
    const q = searchHistoryQuery.trim().toLowerCase();
    return transactions.filter(
      t =>
        t.invoiceNo.toLowerCase().includes(q) ||
        t.serviceName.toLowerCase().includes(q) ||
        t.assignedStaffNames.toLowerCase().includes(q) ||
        t.paymentMethod.toLowerCase().includes(q)
    );
  }, [searchHistoryQuery, transactions]);

  return (
    <div className="space-y-6 pb-12">
      {/* Subtab Bar */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-200 bg-white p-2.5 rounded-2xl shadow-xs gap-3">
        <div className="flex items-center space-x-1.5">
          <button
            type="button"
            id="pos_tab_create"
            onClick={() => setActiveSubTab('create')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeSubTab === 'create'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Kasir POS Baru</span>
          </button>
          <button
            type="button"
            id="pos_tab_history"
            onClick={() => setActiveSubTab('history')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeSubTab === 'history'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Riwayat Transaksi</span>
            <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 text-slate-800">
              {transactions.length}
            </span>
          </button>
        </div>

        {!canViewProfit && (
          <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>Persentase Komisi Staf Dirahasiakan</span>
          </div>
        )}
      </div>

      {activeSubTab === 'create' ? (
        <form onSubmit={handleProcessTransaction} className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          {/* LEFT 2 COLUMNS: CONFIGURATION STEPS */}
          <div className="lg:col-span-2 space-y-5">
            {formError && (
              <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* 1. KENDARAAN & PELANGGAN */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-sky-100 text-sky-700 font-black text-xs flex items-center justify-center">
                    1
                  </span>
                  <h3 className="text-sm font-bold text-slate-900">
                    Pilih Kendaraan & Pelanggan
                  </h3>
                </div>
                <button
                  type="button"
                  id="pos_btn_quick_add_customer"
                  onClick={onOpenQuickCustomer}
                  className="text-xs font-bold text-sky-700 hover:text-sky-800 bg-sky-50 hover:bg-sky-100 px-3 py-1.5 rounded-xl border border-sky-200 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Tambah Cepat Mobil Baru</span>
                </button>
              </div>

              {/* Search & Type Filter */}
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={searchPlate}
                    onChange={e => setSearchPlate(e.target.value.toUpperCase())}
                    placeholder="Cari Plat Nomor (contoh: B 1234 ABC)..."
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl font-medium focus:outline-sky-500"
                  />
                </div>
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  {[
                    { id: 'ALL', label: 'Semua' },
                    { id: 'CAR', label: 'Mobil' },
                    { id: 'MOTORCYCLE', label: 'Motor' },
                  ].map(t => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setVehicleTypeFilter(t.id as any)}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        vehicleTypeFilter === t.id
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Vehicles Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {matchingVehicles.map(veh => {
                  const owner = customers.find(c => c.id === veh.customerId);
                  const isSelected = selectedVehicle?.id === veh.id;
                  return (
                    <div
                      key={veh.id}
                      onClick={() => {
                        setSelectedVehicle(veh);
                        setFormError(null);
                      }}
                      className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all ${
                        isSelected
                          ? 'border-sky-600 bg-sky-50/70 shadow-xs ring-1 ring-sky-600'
                          : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-black text-xs tracking-wider bg-slate-900 text-white px-2.5 py-1 rounded-md">
                          {veh.licensePlate}
                        </span>
                        {isSelected && (
                          <span className="px-2 py-0.5 rounded-md bg-sky-600 text-white font-bold text-[10px] flex items-center gap-1">
                            <Check className="w-3 h-3" /> Terpilih
                          </span>
                        )}
                      </div>
                      <p className="text-slate-900 font-bold truncate mt-2">
                        {veh.brandModel}
                      </p>
                      <div className="flex items-center justify-between text-slate-500 text-[11px] mt-1">
                        <span>Warna: {veh.color}</span>
                        <span className="font-medium text-slate-700">
                          {owner?.name || 'Pelanggan Umum'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 2. LAYANAN POKOK */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-sky-100 text-sky-700 font-black text-xs flex items-center justify-center">
                  2
                </span>
                <h3 className="text-sm font-bold text-slate-900">
                  Pilihan Layanan Pokok
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {services
                  .filter(s => s.isActive)
                  .map(srv => {
                    const isSelected = selectedService?.id === srv.id;
                    return (
                      <div
                        key={srv.id}
                        onClick={() => {
                          setSelectedService(srv);
                          setFormError(null);
                        }}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'border-sky-600 bg-sky-50/70 shadow-xs ring-1 ring-sky-600'
                            : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-bold text-xs text-slate-900">{srv.name}</p>
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              {srv.category} • ~{srv.estimatedDurationMinutes} menit
                            </p>
                          </div>
                          <span className="text-xs font-black text-slate-900">
                            Rp {srv.price.toLocaleString('id-ID')}
                          </span>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* 3. TAMBAHAN LAYANAN EKSTRA */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-sky-100 text-sky-700 font-black text-xs flex items-center justify-center">
                    3
                  </span>
                  <h3 className="text-sm font-bold text-slate-900">
                    Tambahan Layanan Ekstra (Opsional)
                  </h3>
                </div>
                {selectedAddons.length > 0 && (
                  <span className="text-xs font-bold text-sky-700">
                    {selectedAddons.length} opsi dipilih
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {DEFAULT_ADDITIONAL_SERVICES.map(opt => {
                  const isChecked = selectedAddons.some(a => a.id === opt.id);
                  return (
                    <label
                      key={opt.id}
                      className={`flex items-center justify-between p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        isChecked
                          ? 'border-sky-600 bg-sky-50/70 text-slate-900 font-bold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleAddon(opt)}
                          className="rounded-md text-sky-600 focus:ring-sky-500 w-4 h-4 cursor-pointer"
                        />
                        <span>{opt.name}</span>
                      </div>
                      <span className="font-extrabold text-[11px] text-slate-900">
                        +Rp {opt.price.toLocaleString('id-ID')}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* 4. DISKON, MEMBERSHIP & POIN */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-sky-100 text-sky-700 font-black text-xs flex items-center justify-center">
                  4
                </span>
                <h3 className="text-sm font-bold text-slate-900">
                  Diskon, Kuota Member & Poin Loyalitas
                </h3>
              </div>

              {/* Membership Quota Toggle */}
              {activeMembership && (
                <div
                  onClick={() => setUseMembershipQuota(!useMembershipQuota)}
                  className={`p-3.5 rounded-xl border cursor-pointer flex items-center justify-between transition-all ${
                    useMembershipQuota
                      ? 'bg-emerald-50/80 border-emerald-400'
                      : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={useMembershipQuota}
                      onChange={() => setUseMembershipQuota(!useMembershipQuota)}
                      className="rounded-md text-emerald-600 w-4 h-4"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900">Pakai Kuota Paket Membership</span>
                      <p className="text-[11px] text-emerald-700 font-medium">
                        {activeMembership.packageName} (Tersisa {activeMembership.remainingQuota}x cuci gratis)
                      </p>
                    </div>
                  </div>
                  {useMembershipQuota && (
                    <span className="text-xs font-black text-emerald-700">
                      -Rp {servicePrice.toLocaleString('id-ID')}
                    </span>
                  )}
                </div>
              )}

              {/* Points Redemption */}
              {currentCustomer && currentCustomer.pointsBalance > 0 && pointRule?.isEnabled && (
                <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-amber-900">
                      Poin Reward Pelanggan: {currentCustomer.pointsBalance} Poin
                    </span>
                    <p className="text-[11px] text-amber-700">
                      1 Poin bernilai diskon Rp {pointRate.toLocaleString('id-ID')}
                    </p>
                  </div>
                  <select
                    value={pointsToRedeem}
                    onChange={e => setPointsToRedeem(Number(e.target.value))}
                    className="px-3 py-1.5 bg-white border border-amber-300 rounded-xl text-xs font-bold text-amber-900 focus:outline-hidden"
                  >
                    <option value={0}>Jangan Tukar Poin</option>
                    {currentCustomer.pointsBalance >= 5 && <option value={5}>5 Poin (-Rp 5.000)</option>}
                    {currentCustomer.pointsBalance >= 10 && <option value={10}>10 Poin (-Rp 10.000)</option>}
                    <option value={currentCustomer.pointsBalance}>
                      Tukar Semua ({currentCustomer.pointsBalance} Poin)
                    </option>
                  </select>
                </div>
              )}

              {/* Manual Discount */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <div className="w-full sm:w-1/2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Diskon Manual (Rp)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={discountInput}
                    onChange={e => setDiscountInput(e.target.value)}
                    placeholder="0"
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl font-bold focus:outline-sky-500"
                  />
                </div>
                <div className="w-full sm:w-1/2 flex items-end gap-1.5 pt-1 sm:pt-5">
                  {['0', '5000', '10000', '20000'].map(d => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDiscountInput(d)}
                      className={`px-3 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                        discountInput === d
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                      }`}
                    >
                      {d === '0' ? 'Nol' : `${parseInt(d) / 1000}k`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* 5. STAFF YANG MENGERJAKAN (MANDATORY) */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-sky-100 text-sky-700 font-black text-xs flex items-center justify-center">
                    5
                  </span>
                  <h3 className="text-sm font-bold text-slate-900">
                    Staf / Petugas yang Bertugas <span className="text-red-600 font-bold">*Wajib</span>
                  </h3>
                </div>
                {!canViewProfit && (
                  <span className="text-xs text-slate-500 flex items-center gap-1 bg-slate-100 px-2.5 py-1 rounded-lg">
                    <Lock className="w-3 h-3 text-slate-400" /> Komisi dirahasiakan
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {employees
                  .filter(e => e.status === 'ACTIVE')
                  .map(emp => {
                    const isChecked = selectedStaff.some(e => e.id === emp.id);
                    return (
                      <div
                        key={emp.id}
                        onClick={() => toggleStaff(emp)}
                        className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                          isChecked
                            ? 'border-sky-600 bg-sky-50/70 shadow-xs ring-1 ring-sky-600'
                            : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleStaff(emp)}
                            className="rounded-md text-sky-600 w-4 h-4 cursor-pointer"
                          />
                          <div>
                            <p className="font-bold text-slate-900">{emp.name}</p>
                            <p className="text-[11px] text-slate-500">{emp.position}</p>
                          </div>
                        </div>

                        {canViewProfit ? (
                          <span className="text-[11px] font-bold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-200">
                            {emp.currentProfitPercentage}% Komisi
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-500 font-medium">Ditugaskan</span>
                        )}
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: TICKET CHECKOUT SUMMARY */}
          <div className="space-y-5 lg:sticky lg:top-20">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Metode Pembayaran
              </h3>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'QRIS', label: 'QRIS', icon: QrCode },
                  { id: 'CASH', label: 'Tunai', icon: Banknote },
                  { id: 'TRANSFER', label: 'Transfer', icon: CreditCard },
                  { id: 'MEMBERSHIP', label: 'Member', icon: Sparkles },
                ].map(item => {
                  const Icon = item.icon;
                  const isSel = paymentMethod === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setPaymentMethod(item.id)}
                      className={`p-3 rounded-xl border flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        isSel
                          ? 'border-slate-900 bg-slate-900 text-white font-bold shadow-xs'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-xs font-bold">{item.label}</span>
                    </button>
                  );
                })}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Catatan Transaksi (Opsional)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Misal: Titip kunci, minta semir ban tebal..."
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-sky-500 font-medium"
                />
              </div>

              {/* High-Contrast Order Ticket Box */}
              <div className="p-4 rounded-xl bg-slate-900 text-white space-y-2.5">
                <div className="border-b border-slate-800 pb-2 flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Kendaraan:</span>
                  <span className="font-mono font-bold bg-slate-800 text-sky-400 px-2 py-0.5 rounded">
                    {selectedVehicle?.licensePlate || '-'}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-slate-300">
                  <span>{selectedService?.name || 'Layanan'}:</span>
                  <span className="font-bold">Rp {servicePrice.toLocaleString('id-ID')}</span>
                </div>

                {addonsTotal > 0 && (
                  <div className="flex justify-between text-xs text-slate-300">
                    <span>Tambahan ({selectedAddons.length}x):</span>
                    <span className="font-bold">+Rp {addonsTotal.toLocaleString('id-ID')}</span>
                  </div>
                )}

                {totalDiscount > 0 && (
                  <div className="flex justify-between text-xs text-red-400 font-bold">
                    <span>Total Diskon:</span>
                    <span>-Rp {totalDiscount.toLocaleString('id-ID')}</span>
                  </div>
                )}

                <div className="pt-2.5 border-t border-slate-800 flex justify-between items-baseline">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    TOTAL AKHIR:
                  </span>
                  <span className="text-2xl font-black text-sky-400">
                    Rp {finalTotal.toLocaleString('id-ID')}
                  </span>
                </div>

                {canViewProfit && selectedStaff.length > 0 && (
                  <div className="pt-2 border-t border-slate-800 text-[11px] space-y-1 text-slate-400 font-medium">
                    <div className="flex justify-between text-emerald-400">
                      <span>Hak Bersih Owner:</span>
                      <span className="font-bold">Rp {ownerShare.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-purple-400">
                      <span>Komisi Staf ({selectedStaff.length} orang):</span>
                      <span className="font-bold">Rp {totalStaffShare.toLocaleString('id-ID')}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Submit CTA Button */}
              <button
                type="submit"
                id="btn_process_pos_page"
                className="w-full py-3.5 bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-sm rounded-xl transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Receipt className="w-4 h-4" />
                <span>PROSES & SIMPAN TRANSAKSI</span>
              </button>
            </div>
          </div>
        </form>
      ) : (
        /* TRANSACTIONS HISTORY VIEW */
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Riwayat Transaksi Kasir</h3>
              <p className="text-xs text-slate-500">Klik transaksi untuk melihat dan mencetak struk digital</p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchHistoryQuery}
                onChange={e => setSearchHistoryQuery(e.target.value)}
                placeholder="Cari invoice, plat, kasir..."
                className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-sky-500"
              />
            </div>
          </div>

          {filteredHistory.length === 0 ? (
            <p className="text-center text-xs text-slate-400 py-12">Tidak ada transaksi ditemukan.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredHistory.map(tx => {
                const cust = customers.find(c => c.id === tx.customerId);
                const veh = vehicles.find(v => v.id === tx.vehicleId);
                const dateStr = new Date(tx.createdAt).toLocaleString('id-ID', {
                  day: 'numeric',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={tx.id}
                    onClick={() => onOpenReceipt(tx)}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-50 px-2 rounded-xl transition-colors cursor-pointer"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center font-black text-sm border border-sky-100">
                        #{tx.queueNumber}
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-extrabold text-xs text-slate-900">{tx.invoiceNo}</span>
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 uppercase">
                            {tx.paymentMethod}
                          </span>
                          <span className="text-[11px] text-slate-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {dateStr}
                          </span>
                        </div>
                        <p className="text-xs text-slate-800 font-bold mt-0.5">
                          {veh?.licensePlate || '-'} • {tx.serviceName}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          Pelanggan: {cust?.name || 'Umum'} • Staf: {tx.assignedStaffNames || '-'} • Kasir: {tx.cashierName}
                        </p>
                      </div>
                    </div>

                    <div className="text-right sm:self-center">
                      <span className="text-sm font-black text-slate-900">
                        Rp {tx.totalAmount.toLocaleString('id-ID')}
                      </span>
                      {canViewProfit && (
                        <p className="text-[10px] text-emerald-700 font-bold mt-0.5">
                          Owner: Rp {tx.ownerShareAmount.toLocaleString('id-ID')} | Staf: Rp {tx.staffShareAmount.toLocaleString('id-ID')}
                        </p>
                      )}
                      <p className="text-[11px] text-sky-700 font-bold hover:underline mt-0.5">
                        Lihat & Cetak Struk →
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
