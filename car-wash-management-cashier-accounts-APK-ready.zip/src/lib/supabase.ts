import { createClient } from '@supabase/supabase-js';

const supabaseUrl =
  import.meta.env.VITE_SUPABASE_URL || 'https://ukavxclgnthzwewvozgl.supabase.co';
const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVrYXZ4Y2xnbnRoendld3ZvemdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg3OTI0MzksImV4cCI6MjEwNDM2ODQzOX0.F8Ru-TUb9Zq-CCKlw9exWMt2wB8ruKOvOI83W3lYKRk';

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export async function checkSupabaseConnection(): Promise<{
  connected: boolean;
  message: string;
  tablesFound?: string[];
  latencyMs?: number;
}> {
  if (!isSupabaseConfigured) {
    return { connected: false, message: 'Supabase URL atau Anon Key belum dikonfigurasi.' };
  }

  const start = Date.now();
  try {
    // Try pinging Supabase REST API
    const response = await fetch(`${supabaseUrl}/rest/v1/`, {
      method: 'GET',
      headers: {
        apikey: supabaseAnonKey,
        Authorization: `Bearer ${supabaseAnonKey}`,
      },
    });

    const latency = Date.now() - start;

    if (response.ok) {
      const data = await response.json();
      const tableNames = data?.definitions ? Object.keys(data.definitions) : [];
      return {
        connected: true,
        message: `Terhubung dengan sukses ke Supabase (${latency}ms)`,
        tablesFound: tableNames,
        latencyMs: latency,
      };
    } else {
      return {
        connected: false,
        message: `Supabase merespons dengan status ${response.status}: ${response.statusText}`,
        latencyMs: latency,
      };
    }
  } catch (error: any) {
    return {
      connected: false,
      message: `Gagal menghubungi Supabase: ${error?.message || error}`,
    };
  }
}

// SQL Schema for users to run in their Supabase SQL editor
export const SUPABASE_SQL_SCHEMA = `-- SKEMA TABEL LENGKAP SISTEM CAR WASH UNTUK SUPABASE
-- Jalankan skrip ini di SQL Editor Supabase Anda (https://supabase.com/dashboard/project/ukavxclgnthzwewvozgl/sql)

-- 1. Businesses (Usaha / Cabang)
CREATE TABLE IF NOT EXISTS public.businesses (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  logo_url TEXT,
  owner_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Users (Pengguna Sistem & Role)
CREATE TABLE IF NOT EXISTS public.users (
  id BIGSERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('MASTER', 'OWNER', 'ADMIN', 'KASIR', 'STAFF')),
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE SET NULL,
  is_active BOOLEAN DEFAULT TRUE,
  is_permanent_master BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Employees (Staff & Karyawan)
CREATE TABLE IF NOT EXISTS public.employees (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE CASCADE,
  user_id BIGINT REFERENCES public.users(id) ON DELETE SET NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  role TEXT NOT NULL,
  commission_percentage NUMERIC DEFAULT 0,
  daily_salary NUMERIC DEFAULT 0,
  monthly_salary NUMERIC DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  join_date TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Staff Profit Settings (Konfigurasi Bagi Hasil)
CREATE TABLE IF NOT EXISTS public.staff_profit_settings (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE CASCADE,
  employee_id BIGINT REFERENCES public.employees(id) ON DELETE CASCADE,
  service_id BIGINT,
  profit_type TEXT NOT NULL CHECK (profit_type IN ('PERCENTAGE', 'FIXED_AMOUNT')),
  profit_value NUMERIC NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Services (Katalog Layanan & Tarif Cuci)
CREATE TABLE IF NOT EXISTS public.services (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  vehicle_type TEXT NOT NULL CHECK (vehicle_type IN ('MOBIL', 'MOTOR')),
  vehicle_size TEXT NOT NULL CHECK (vehicle_size IN ('KECIL', 'SEDANG', 'BESAR', 'MEWAH')),
  price NUMERIC NOT NULL,
  estimated_minutes INTEGER DEFAULT 30,
  staff_commission NUMERIC DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Customers (Pelanggan)
CREATE TABLE IF NOT EXISTS public.customers (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT,
  points INTEGER DEFAULT 0,
  total_spend NUMERIC DEFAULT 0,
  visit_count INTEGER DEFAULT 0,
  membership_type TEXT DEFAULT 'REGULER',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Vehicles (Kendaraan Pelanggan)
CREATE TABLE IF NOT EXISTS public.vehicles (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE CASCADE,
  customer_id BIGINT REFERENCES public.customers(id) ON DELETE CASCADE,
  plate_number TEXT NOT NULL,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  color TEXT,
  vehicle_type TEXT NOT NULL CHECK (vehicle_type IN ('MOBIL', 'MOTOR')),
  vehicle_size TEXT NOT NULL CHECK (vehicle_size IN ('KECIL', 'SEDANG', 'BESAR', 'MEWAH')),
  wash_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Transactions (Transaksi Kasir & Pembayaran)
CREATE TABLE IF NOT EXISTS public.transactions (
  id BIGSERIAL PRIMARY KEY,
  invoice_number TEXT UNIQUE NOT NULL,
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE CASCADE,
  customer_id BIGINT REFERENCES public.customers(id) ON DELETE SET NULL,
  vehicle_id BIGINT REFERENCES public.vehicles(id) ON DELETE SET NULL,
  service_id BIGINT REFERENCES public.services(id) ON DELETE SET NULL,
  service_name TEXT NOT NULL,
  vehicle_plate TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  discount NUMERIC DEFAULT 0,
  final_amount NUMERIC NOT NULL,
  payment_method TEXT NOT NULL CHECK (payment_method IN ('CASH', 'TRANSFER', 'QRIS', 'MEMBERSHIP_POINT')),
  payment_status TEXT NOT NULL CHECK (payment_status IN ('PAID', 'PENDING', 'CANCELLED')),
  cashier_id BIGINT REFERENCES public.users(id) ON DELETE SET NULL,
  cashier_name TEXT NOT NULL,
  queue_status TEXT NOT NULL CHECK (queue_status IN ('MENUNGGU', 'PROSES_CUCI', 'PENGERINGAN', 'SELESAI', 'DIAMBIL')),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Transaction Staff (Bagi Hasil per Transaksi)
CREATE TABLE IF NOT EXISTS public.transaction_staff (
  id BIGSERIAL PRIMARY KEY,
  transaction_id BIGINT REFERENCES public.transactions(id) ON DELETE CASCADE,
  employee_id BIGINT REFERENCES public.employees(id) ON DELETE CASCADE,
  staff_name TEXT NOT NULL,
  commission_amount NUMERIC NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. Queue Status History (Pelacakan Perubahan Antrian)
CREATE TABLE IF NOT EXISTS public.vehicle_status_history (
  id BIGSERIAL PRIMARY KEY,
  transaction_id BIGINT REFERENCES public.transactions(id) ON DELETE CASCADE,
  previous_status TEXT,
  new_status TEXT NOT NULL,
  changed_by_user_id BIGINT REFERENCES public.users(id) ON DELETE SET NULL,
  changed_by_name TEXT NOT NULL,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  notes TEXT
);

-- 11. Attendance (Presensi Staff)
CREATE TABLE IF NOT EXISTS public.attendance (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT REFERENCES public.businesses(id) ON DELETE CASCADE,
  employee_id BIGINT REFERENCES public.employees(id) ON DELETE CASCADE,
  employee_name TEXT NOT NULL,
  date DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('HADIR', 'SAKIT', 'IZIN', 'ALPA')),
  clock_in TIMESTAMPTZ,
  clock_out TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. Audit Logs (Catatan Audit Keamanan)
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT,
  user_id BIGINT,
  user_name TEXT NOT NULL,
  user_role TEXT NOT NULL,
  action TEXT NOT NULL,
  details TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS) but allow anon access for system app
ALTER TABLE public.businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_profit_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transaction_staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Allow anon policies for demo/application key
CREATE POLICY "Allow public read-write for demo businesses" ON public.businesses FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo users" ON public.users FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo employees" ON public.employees FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo staff_profit_settings" ON public.staff_profit_settings FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo services" ON public.services FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo customers" ON public.customers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo vehicles" ON public.vehicles FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo transactions" ON public.transactions FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo transaction_staff" ON public.transaction_staff FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo vehicle_status_history" ON public.vehicle_status_history FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo attendance" ON public.attendance FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public read-write for demo audit_logs" ON public.audit_logs FOR ALL USING (true) WITH CHECK (true);
`;
