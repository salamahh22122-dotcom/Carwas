import { supabase, checkSupabaseConnection, isSupabaseConfigured } from '../lib/supabase';
import { CarWashStorage } from './storage';

export interface SupabaseSyncStatus {
  isConfigured: boolean;
  isConnected: boolean;
  latencyMs?: number;
  message: string;
  lastSyncTime?: number;
  syncedTables?: string[];
  tablesDetected?: string[];
}

export class SupabaseSyncService {
  private static instance: SupabaseSyncService;
  private status: SupabaseSyncStatus = {
    isConfigured: isSupabaseConfigured,
    isConnected: false,
    message: 'Belum diuji koneksi.',
  };
  private listeners: Array<(status: SupabaseSyncStatus) => void> = [];

  public static getInstance(): SupabaseSyncService {
    if (!SupabaseSyncService.instance) {
      SupabaseSyncService.instance = new SupabaseSyncService();
    }
    return SupabaseSyncService.instance;
  }

  public subscribe(listener: (status: SupabaseSyncStatus) => void): () => void {
    this.listeners.push(listener);
    listener(this.status);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify(): void {
    this.listeners.forEach(l => l({ ...this.status }));
  }

  public getStatus(): SupabaseSyncStatus {
    return { ...this.status };
  }

  public async testConnection(): Promise<SupabaseSyncStatus> {
    const res = await checkSupabaseConnection();
    this.status = {
      isConfigured: isSupabaseConfigured,
      isConnected: res.connected,
      latencyMs: res.latencyMs,
      message: res.message,
      tablesDetected: res.tablesFound,
      lastSyncTime: this.status.lastSyncTime,
      syncedTables: this.status.syncedTables,
    };
    this.notify();
    return this.status;
  }

  /**
   * Sync all local data from CarWashStorage up to Supabase tables
   */
  public async syncAllToSupabase(storage: CarWashStorage): Promise<{
    success: boolean;
    syncedCount: Record<string, number>;
    errors: string[];
  }> {
    const errors: string[] = [];
    const syncedCount: Record<string, number> = {};

    try {
      // 1. Businesses
      if (storage.businesses.length > 0) {
        const rows = storage.businesses.map(b => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email || null,
          logo_url: b.logoUrl || null,
          owner_name: b.ownerName,
        }));
        const { error } = await supabase.from('businesses').upsert(rows);
        if (error) errors.push(`Businesses: ${error.message}`);
        else syncedCount['businesses'] = rows.length;
      }

      // 2. Users
      if (storage.users.length > 0) {
        const rows = storage.users.map(u => ({
          id: u.id,
          username: u.username,
          email: u.email || null,
          password_hash: u.passwordHash,
          full_name: u.fullName,
          phone: u.phone,
          role: u.role,
          business_id: u.businessId || null,
          is_active: u.isActive,
          is_permanent_master: Boolean(u.isPermanentMaster),
        }));
        const { error } = await supabase.from('users').upsert(rows);
        if (error) errors.push(`Users: ${error.message}`);
        else syncedCount['users'] = rows.length;
      }

      // 3. Employees
      if (storage.employees.length > 0) {
        const rows = storage.employees.map(e => ({
          id: e.id,
          business_id: e.businessId,
          user_id: e.userId || null,
          full_name: e.fullName,
          phone: e.phone,
          role: e.role,
          commission_percentage: e.commissionPercentage,
          daily_salary: e.dailySalary,
          monthly_salary: e.monthlySalary,
          is_active: e.isActive,
        }));
        const { error } = await supabase.from('employees').upsert(rows);
        if (error) errors.push(`Employees: ${error.message}`);
        else syncedCount['employees'] = rows.length;
      }

      // 4. Services
      if (storage.services.length > 0) {
        const rows = storage.services.map(s => ({
          id: s.id,
          business_id: s.businessId,
          name: s.name,
          category: s.category,
          vehicle_type: s.vehicleType,
          vehicle_size: s.vehicleSize,
          price: s.price,
          estimated_minutes: s.estimatedMinutes,
          staff_commission: s.staffCommission,
          is_active: s.isActive,
        }));
        const { error } = await supabase.from('services').upsert(rows);
        if (error) errors.push(`Services: ${error.message}`);
        else syncedCount['services'] = rows.length;
      }

      // 5. Customers
      if (storage.customers.length > 0) {
        const rows = storage.customers.map(c => ({
          id: c.id,
          business_id: c.businessId,
          name: c.name,
          phone: c.phone,
          address: c.address || null,
          points: c.points,
          total_spend: c.totalSpend,
          visit_count: c.visitCount,
          membership_type: c.membershipType,
        }));
        const { error } = await supabase.from('customers').upsert(rows);
        if (error) errors.push(`Customers: ${error.message}`);
        else syncedCount['customers'] = rows.length;
      }

      // 6. Vehicles
      if (storage.vehicles.length > 0) {
        const rows = storage.vehicles.map(v => ({
          id: v.id,
          business_id: v.businessId,
          customer_id: v.customerId,
          plate_number: v.plateNumber,
          brand: v.brand,
          model: v.model,
          color: v.color || null,
          vehicle_type: v.vehicleType,
          vehicle_size: v.vehicleSize,
          wash_count: v.washCount,
        }));
        const { error } = await supabase.from('vehicles').upsert(rows);
        if (error) errors.push(`Vehicles: ${error.message}`);
        else syncedCount['vehicles'] = rows.length;
      }

      // 7. Transactions
      if (storage.transactions.length > 0) {
        const rows = storage.transactions.map(t => ({
          id: t.id,
          invoice_number: t.invoiceNumber,
          business_id: t.businessId,
          customer_id: t.customerId || null,
          vehicle_id: t.vehicleId || null,
          service_id: t.serviceId || null,
          service_name: t.serviceName,
          vehicle_plate: t.vehiclePlate,
          customer_name: t.customerName,
          amount: t.amount,
          discount: t.discount,
          final_amount: t.finalAmount,
          payment_method: t.paymentMethod,
          payment_status: t.paymentStatus,
          cashier_id: t.cashierId || null,
          cashier_name: t.cashierName,
          queue_status: t.queueStatus,
          notes: t.notes || null,
        }));
        const { error } = await supabase.from('transactions').upsert(rows);
        if (error) errors.push(`Transactions: ${error.message}`);
        else syncedCount['transactions'] = rows.length;
      }

      this.status.lastSyncTime = Date.now();
      this.status.syncedTables = Object.keys(syncedCount);
      this.notify();

      return {
        success: errors.length === 0,
        syncedCount,
        errors,
      };
    } catch (err: any) {
      errors.push(`Sync failed: ${err.message || err}`);
      return {
        success: false,
        syncedCount,
        errors,
      };
    }
  }
}
