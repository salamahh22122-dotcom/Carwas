import {
  Business,
  User,
  UserRole,
  Employee,
  StaffProfitSetting,
  Service,
  Customer,
  Vehicle,
  Transaction,
  TransactionStaff,
  VehicleQueueStatus,
  VehicleStatusHistory,
  Attendance,
  AttendanceStatus,
  AuditLog,
  MembershipPackage,
  CustomerMembership,
  PointRule,
  CustomerPointHistory,
  AdditionalOption,
  DatePeriodFilter,
  SalesReportSummary,
  StaffProfitReportItem,
  VehicleReportItem,
  ServicePopularityItem,
} from '../types';
import {
  INITIAL_BUSINESSES,
  INITIAL_USERS,
  INITIAL_EMPLOYEES,
  INITIAL_PROFIT_SETTINGS,
  INITIAL_SERVICES,
  INITIAL_CUSTOMERS,
  INITIAL_VEHICLES,
  INITIAL_TRANSACTIONS,
  INITIAL_TRANSACTION_STAFF,
  INITIAL_VEHICLE_STATUS_HISTORY,
  INITIAL_ATTENDANCE,
  INITIAL_MEMBERSHIP_PACKAGES,
  INITIAL_CUSTOMER_MEMBERSHIPS,
  INITIAL_POINT_RULE,
  INITIAL_POINT_HISTORIES,
  INITIAL_AUDIT_LOGS,
} from './initialData';

const STORAGE_KEYS = {
  BUSINESSES: 'carwash_businesses',
  USERS: 'carwash_users',
  EMPLOYEES: 'carwash_employees',
  PROFIT_SETTINGS: 'carwash_profit_settings',
  SERVICES: 'carwash_services',
  CUSTOMERS: 'carwash_customers',
  VEHICLES: 'carwash_vehicles',
  TRANSACTIONS: 'carwash_transactions',
  TRANSACTION_STAFF: 'carwash_transaction_staff',
  QUEUE_HISTORY: 'carwash_queue_history',
  ATTENDANCE: 'carwash_attendance',
  PACKAGES: 'carwash_membership_packages',
  CUSTOMER_MEMBERSHIPS: 'carwash_customer_memberships',
  POINT_RULES: 'carwash_point_rules',
  POINT_HISTORY: 'carwash_point_history',
  AUDIT_LOGS: 'carwash_audit_logs',
  CURRENT_USER_ID: 'carwash_current_user_id',
  CURRENT_BUSINESS_ID: 'carwash_current_business_id',
};

function getStored<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Failed to store key: ${key}`, err);
  }
}

export class CarWashStorage {
  // Static state in memory
  private static instance: CarWashStorage;

  businesses: Business[];
  users: User[];
  employees: Employee[];
  profitSettings: StaffProfitSetting[];
  services: Service[];
  customers: Customer[];
  vehicles: Vehicle[];
  transactions: Transaction[];
  transactionStaff: TransactionStaff[];
  queueHistory: VehicleStatusHistory[];
  attendance: Attendance[];
  packages: MembershipPackage[];
  customerMemberships: CustomerMembership[];
  pointRules: Record<number, PointRule>; // keyed by businessId
  pointHistory: CustomerPointHistory[];
  auditLogs: AuditLog[];

  currentUser: User | null = null;
  currentBusiness: Business | null = null;

  private listeners: Set<() => void> = new Set();

  private constructor() {
    this.businesses = getStored<Business[]>(STORAGE_KEYS.BUSINESSES, INITIAL_BUSINESSES);
    this.users = getStored<User[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
    this.employees = getStored<Employee[]>(STORAGE_KEYS.EMPLOYEES, INITIAL_EMPLOYEES);
    this.profitSettings = getStored<StaffProfitSetting[]>(STORAGE_KEYS.PROFIT_SETTINGS, INITIAL_PROFIT_SETTINGS);
    this.services = getStored<Service[]>(STORAGE_KEYS.SERVICES, INITIAL_SERVICES);
    this.customers = getStored<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    this.vehicles = getStored<Vehicle[]>(STORAGE_KEYS.VEHICLES, INITIAL_VEHICLES);
    this.transactions = getStored<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, INITIAL_TRANSACTIONS);
    this.transactionStaff = getStored<TransactionStaff[]>(STORAGE_KEYS.TRANSACTION_STAFF, INITIAL_TRANSACTION_STAFF);
    this.queueHistory = getStored<VehicleStatusHistory[]>(STORAGE_KEYS.QUEUE_HISTORY, INITIAL_VEHICLE_STATUS_HISTORY);
    this.attendance = getStored<Attendance[]>(STORAGE_KEYS.ATTENDANCE, INITIAL_ATTENDANCE);
    this.packages = getStored<MembershipPackage[]>(STORAGE_KEYS.PACKAGES, INITIAL_MEMBERSHIP_PACKAGES);
    this.customerMemberships = getStored<CustomerMembership[]>(STORAGE_KEYS.CUSTOMER_MEMBERSHIPS, INITIAL_CUSTOMER_MEMBERSHIPS);
    this.pointRules = getStored<Record<number, PointRule>>(STORAGE_KEYS.POINT_RULES, { 1: INITIAL_POINT_RULE });
    this.pointHistory = getStored<CustomerPointHistory[]>(STORAGE_KEYS.POINT_HISTORY, INITIAL_POINT_HISTORIES);
    this.auditLogs = getStored<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);

    // Ensure the single permanent Master account is strictly enforced
    const permanentMaster: User = {
      id: 1,
      username: 'master',
      email: 'mdqputra@gmail.com',
      passwordHash: '990830Ok',
      fullName: 'Master Administrator',
      phone: '081198765432',
      role: 'MASTER',
      businessId: null,
      isActive: true,
      isPermanentMaster: true,
      createdAt: this.users.find(u => u.id === 1)?.createdAt || (Date.now() - 60 * 86400000),
    };

    const existingMasterIdx = this.users.findIndex(u => u.id === 1 || u.role === 'MASTER');
    if (existingMasterIdx >= 0) {
      this.users[existingMasterIdx] = {
        ...this.users[existingMasterIdx],
        ...permanentMaster,
      };
    } else {
      this.users.unshift(permanentMaster);
    }

    // Guarantee strictly ONLY ONE MASTER account across the whole system
    this.users = this.users.filter(u => u.id === 1 || u.role !== 'MASTER');

    // Ensure users have emails for email-based login
    this.users.forEach(u => {
      if (!u.email) {
        if (u.username === 'budi_owner') u.email = 'budi.owner@cleanauto.com';
        else if (u.username === 'admin_dian') u.email = 'admin.dian@cleanauto.com';
        else if (u.username === 'kasir_siti') u.email = 'kasir.siti@cleanauto.com';
        else if (u.username === 'staff_joko') u.email = 'staff.joko@cleanauto.com';
        else if (u.username === 'hendra_owner') u.email = 'hendra.owner@autoshine.com';
        else u.email = `${u.username}@cleanauto.com`;
      }
    });

    setStored(STORAGE_KEYS.USERS, this.users);

    // Restore last session user or start logged out
    const savedUserId = getStored<number | null>(STORAGE_KEYS.CURRENT_USER_ID, null);
    const user = savedUserId ? this.users.find(u => u.id === savedUserId && u.isActive) || null : null;
    this.currentUser = user;

    // Restore business
    if (this.currentUser?.businessId) {
      this.currentBusiness = this.businesses.find(b => b.id === this.currentUser!.businessId) || this.businesses[0] || null;
    } else {
      const savedBizId = getStored<number | null>(STORAGE_KEYS.CURRENT_BUSINESS_ID, 1);
      this.currentBusiness = this.businesses.find(b => b.id === savedBizId) || this.businesses[0] || null;
    }
  }

  public static getInstance(): CarWashStorage {
    if (!CarWashStorage.instance) {
      CarWashStorage.instance = new CarWashStorage();
    }
    return CarWashStorage.instance;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    this.saveAll();
    this.listeners.forEach(l => l());
  }

  private saveAll(): void {
    setStored(STORAGE_KEYS.BUSINESSES, this.businesses);
    setStored(STORAGE_KEYS.USERS, this.users);
    setStored(STORAGE_KEYS.EMPLOYEES, this.employees);
    setStored(STORAGE_KEYS.PROFIT_SETTINGS, this.profitSettings);
    setStored(STORAGE_KEYS.SERVICES, this.services);
    setStored(STORAGE_KEYS.CUSTOMERS, this.customers);
    setStored(STORAGE_KEYS.VEHICLES, this.vehicles);
    setStored(STORAGE_KEYS.TRANSACTIONS, this.transactions);
    setStored(STORAGE_KEYS.TRANSACTION_STAFF, this.transactionStaff);
    setStored(STORAGE_KEYS.QUEUE_HISTORY, this.queueHistory);
    setStored(STORAGE_KEYS.ATTENDANCE, this.attendance);
    setStored(STORAGE_KEYS.PACKAGES, this.packages);
    setStored(STORAGE_KEYS.CUSTOMER_MEMBERSHIPS, this.customerMemberships);
    setStored(STORAGE_KEYS.POINT_RULES, this.pointRules);
    setStored(STORAGE_KEYS.POINT_HISTORY, this.pointHistory);
    setStored(STORAGE_KEYS.AUDIT_LOGS, this.auditLogs);
    setStored(STORAGE_KEYS.CURRENT_USER_ID, this.currentUser?.id ?? null);
    setStored(STORAGE_KEYS.CURRENT_BUSINESS_ID, this.currentBusiness?.id ?? null);
  }

  // ---------------------------------------------------------------------------
  // RBAC & PERMISSIONS
  // ---------------------------------------------------------------------------
  public canViewFinancials(role?: UserRole): boolean {
    const r = role || this.currentUser?.role;
    return r === 'MASTER' || r === 'OWNER' || r === 'KASIR';
  }

  public canManageProfitShare(role?: UserRole): boolean {
    const r = role || this.currentUser?.role;
    return r === 'MASTER' || r === 'OWNER';
  }

  public canManageEmployees(role?: UserRole): boolean {
    const r = role || this.currentUser?.role;
    return r === 'MASTER' || r === 'OWNER' || r === 'ADMIN';
  }

  public canManageServices(role?: UserRole): boolean {
    const r = role || this.currentUser?.role;
    return r === 'MASTER' || r === 'OWNER' || r === 'ADMIN' || r === 'KASIR';
  }

  // ---------------------------------------------------------------------------
  // AUTH
  // ---------------------------------------------------------------------------
  public login(identifier: string, plainPassword: string): { success: boolean; message: string; user?: User } {
    const trimmedId = identifier.trim();
    const trimmedPass = plainPassword.trim();

    if (!trimmedId) {
      return { success: false, message: 'Email atau username wajib diisi.' };
    }
    if (!trimmedPass) {
      return { success: false, message: 'Password wajib diisi.' };
    }

    // Check email format if @ is present
    if (trimmedId.includes('@')) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(trimmedId)) {
        return { success: false, message: 'Format email tidak valid. Pastikan penulisan alamat email benar (contoh: user@domain.com).' };
      }
    }

    const lowerId = trimmedId.toLowerCase();
    const user = this.users.find(u =>
      (u.email && u.email.toLowerCase() === lowerId) ||
      u.username.toLowerCase() === lowerId
    );

    if (!user) {
      return { success: false, message: 'Email atau username tidak ditemukan dalam sistem.' };
    }

    if (!user.isActive) {
      return { success: false, message: 'Akun ini telah dinonaktifkan. Silakan hubungi Administrator.' };
    }

    if (user.passwordHash !== trimmedPass) {
      return { success: false, message: 'Password yang Anda masukkan salah. Silakan periksa kembali.' };
    }

    this.setCurrentUser(user);
    this.logAudit({
      businessId: user.businessId,
      userId: user.id,
      userName: user.fullName,
      userRole: user.role,
      action: 'LOGIN',
      details: `User ${user.fullName} (${user.email || user.username}) berhasil login sebagai ${user.role}`,
    });

    return { success: true, message: `Selamat datang kembali, ${user.fullName}!`, user };
  }

  public setCurrentUser(user: User | null): void {
    this.currentUser = user;
    setStored(STORAGE_KEYS.CURRENT_USER_ID, user ? user.id : null);
    if (user?.businessId) {
      this.currentBusiness = this.businesses.find(b => b.id === user.businessId) || null;
      if (this.currentBusiness) {
        setStored(STORAGE_KEYS.CURRENT_BUSINESS_ID, this.currentBusiness.id);
      }
    } else if (user?.role === 'MASTER' && this.businesses.length > 0) {
      if (!this.currentBusiness) {
        this.currentBusiness = this.businesses[0];
        setStored(STORAGE_KEYS.CURRENT_BUSINESS_ID, this.currentBusiness.id);
      }
    }
    this.notify();
  }

  public switchUser(userId: number): void {
    const user = this.users.find(u => u.id === userId) || null;
    if (user) {
      this.setCurrentUser(user);
    }
  }

  public authenticate(identifier: string, passwordPlain: string): User | null {
    const res = this.login(identifier, passwordPlain);
    return res.success && res.user ? res.user : null;
  }

  public canManageProfitSetting(role?: UserRole): boolean {
    return this.canManageProfitShare(role);
  }

  public createCashierAccount(params: {
    fullName: string;
    username: string;
    email?: string;
    phone: string;
    passwordPlain: string;
  }): { success: boolean; message: string } {
    if (this.currentUser?.role !== 'OWNER') {
      return { success: false, message: 'Hanya Owner yang dapat mendaftarkan akun Kasir.' };
    }

    const businessId = this.currentBusiness?.id;
    if (!businessId) {
      return { success: false, message: 'Unit bisnis aktif tidak ditemukan.' };
    }

    const username = params.username.trim().toLowerCase();
    const email = (params.email || '').trim().toLowerCase();

    if (!username || username.length < 3) {
      return { success: false, message: 'Username Kasir minimal 3 karakter.' };
    }

    if (this.users.some(u => u.username.toLowerCase() === username)) {
      return { success: false, message: `Username "${username}" sudah digunakan.` };
    }

    if (email && this.users.some(u => u.email?.toLowerCase() === email)) {
      return { success: false, message: `Email "${email}" sudah digunakan.` };
    }

    const newId = Math.max(0, ...this.users.map(u => u.id)) + 1;
    const newCashier: User = {
      id: newId,
      username,
      email: email || undefined,
      passwordHash: params.passwordPlain.trim(),
      fullName: params.fullName.trim(),
      phone: params.phone.trim(),
      role: 'KASIR',
      businessId,
      isActive: true,
      createdAt: Date.now(),
    };

    this.users.push(newCashier);

    this.logAudit({
      businessId,
      userId: this.currentUser.id,
      userName: this.currentUser.fullName,
      userRole: this.currentUser.role,
      action: 'CREATE_CASHIER_ACCOUNT',
      details: `Owner mendaftarkan akun Kasir ${newCashier.fullName} (@${newCashier.username}) untuk bisnis ${this.currentBusiness?.name || businessId}.`,
    });

    this.notify();
    return { success: true, message: `Akun Kasir ${newCashier.fullName} berhasil dibuat.` };
  }

  public toggleUserStatus(userId: number): { success: boolean; message: string } {
    if (this.currentUser?.role !== 'OWNER') {
      return { success: false, message: 'Hanya Owner yang dapat mengubah status akun Kasir.' };
    }

    const user = this.users.find(u => u.id === userId && u.role === 'KASIR' && u.businessId === this.currentBusiness?.id);
    if (!user) return { success: false, message: 'Akun Kasir tidak ditemukan pada bisnis aktif.' };

    user.isActive = !user.isActive;
    this.logAudit({
      businessId: user.businessId,
      userId: this.currentUser.id,
      userName: this.currentUser.fullName,
      userRole: this.currentUser.role,
      action: 'TOGGLE_CASHIER_ACCOUNT_STATUS',
      details: `Owner mengubah akun Kasir ${user.fullName} menjadi ${user.isActive ? 'AKTIF' : 'NONAKTIF'}.`,
    });

    this.notify();
    return { success: true, message: `Akun Kasir ${user.fullName} sekarang ${user.isActive ? 'aktif' : 'nonaktif'}.` };
  }


  public getVehicleStatusHistory(vehicleId: number): VehicleStatusHistory[] {
    return this.queueHistory.filter(q => q.vehicleId === vehicleId);
  }

  public switchBusiness(businessOrId: Business | number): void {
    if (typeof businessOrId === 'number') {
      const b = this.businesses.find(item => item.id === businessOrId);
      if (b) {
        this.currentBusiness = b;
        setStored(STORAGE_KEYS.CURRENT_BUSINESS_ID, b.id);
      }
    } else {
      this.currentBusiness = businessOrId;
      setStored(STORAGE_KEYS.CURRENT_BUSINESS_ID, businessOrId.id);
    }
    this.notify();
  }

  public logout(): void {
    if (this.currentUser) {
      this.logAudit({
        businessId: this.currentUser.businessId,
        userId: this.currentUser.id,
        userName: this.currentUser.fullName,
        userRole: this.currentUser.role,
        action: 'LOGOUT',
        details: `User ${this.currentUser.fullName} (${this.currentUser.email || this.currentUser.username}) berhasil keluar dari sistem`,
      });
    }
    this.currentUser = null;
    setStored(STORAGE_KEYS.CURRENT_USER_ID, null);
    this.notify();
  }

  // ---------------------------------------------------------------------------
  // AUDIT LOGGING
  // ---------------------------------------------------------------------------
  public logAudit(entry: Omit<AuditLog, 'id' | 'timestamp'>): void {
    const newLog: AuditLog = {
      ...entry,
      id: Date.now() + Math.floor(Math.random() * 1000),
      timestamp: Date.now(),
    };
    this.auditLogs.unshift(newLog);
    // Keep max 200 logs
    if (this.auditLogs.length > 200) {
      this.auditLogs.pop();
    }
  }

  // ---------------------------------------------------------------------------
  // MASTER: CREATE OWNER & BUSINESS
  // ---------------------------------------------------------------------------
  public createOwnerAndBusiness(params: {
    username: string;
    passwordPlain: string;
    fullName: string;
    phone: string;
    businessName: string;
    businessAddress: string;
  }): { success: boolean; message: string } {
    if (this.currentUser?.role !== 'MASTER') {
      return { success: false, message: 'Hanya Master Admin yang berhak membuat akun Owner & Unit Bisnis.' };
    }

    const username = params.username.trim().toLowerCase();
    if (this.users.some(u => u.username.toLowerCase() === username)) {
      return { success: false, message: `Username "${username}" sudah digunakan.` };
    }

    const newBizId = Math.max(0, ...this.businesses.map(b => b.id)) + 1;
    const newUserId = Math.max(0, ...this.users.map(u => u.id)) + 1;

    const newOwner: User = {
      id: newUserId,
      username,
      passwordHash: params.passwordPlain.trim(),
      fullName: params.fullName.trim(),
      phone: params.phone.trim(),
      role: 'OWNER',
      businessId: newBizId,
      isActive: true,
      createdAt: Date.now(),
    };

    const newBiz: Business = {
      id: newBizId,
      name: params.businessName.trim(),
      ownerUserId: newUserId,
      address: params.businessAddress.trim(),
      phone: params.phone.trim(),
      status: 'ACTIVE',
      createdAt: Date.now(),
    };

    this.users.push(newOwner);
    this.businesses.push(newBiz);

    // Initialize point rule for new business
    this.pointRules[newBizId] = {
      id: newBizId,
      businessId: newBizId,
      spendAmountPerPoint: 10000,
      pointsEarned: 1,
      pointRedeemValue: 1000,
      isEnabled: true,
      updatedAt: Date.now(),
    };

    this.logAudit({
      businessId: newBizId,
      userId: this.currentUser.id,
      userName: this.currentUser.fullName,
      userRole: this.currentUser.role,
      action: 'CREATE_OWNER_AND_BUSINESS',
      details: `Master membuat Owner: ${newOwner.fullName} (@${newOwner.username}) dan Unit Bisnis: ${newBiz.name}`,
    });

    this.notify();
    return { success: true, message: `Berhasil membuat Owner ${newOwner.fullName} dan Bisnis ${newBiz.name}!` };
  }

  public toggleBusinessStatus(businessId: number): { success: boolean; message: string } {
    if (this.currentUser?.role !== 'MASTER') {
      return { success: false, message: 'Hanya Master Admin yang berhak mengubah status unit bisnis.' };
    }
    const biz = this.businesses.find(b => b.id === businessId);
    if (!biz) return { success: false, message: 'Unit bisnis tidak ditemukan.' };

    biz.status = biz.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
    this.logAudit({
      businessId: biz.id,
      userId: this.currentUser.id,
      userName: this.currentUser.fullName,
      userRole: this.currentUser.role,
      action: 'TOGGLE_BUSINESS_STATUS',
      details: `Master mengubah status unit bisnis "${biz.name}" menjadi ${biz.status}`,
    });

    this.notify();
    return {
      success: true,
      message: `Status unit bisnis "${biz.name}" berhasil diubah menjadi ${biz.status === 'ACTIVE' ? 'Aktif' : 'Suspended'}.`,
    };
  }

  // ---------------------------------------------------------------------------
  // OWNER / ADMIN: EMPLOYEES & CONFIDENTIAL PROFIT SHARING
  // ---------------------------------------------------------------------------
  public addEmployee(params: {
    name: string;
    phone: string;
    position: string;
    profitPercentage: number;
  }): { success: boolean; message: string } {
    if (!this.canManageEmployees()) {
      return { success: false, message: 'Anda tidak memiliki hak akses untuk menambah staff.' };
    }
    const bizId = this.currentBusiness?.id;
    if (!bizId) return { success: false, message: 'Unit bisnis aktif tidak ditemukan.' };

    const newId = Math.max(0, ...this.employees.map(e => e.id)) + 1;
    const newEmp: Employee = {
      id: newId,
      businessId: bizId,
      name: params.name.trim(),
      phone: params.phone.trim(),
      position: params.position.trim(),
      status: 'ACTIVE',
      currentProfitPercentage: params.profitPercentage,
      createdAt: Date.now(),
    };

    this.employees.push(newEmp);

    // Record initial profit setting history
    const newSetting: StaffProfitSetting = {
      id: Date.now(),
      businessId: bizId,
      employeeId: newId,
      percentage: params.profitPercentage,
      effectiveDate: Date.now(),
      updatedBy: `${this.currentUser?.fullName} (${this.currentUser?.role})`,
      notes: 'Pengaturan awal persentase bagi hasil saat pendaftaran',
    };
    this.profitSettings.unshift(newSetting);

    this.logAudit({
      businessId: bizId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'OWNER',
      action: 'ADD_EMPLOYEE',
      details: `Tambah staff baru: ${newEmp.name} (${newEmp.position}) dengan bagi hasil ${params.profitPercentage}%`,
    });

    this.notify();
    return { success: true, message: `Staff ${newEmp.name} berhasil ditambahkan!` };
  }

  public updateEmployee(
    employeeId: number,
    updates: Partial<Omit<Employee, 'id' | 'businessId' | 'createdAt'>>,
    profitChangeNotes?: string
  ): { success: boolean; message: string } {
    const idx = this.employees.findIndex(e => e.id === employeeId);
    if (idx === -1) return { success: false, message: 'Staff tidak ditemukan.' };

    const old = this.employees[idx];
    const canChangePct = this.canManageProfitShare();

    // Check if profit percentage changed
    if (updates.currentProfitPercentage !== undefined && updates.currentProfitPercentage !== old.currentProfitPercentage) {
      if (!canChangePct) {
        return { success: false, message: 'Hanya Owner atau Master yang berhak mengubah persentase komisi bagi hasil.' };
      }
      const newSetting: StaffProfitSetting = {
        id: Date.now(),
        businessId: old.businessId,
        employeeId: old.id,
        percentage: updates.currentProfitPercentage,
        effectiveDate: Date.now(),
        updatedBy: `${this.currentUser?.fullName} (${this.currentUser?.role})`,
        notes: profitChangeNotes?.trim() || `Penyesuaian persentase dari ${old.currentProfitPercentage}% ke ${updates.currentProfitPercentage}%`,
      };
      this.profitSettings.unshift(newSetting);

      this.logAudit({
        businessId: old.businessId,
        userId: this.currentUser?.id || 0,
        userName: this.currentUser?.fullName || 'User',
        userRole: this.currentUser?.role || 'OWNER',
        action: 'UPDATE_PROFIT_PERCENTAGE',
        details: `Bagi hasil staff ${old.name} diubah dari ${old.currentProfitPercentage}% menjadi ${updates.currentProfitPercentage}%. Catatan: ${profitChangeNotes || '-'}`,
      });
    }

    const updated: Employee = {
      ...old,
      ...updates,
      // Guard against unauthorized percentage edits
      currentProfitPercentage: canChangePct ? (updates.currentProfitPercentage ?? old.currentProfitPercentage) : old.currentProfitPercentage,
    };

    this.employees[idx] = updated;
    this.notify();
    return { success: true, message: `Data staff ${updated.name} berhasil diperbarui.` };
  }

  public toggleEmployeeStatus(employeeId: number): void {
    const emp = this.employees.find(e => e.id === employeeId);
    if (!emp) return;
    const newStatus = emp.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    emp.status = newStatus;
    this.logAudit({
      businessId: emp.businessId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'OWNER',
      action: 'TOGGLE_EMPLOYEE_STATUS',
      details: `Mengubah status staff ${emp.name} menjadi ${newStatus}`,
    });
    this.notify();
  }

  public deleteEmployee(employeeId: number): { success: boolean; message: string } {
    if (!this.canManageEmployees()) {
      return { success: false, message: 'Anda tidak memiliki hak akses menghapus staff.' };
    }
    const idx = this.employees.findIndex(e => e.id === employeeId);
    if (idx === -1) return { success: false, message: 'Staff tidak ditemukan.' };
    const emp = this.employees[idx];
    this.employees.splice(idx, 1);
    this.logAudit({
      businessId: emp.businessId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'OWNER',
      action: 'DELETE_EMPLOYEE',
      details: `Menghapus data staff ${emp.name} (${emp.position})`,
    });
    this.notify();
    return { success: true, message: `Staff ${emp.name} berhasil dihapus.` };
  }

  // ---------------------------------------------------------------------------
  // SERVICES
  // ---------------------------------------------------------------------------
  public addService(params: Omit<Service, 'id' | 'businessId' | 'createdAt'>): { success: boolean; message: string } {
    if (!this.canManageServices()) {
      return { success: false, message: 'Anda tidak memiliki akses menambah layanan.' };
    }
    const bizId = this.currentBusiness?.id;
    if (!bizId) return { success: false, message: 'Unit bisnis aktif tidak ditemukan.' };

    const newId = Math.max(0, ...this.services.map(s => s.id)) + 1;
    const newSrv: Service = {
      ...params,
      id: newId,
      businessId: bizId,
      createdAt: Date.now(),
    };
    this.services.push(newSrv);
    this.logAudit({
      businessId: bizId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'OWNER',
      action: 'ADD_SERVICE',
      details: `Menambah layanan: ${newSrv.name} (Rp ${newSrv.price.toLocaleString('id-ID')})`,
    });
    this.notify();
    return { success: true, message: `Layanan ${newSrv.name} berhasil ditambahkan.` };
  }

  public updateService(serviceId: number, updates: Partial<Omit<Service, 'id' | 'businessId' | 'createdAt'>>): void {
    const idx = this.services.findIndex(s => s.id === serviceId);
    if (idx === -1) return;
    this.services[idx] = { ...this.services[idx], ...updates };
    this.logAudit({
      businessId: this.services[idx].businessId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'OWNER',
      action: 'UPDATE_SERVICE',
      details: `Update layanan: ${this.services[idx].name}`,
    });
    this.notify();
  }

  public toggleServiceStatus(serviceId: number): void {
    const srv = this.services.find(s => s.id === serviceId);
    if (!srv) return;
    srv.isActive = !srv.isActive;
    this.logAudit({
      businessId: srv.businessId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'OWNER',
      action: 'TOGGLE_SERVICE_STATUS',
      details: `Mengubah status layanan ${srv.name} menjadi ${srv.isActive ? 'Aktif' : 'Nonaktif'}`,
    });
    this.notify();
  }

  public deleteService(serviceId: number): void {
    const idx = this.services.findIndex(s => s.id === serviceId);
    if (idx === -1) return;
    const srv = this.services[idx];
    this.services.splice(idx, 1);
    this.logAudit({
      businessId: srv.businessId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'OWNER',
      action: 'DELETE_SERVICE',
      details: `Menghapus layanan ${srv.name}`,
    });
    this.notify();
  }

  // ---------------------------------------------------------------------------
  // CUSTOMERS & VEHICLES
  // ---------------------------------------------------------------------------
  public addCustomerWithVehicle(params: {
    name: string;
    phone: string;
    email: string;
    licensePlate: string;
    brandModel: string;
    vehicleType: string;
    color: string;
    notes: string;
  }): { success: boolean; message: string; customerId: number; vehicleId: number } {
    const bizId = this.currentBusiness?.id || 1;
    const custId = Math.max(0, ...this.customers.map(c => c.id)) + 1;
    const vehId = Math.max(0, ...this.vehicles.map(v => v.id)) + 1;

    const newCust: Customer = {
      id: custId,
      businessId: bizId,
      name: params.name.trim(),
      phone: params.phone.trim(),
      email: params.email.trim(),
      notes: params.notes.trim(),
      pointsBalance: 0,
      createdAt: Date.now(),
    };

    const newVeh: Vehicle = {
      id: vehId,
      businessId: bizId,
      customerId: custId,
      licensePlate: params.licensePlate.trim().toUpperCase(),
      brandModel: params.brandModel.trim(),
      vehicleType: params.vehicleType.trim(),
      color: params.color.trim(),
      notes: params.notes.trim(),
      createdAt: Date.now(),
    };

    this.customers.push(newCust);
    this.vehicles.push(newVeh);

    this.logAudit({
      businessId: bizId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'KASIR',
      action: 'ADD_CUSTOMER_VEHICLE',
      details: `Pendaftaran pelanggan: ${newCust.name} dengan kendaraan ${newVeh.licensePlate} (${newVeh.brandModel})`,
    });

    this.notify();
    return {
      success: true,
      message: `Pelanggan ${newCust.name} (${newVeh.licensePlate}) berhasil didaftarkan!`,
      customerId: custId,
      vehicleId: vehId,
    };
  }

  // ---------------------------------------------------------------------------
  // TRANSACTIONS & AUTOMATED PROFIT SHARING ENGINE
  // ---------------------------------------------------------------------------
  public createTransaction(params: {
    customerId: number;
    vehicleId: number;
    service: Service;
    assignedStaff: Employee[];
    additionalItems?: AdditionalOption[];
    discountAmount?: number;
    paymentMethod: string;
    notes?: string;
    usedMembershipId?: number | null;
    pointsToRedeem?: number;
  }): { success: boolean; message: string; transaction?: Transaction } {
    const bizId = this.currentBusiness?.id || 1;
    const cashier = this.currentUser;
    if (!cashier) return { success: false, message: 'Anda belum login.' };

    if (params.assignedStaff.length === 0) {
      return { success: false, message: 'Kasir WAJIB memilih minimal 1 Staff yang mengerjakan layanan!' };
    }

    const todayStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const countToday = this.transactions.filter(t => t.businessId === bizId).length + 1;
    const queueNumber = countToday;
    const invoiceNo = `INV-${todayStr}-${String(queueNumber).padStart(3, '0')}`;

    const servicePrice = params.service.price;
    const additionalList = params.additionalItems || [];
    const additionalAmount = additionalList.reduce((acc, i) => acc + i.price, 0);
    const grossAmount = servicePrice + additionalAmount;
    const discountAmount = params.discountAmount || 0;
    const totalAmount = Math.max(0, grossAmount - discountAmount);

    // Handle Membership deduction
    if (params.usedMembershipId) {
      const membership = this.customerMemberships.find(m => m.id === params.usedMembershipId);
      if (membership && membership.remainingQuota > 0) {
        membership.remainingQuota -= 1;
        if (membership.remainingQuota <= 0) {
          membership.status = 'DEPLETED';
        }
      }
    }

    // Handle Points redemption
    if (params.pointsToRedeem && params.pointsToRedeem > 0) {
      const cust = this.customers.find(c => c.id === params.customerId);
      if (cust) {
        cust.pointsBalance = Math.max(0, cust.pointsBalance - params.pointsToRedeem);
        this.pointHistory.unshift({
          id: Date.now() + Math.random(),
          businessId: bizId,
          customerId: cust.id,
          transactionId: countToday,
          pointsChange: -params.pointsToRedeem,
          type: 'REDEEM',
          description: `Penukaran ${params.pointsToRedeem} poin pada transaksi ${invoiceNo}`,
          createdAt: Date.now(),
        });
      }
    }

    // Calculate staff commissions & owner profit strictly
    let totalStaffShare = 0;
    const staffCommissions: TransactionStaff[] = [];
    const portionPerStaff = totalAmount / params.assignedStaff.length;

    for (const emp of params.assignedStaff) {
      const commission = (portionPerStaff * emp.currentProfitPercentage) / 100.0;
      totalStaffShare += commission;
      staffCommissions.push({
        id: Date.now() + Math.random(),
        transactionId: countToday,
        employeeId: emp.id,
        employeeName: emp.name,
        profitPercentage: emp.currentProfitPercentage,
        commissionAmount: commission,
      });
    }

    const ownerShare = Math.max(0, totalAmount - totalStaffShare);
    const staffNamesStr = params.assignedStaff.map(e => e.name).join(', ');
    const additionalStr = additionalList.map(a => `${a.name} (+Rp ${a.price.toLocaleString('id-ID')})`).join(', ');

    // Calculate points earned
    let pointsEarned = 0;
    const pointRule = this.pointRules[bizId];
    if (pointRule && pointRule.isEnabled && pointRule.spendAmountPerPoint > 0 && totalAmount >= pointRule.spendAmountPerPoint) {
      pointsEarned = Math.floor(totalAmount / pointRule.spendAmountPerPoint) * pointRule.pointsEarned;
      if (pointsEarned > 0) {
        const cust = this.customers.find(c => c.id === params.customerId);
        if (cust) {
          cust.pointsBalance += pointsEarned;
          this.pointHistory.unshift({
            id: Date.now() + Math.random(),
            businessId: bizId,
            customerId: cust.id,
            transactionId: countToday,
            pointsChange: pointsEarned,
            type: 'EARN',
            description: `Perolehan +${pointsEarned} poin dari transaksi ${invoiceNo}`,
            createdAt: Date.now(),
          });
        }
      }
    }

    const txId = Math.max(0, ...this.transactions.map(t => t.id)) + 1;
    const newTx: Transaction = {
      id: txId,
      businessId: bizId,
      invoiceNo,
      queueNumber,
      customerId: params.customerId,
      vehicleId: params.vehicleId,
      serviceId: params.service.id,
      serviceName: params.service.name,
      servicePrice,
      additionalServices: additionalStr,
      additionalAmount,
      discountAmount,
      totalAmount,
      staffShareAmount: totalStaffShare,
      ownerShareAmount: ownerShare,
      assignedStaffNames: staffNamesStr,
      status: 'COMPLETED',
      queueStatus: 'WAITING',
      paymentMethod: params.paymentMethod,
      usedMembershipId: params.usedMembershipId || null,
      pointsUsed: params.pointsToRedeem || 0,
      pointsEarned,
      cashierUserId: cashier.id,
      cashierName: cashier.fullName,
      notes: params.notes || '',
      createdAt: Date.now(),
    };

    this.transactions.unshift(newTx);
    for (const item of staffCommissions) {
      this.transactionStaff.push({ ...item, transactionId: txId });
    }

    // Auto-create initial queue status: WAITING
    this.updateVehicleQueueStatus(
      params.vehicleId,
      'WAITING',
      txId,
      `Antrian #${queueNumber} (${invoiceNo}) terdaftar. Layanan: ${params.service.name}. Staff: ${staffNamesStr}`
    );

    this.logAudit({
      businessId: bizId,
      userId: cashier.id,
      userName: cashier.fullName,
      userRole: cashier.role,
      action: 'CREATE_TRANSACTION',
      details: `Transaksi ${invoiceNo} (#${queueNumber}) total Rp ${totalAmount.toLocaleString('id-ID')} Staff: ${staffNamesStr}`,
    });

    this.notify();
    return {
      success: true,
      message: `Antrian #${queueNumber} (${invoiceNo}) berhasil dibuat!`,
      transaction: newTx,
    };
  }

  // ---------------------------------------------------------------------------
  // VEHICLE QUEUE PIPELINE
  // WAITING -> WASHING -> DRYING -> FINISHED -> PICKED_UP
  // ---------------------------------------------------------------------------
  public updateVehicleQueueStatus(
    vehicleId: number,
    newStatus: VehicleQueueStatus,
    transactionId?: number | null,
    notes?: string
  ): void {
    const bizId = this.currentBusiness?.id || 1;
    const updater = this.currentUser?.fullName || 'Sistem';
    const role = this.currentUser?.role || 'STAFF';

    const historyEntry: VehicleStatusHistory = {
      id: Date.now() + Math.random(),
      businessId: bizId,
      vehicleId,
      transactionId: transactionId || null,
      status: newStatus,
      updatedBy: `${updater} (${role})`,
      notes: notes || '',
      timestamp: Date.now(),
    };
    this.queueHistory.unshift(historyEntry);

    // Also update transaction queue status
    const targetTx = transactionId
      ? this.transactions.find(t => t.id === transactionId)
      : this.transactions.find(t => t.vehicleId === vehicleId && t.queueStatus !== 'PICKED_UP');

    if (targetTx) {
      targetTx.queueStatus = newStatus;
    }

    this.logAudit({
      businessId: bizId,
      userId: this.currentUser?.id || 0,
      userName: updater,
      userRole: role,
      action: 'UPDATE_QUEUE_STATUS',
      details: `Kendaraan #${vehicleId} status beralih ke: ${newStatus}`,
    });

    this.notify();
  }

  public getNextQueueStatus(current: VehicleQueueStatus): VehicleQueueStatus | null {
    switch (current) {
      case 'WAITING':
        return 'WASHING';
      case 'WASHING':
        return 'DRYING';
      case 'DRYING':
        return 'FINISHED';
      case 'FINISHED':
        return 'PICKED_UP';
      default:
        return null;
    }
  }

  // ---------------------------------------------------------------------------
  // ATTENDANCE
  // ---------------------------------------------------------------------------
  public checkInStaff(employee: Employee, status: AttendanceStatus = 'PRESENT', notes: string = ''): { success: boolean; message: string } {
    const bizId = this.currentBusiness?.id || 1;
    const today = new Date().toISOString().split('T')[0];
    const time = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

    const existing = this.attendance.find(a => a.businessId === bizId && a.employeeId === employee.id && a.date === today);
    if (existing) {
      return { success: false, message: `${employee.name} sudah melakukan Check-in hari ini pada ${existing.checkInTime}.` };
    }

    const newAttendance: Attendance = {
      id: Date.now(),
      businessId: bizId,
      employeeId: employee.id,
      employeeName: employee.name,
      date: today,
      checkInTime: time,
      checkOutTime: '',
      status,
      notes,
    };
    this.attendance.unshift(newAttendance);

    this.logAudit({
      businessId: bizId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'STAFF',
      action: 'CHECK_IN',
      details: `Check-in ${employee.name} pada ${today} pukul ${time} (${status})`,
    });

    this.notify();
    return { success: true, message: `Check-in ${employee.name} berhasil!` };
  }

  public checkOutStaff(attendanceId: number, notes: string = ''): { success: boolean; message: string } {
    const att = this.attendance.find(a => a.id === attendanceId);
    if (!att) return { success: false, message: 'Data presensi tidak ditemukan.' };

    const time = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    att.checkOutTime = time;
    if (notes) {
      att.notes = att.notes ? `${att.notes} | ${notes}` : notes;
    }

    this.logAudit({
      businessId: att.businessId,
      userId: this.currentUser?.id || 0,
      userName: this.currentUser?.fullName || 'User',
      userRole: this.currentUser?.role || 'STAFF',
      action: 'CHECK_OUT',
      details: `Check-out ${att.employeeName} pukul ${time}`,
    });

    this.notify();
    return { success: true, message: `Check-out ${att.employeeName} berhasil.` };
  }

  public recordCustomAttendance(params: Omit<Attendance, 'id'>): void {
    this.attendance.unshift({
      ...params,
      id: Date.now(),
    });
    this.notify();
  }

  // ---------------------------------------------------------------------------
  // MEMBERSHIP PACKAGES & POINTS
  // ---------------------------------------------------------------------------
  public addMembershipPackage(params: Omit<MembershipPackage, 'id' | 'businessId' | 'createdAt'>): void {
    const bizId = this.currentBusiness?.id || 1;
    const newPkg: MembershipPackage = {
      ...params,
      id: Date.now(),
      businessId: bizId,
      createdAt: Date.now(),
    };
    this.packages.push(newPkg);
    this.notify();
  }

  public deleteMembershipPackage(pkgId: number): void {
    const idx = this.packages.findIndex(p => p.id === pkgId);
    if (idx !== -1) {
      this.packages.splice(idx, 1);
      this.notify();
    }
  }

  public purchaseCustomerMembership(customerId: number, pkg: MembershipPackage): { success: boolean; message: string } {
    const bizId = this.currentBusiness?.id || 1;
    const now = Date.now();
    const expiresAt = now + pkg.validityDays * 86400000;

    const newSub: CustomerMembership = {
      id: Date.now(),
      businessId: bizId,
      customerId,
      packageId: pkg.id,
      packageName: pkg.name,
      totalQuota: pkg.totalVisits,
      remainingQuota: pkg.totalVisits,
      purchasePrice: pkg.price,
      purchasedAt: now,
      expiresAt,
      status: 'ACTIVE',
    };
    this.customerMemberships.unshift(newSub);
    this.notify();
    return { success: true, message: `Paket ${pkg.name} berhasil diaktifkan untuk pelanggan!` };
  }

  public updatePointRule(rule: Partial<PointRule>): void {
    const bizId = this.currentBusiness?.id || 1;
    const current = this.pointRules[bizId] || {
      id: bizId,
      businessId: bizId,
      spendAmountPerPoint: 10000,
      pointsEarned: 1,
      pointRedeemValue: 1000,
      isEnabled: true,
      updatedAt: Date.now(),
    };

    this.pointRules[bizId] = {
      ...current,
      ...rule,
      updatedAt: Date.now(),
    };
    this.notify();
  }

  public adjustCustomerPoints(customerId: number, delta: number, description: string): void {
    const bizId = this.currentBusiness?.id || 1;
    const cust = this.customers.find(c => c.id === customerId);
    if (!cust) return;

    cust.pointsBalance = Math.max(0, cust.pointsBalance + delta);
    this.pointHistory.unshift({
      id: Date.now(),
      businessId: bizId,
      customerId,
      pointsChange: delta,
      type: delta >= 0 ? 'BONUS' : 'ADJUSTMENT',
      description,
      createdAt: Date.now(),
    });
    this.notify();
  }

  // ---------------------------------------------------------------------------
  // BUSINESS SETTINGS
  // ---------------------------------------------------------------------------
  public updateBusiness(name: string, address: string, phone: string): void {
    if (!this.currentBusiness) return;
    this.currentBusiness.name = name;
    this.currentBusiness.address = address;
    this.currentBusiness.phone = phone;
    const idx = this.businesses.findIndex(b => b.id === this.currentBusiness!.id);
    if (idx !== -1) {
      this.businesses[idx] = { ...this.currentBusiness };
    }
    this.notify();
  }

  // ---------------------------------------------------------------------------
  // REPORT CALCULATIONS
  // ---------------------------------------------------------------------------
  public filterTransactionsByPeriod(
    transactions: Transaction[],
    period: DatePeriodFilter,
    customStartStr?: string,
    customEndStr?: string
  ): Transaction[] {
    const now = new Date();
    let startTime = 0;
    let endTime = Date.now() + 86400000;

    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const endOfDay = startOfDay + 86400000 - 1;

    switch (period) {
      case 'TODAY':
        startTime = startOfDay;
        endTime = endOfDay;
        break;
      case 'YESTERDAY':
        startTime = startOfDay - 86400000;
        endTime = startOfDay - 1;
        break;
      case 'THIS_WEEK': {
        const dayOfWeek = now.getDay() || 7; // Sunday is 7
        const monday = new Date(now);
        monday.setDate(now.getDate() - dayOfWeek + 1);
        monday.setHours(0, 0, 0, 0);
        startTime = monday.getTime();
        endTime = Date.now() + 86400000;
        break;
      }
      case 'THIS_MONTH': {
        const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
        startTime = firstOfMonth.getTime();
        endTime = Date.now() + 86400000;
        break;
      }
      case 'CUSTOM':
        if (customStartStr) {
          startTime = new Date(`${customStartStr}T00:00:00`).getTime() || 0;
        }
        if (customEndStr) {
          endTime = new Date(`${customEndStr}T23:59:59`).getTime() || LongMax();
        }
        break;
    }

    return transactions.filter(t => t.createdAt >= startTime && t.createdAt <= endTime);
  }

  public calculateSalesReportSummary(transactions: Transaction[]): SalesReportSummary {
    const totalTransactions = transactions.length;
    const grossRevenue = transactions.reduce((sum, t) => sum + (t.servicePrice + t.additionalAmount), 0);
    const totalDiscount = transactions.reduce((sum, t) => sum + t.discountAmount, 0);
    const netRevenue = transactions.reduce((sum, t) => sum + t.totalAmount, 0);

    let totalCash = 0;
    let totalTransfer = 0;
    let totalQris = 0;
    let totalOther = 0;

    for (const t of transactions) {
      const pm = t.paymentMethod.toUpperCase();
      if (pm.includes('CASH') || pm.includes('TUNAI')) totalCash += t.totalAmount;
      else if (pm.includes('TRANSFER')) totalTransfer += t.totalAmount;
      else if (pm.includes('QRIS')) totalQris += t.totalAmount;
      else totalOther += t.totalAmount;
    }

    return {
      totalTransactions,
      grossRevenue,
      totalDiscount,
      netRevenue,
      totalCash,
      totalTransfer,
      totalQris,
      totalOther,
    };
  }

  public calculateStaffProfitReport(transactions: Transaction[], employees: Employee[]): StaffProfitReportItem[] {
    const results: StaffProfitReportItem[] = [];

    for (const emp of employees) {
      const assignedTxs = transactions.filter(t => t.assignedStaffNames.toLowerCase().includes(emp.name.toLowerCase()));
      const vehicleCount = new Set(assignedTxs.map(t => t.vehicleId)).size;
      const serviceCount = assignedTxs.length;
      const totalServiceSales = assignedTxs.reduce((sum, t) => sum + t.totalAmount, 0);

      let totalStaffShare = 0;
      let recordedPercentages: number[] = [];

      for (const tx of assignedTxs) {
        // Query exact historical commission and percentage saved at transaction creation
        const tsRecord = this.transactionStaff.find(
          ts => ts.transactionId === tx.id && (ts.employeeId === emp.id || ts.employeeName.toLowerCase() === emp.name.toLowerCase())
        );

        if (tsRecord) {
          totalStaffShare += tsRecord.commissionAmount;
          recordedPercentages.push(tsRecord.profitPercentage);
        } else {
          // Graceful fallback for legacy records
          const staffCount = tx.assignedStaffNames.split(',').filter(s => s.trim().length > 0).length || 1;
          totalStaffShare += (tx.staffShareAmount / staffCount);
          recordedPercentages.push(emp.currentProfitPercentage);
        }
      }

      const totalOwnerShare = Math.max(0, totalServiceSales - totalStaffShare);
      // Historical snapshot percentage: average of historical snapshot in this period, or current percentage if no tx
      const snapshotPercentage = recordedPercentages.length > 0
        ? recordedPercentages[0]
        : emp.currentProfitPercentage;

      results.push({
        employeeId: emp.id,
        employeeName: emp.name,
        position: emp.position,
        vehicleCount,
        serviceCount,
        totalServiceSales,
        snapshotPercentage,
        totalStaffShare,
        totalOwnerShare,
      });
    }

    return results.sort((a, b) => b.serviceCount - a.serviceCount);
  }

  public getTransactionStaffRecords(txId?: number): TransactionStaff[] {
    if (txId !== undefined) {
      return this.transactionStaff.filter(ts => ts.transactionId === txId);
    }
    return this.transactionStaff;
  }

  public filterAttendanceByPeriod(
    attendanceList: Attendance[],
    period: DatePeriodFilter,
    customStartStr?: string,
    customEndStr?: string
  ): Attendance[] {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    switch (period) {
      case 'TODAY':
        return attendanceList.filter(a => a.date === todayStr);
      case 'YESTERDAY': {
        const yDate = new Date(now);
        yDate.setDate(now.getDate() - 1);
        const yStr = yDate.toISOString().split('T')[0];
        return attendanceList.filter(a => a.date === yStr);
      }
      case 'THIS_WEEK': {
        const dayOfWeek = now.getDay() || 7;
        const monday = new Date(now);
        monday.setDate(now.getDate() - dayOfWeek + 1);
        monday.setHours(0, 0, 0, 0);
        const mondayStr = monday.toISOString().split('T')[0];
        return attendanceList.filter(a => a.date >= mondayStr && a.date <= todayStr);
      }
      case 'THIS_MONTH': {
        const firstOfMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
        return attendanceList.filter(a => a.date >= firstOfMonthStr && a.date <= todayStr);
      }
      case 'CUSTOM': {
        let list = attendanceList;
        if (customStartStr) list = list.filter(a => a.date >= customStartStr);
        if (customEndStr) list = list.filter(a => a.date <= customEndStr);
        return list;
      }
      default:
        return attendanceList;
    }
  }

  public calculateVehicleReport(vehicles: Vehicle[], customers: Customer[], transactions: Transaction[]): VehicleReportItem[] {
    const custMap = new Map(customers.map(c => [c.id, c]));
    const results: VehicleReportItem[] = [];

    for (const veh of vehicles) {
      const vTxs = transactions.filter(t => t.vehicleId === veh.id).sort((a, b) => b.createdAt - a.createdAt);
      const cust = custMap.get(veh.customerId);
      const totalSpent = vTxs.reduce((acc, t) => acc + t.totalAmount, 0);
      const lastTx = vTxs[0];

      results.push({
        vehicle: veh,
        customerName: cust?.name || 'Pelanggan Umum',
        customerPhone: cust?.phone || '-',
        totalVisits: vTxs.length,
        lastVisitTimestamp: lastTx ? lastTx.createdAt : null,
        lastServiceName: lastTx ? lastTx.serviceName : 'Belum pernah',
        totalSpent,
      });
    }

    return results.sort((a, b) => b.totalVisits - a.totalVisits);
  }

  public calculateServicePopularityReport(services: Service[], transactions: Transaction[]): ServicePopularityItem[] {
    const totalRevenueAll = transactions.reduce((acc, t) => acc + t.totalAmount, 0) || 1;
    const results: ServicePopularityItem[] = [];

    for (const srv of services) {
      const srvTxs = transactions.filter(t => t.serviceId === srv.id || t.serviceName.toLowerCase() === srv.name.toLowerCase());
      const useCount = srvTxs.length;
      const totalRevenue = srvTxs.reduce((acc, t) => acc + t.totalAmount, 0);
      const uniqueVehiclesCount = new Set(srvTxs.map(t => t.vehicleId)).size;
      const revenueContributionPercentage = (totalRevenue / totalRevenueAll) * 100;

      results.push({
        serviceId: srv.id,
        serviceName: srv.name,
        category: srv.category,
        useCount,
        totalRevenue,
        uniqueVehiclesCount,
        revenueContributionPercentage,
      });
    }

    return results.sort((a, b) => b.useCount - a.useCount);
  }

  // ---------------------------------------------------------------------------
  // EXPORT / IMPORT ALL DATA
  // ---------------------------------------------------------------------------
  public exportDataJSON(): string {
    const data = {
      exportedAt: new Date().toISOString(),
      businesses: this.businesses,
      users: this.users,
      employees: this.employees,
      profitSettings: this.profitSettings,
      services: this.services,
      customers: this.customers,
      vehicles: this.vehicles,
      transactions: this.transactions,
      transactionStaff: this.transactionStaff,
      queueHistory: this.queueHistory,
      attendance: this.attendance,
      packages: this.packages,
      customerMemberships: this.customerMemberships,
      pointRules: this.pointRules,
      pointHistory: this.pointHistory,
      auditLogs: this.auditLogs,
    };
    return JSON.stringify(data, null, 2);
  }

  public importDataJSON(jsonStr: string): { success: boolean; message: string } {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.businesses) this.businesses = parsed.businesses;
      if (parsed.users) this.users = parsed.users;
      if (parsed.employees) this.employees = parsed.employees;
      if (parsed.profitSettings) this.profitSettings = parsed.profitSettings;
      if (parsed.services) this.services = parsed.services;
      if (parsed.customers) this.customers = parsed.customers;
      if (parsed.vehicles) this.vehicles = parsed.vehicles;
      if (parsed.transactions) this.transactions = parsed.transactions;
      if (parsed.transactionStaff) this.transactionStaff = parsed.transactionStaff;
      if (parsed.queueHistory) this.queueHistory = parsed.queueHistory;
      if (parsed.attendance) this.attendance = parsed.attendance;
      if (parsed.packages) this.packages = parsed.packages;
      if (parsed.customerMemberships) this.customerMemberships = parsed.customerMemberships;
      if (parsed.pointRules) this.pointRules = parsed.pointRules;
      if (parsed.pointHistory) this.pointHistory = parsed.pointHistory;
      if (parsed.auditLogs) this.auditLogs = parsed.auditLogs;

      this.notify();
      return { success: true, message: 'Database car wash berhasil diimpor sepenuhnya!' };
    } catch (e: any) {
      return { success: false, message: `Gagal membaca file JSON: ${e?.message}` };
    }
  }

  public resetToDefault(): void {
    localStorage.clear();
    this.businesses = INITIAL_BUSINESSES;
    this.users = INITIAL_USERS;
    this.employees = INITIAL_EMPLOYEES;
    this.profitSettings = INITIAL_PROFIT_SETTINGS;
    this.services = INITIAL_SERVICES;
    this.customers = INITIAL_CUSTOMERS;
    this.vehicles = INITIAL_VEHICLES;
    this.transactions = INITIAL_TRANSACTIONS;
    this.transactionStaff = INITIAL_TRANSACTION_STAFF;
    this.queueHistory = INITIAL_VEHICLE_STATUS_HISTORY;
    this.attendance = INITIAL_ATTENDANCE;
    this.packages = INITIAL_MEMBERSHIP_PACKAGES;
    this.customerMemberships = INITIAL_CUSTOMER_MEMBERSHIPS;
    this.pointRules = { 1: INITIAL_POINT_RULE };
    this.pointHistory = INITIAL_POINT_HISTORIES;
    this.auditLogs = INITIAL_AUDIT_LOGS;
    this.currentUser = INITIAL_USERS.find(u => u.username === 'budi_owner') || INITIAL_USERS[0];
    this.currentBusiness = INITIAL_BUSINESSES[0];
    this.notify();
  }
}

function LongMax(): number {
  return 9999999999999;
}
