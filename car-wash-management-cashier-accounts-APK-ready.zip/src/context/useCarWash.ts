import { useState, useEffect, useCallback } from 'react';
import { CarWashStorage } from '../data/storage';
import { User, Business, Employee, Service, Customer, Vehicle, Transaction, VehicleStatusHistory, Attendance, MembershipPackage, CustomerMembership, AuditLog } from '../types';

export function useCarWash() {
  const storage = CarWashStorage.getInstance();
  const [, setTick] = useState(0);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  useEffect(() => {
    const unsubscribe = storage.subscribe(() => {
      setTick(t => t + 1);
    });
    return unsubscribe;
  }, [storage]);

  const showToast = useCallback((text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(prev => (prev?.text === text ? null : prev));
    }, 4000);
  }, []);

  return {
    storage,
    currentUser: storage.currentUser,
    currentBusiness: storage.currentBusiness,
    businesses: storage.businesses,
    users: storage.users,
    employees: storage.employees.filter(e => e.businessId === storage.currentBusiness?.id),
    services: storage.services.filter(s => s.businessId === storage.currentBusiness?.id),
    customers: storage.customers.filter(c => c.businessId === storage.currentBusiness?.id),
    vehicles: storage.vehicles.filter(v => v.businessId === storage.currentBusiness?.id),
    transactions: storage.transactions.filter(t => t.businessId === storage.currentBusiness?.id),
    transactionStaff: storage.transactionStaff,
    queueHistory: storage.queueHistory.filter(q => q.businessId === storage.currentBusiness?.id),
    attendance: storage.attendance.filter(a => a.businessId === storage.currentBusiness?.id),
    packages: storage.packages.filter(p => p.businessId === storage.currentBusiness?.id),
    customerMemberships: storage.customerMemberships.filter(m => m.businessId === storage.currentBusiness?.id),
    pointRule: storage.currentBusiness ? storage.pointRules[storage.currentBusiness.id] : null,
    pointHistory: storage.pointHistory.filter(h => h.businessId === storage.currentBusiness?.id),
    auditLogs: storage.currentUser?.role === 'MASTER'
      ? storage.auditLogs
      : storage.auditLogs.filter(l => l.businessId === storage.currentBusiness?.id || l.businessId === null),
    toastMessage,
    showToast,
    clearToast: () => setToastMessage(null),
  };
}
