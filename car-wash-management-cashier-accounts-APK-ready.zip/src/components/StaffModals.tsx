import React, { useState } from 'react';
import { X, UserPlus, Edit, History, Lock, AlertCircle, Calculator } from 'lucide-react';
import { Employee, StaffProfitSetting } from '../types';

interface AddEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: { name: string; phone: string; position: string; profitPercentage: number }) => void;
}

export const AddEmployeeModal: React.FC<AddEmployeeModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [position, setPosition] = useState('Staff Cuci & Lap');
  const [percentage, setPercentage] = useState(30);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const samplePrice = 100000;
  const staffShare = (samplePrice * percentage) / 100;
  const ownerShare = samplePrice - staffShare;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      setError('Nama dan nomor HP wajib diisi.');
      return;
    }
    if (percentage < 0 || percentage > 100) {
      setError('Persentase komisi bagi hasil harus antara 0% - 100%.');
      return;
    }
    onConfirm({
      name: name.trim(),
      phone: phone.trim(),
      position: position.trim(),
      profitPercentage: percentage,
    });
    setName('');
    setPhone('');
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-sky-100 text-sky-700">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Tambah Staff Baru</h3>
              <p className="text-xs text-slate-500">Pendaftaran petugas cuci & pengaturan komisi</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nama Lengkap Staff <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Contoh: Budi Santoso"
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nomor WhatsApp / HP <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              required
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="08123456789"
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Jabatan / Posisi Kerja
            </label>
            <input
              type="text"
              value={position}
              onChange={e => setPosition(e.target.value)}
              placeholder="Kepala Cuci, Detailer, Teknisi..."
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">
                Persentase Bagi Hasil Komisi (%)
              </label>
              <span className="text-xs font-extrabold text-purple-700">{percentage}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={percentage}
              onChange={e => setPercentage(Number(e.target.value))}
              className="w-full accent-purple-600 cursor-pointer"
            />
            <p className="text-[10px] text-slate-400 mt-0.5">
              Rahasia Owner & Master. Tidak diperlihatkan ke Kasir.
            </p>
          </div>

          {/* Live Simulation Card */}
          <div className="p-3.5 rounded-xl bg-purple-50/60 border border-purple-200/70 text-xs space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-purple-900 text-[11px] mb-1">
              <Calculator className="w-3.5 h-3.5" />
              <span>Simulasi Komisi Transaksi Rp 100.000:</span>
            </div>
            <div className="flex justify-between text-purple-700">
              <span>• Bagian Staff ({percentage}%):</span>
              <span className="font-bold">Rp {staffShare.toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between text-emerald-700">
              <span>• Bagian Owner ({100 - percentage}%):</span>
              <span className="font-bold">Rp {ownerShare.toLocaleString('id-ID')}</span>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors cursor-pointer"
            >
              Simpan Staff
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface EditEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  employee: Employee | null;
  canManageProfit: boolean;
  onConfirm: (employeeId: number, updates: Partial<Employee>, notes?: string) => void;
}

export const EditEmployeeModal: React.FC<EditEmployeeModalProps> = ({
  isOpen,
  onClose,
  employee,
  canManageProfit,
  onConfirm,
}) => {
  const [name, setName] = useState(employee?.name || '');
  const [phone, setPhone] = useState(employee?.phone || '');
  const [position, setPosition] = useState(employee?.position || '');
  const [status, setStatus] = useState(employee?.status || 'ACTIVE');
  const [percentage, setPercentage] = useState(employee?.currentProfitPercentage || 30);
  const [notes, setNotes] = useState('');

  React.useEffect(() => {
    if (employee) {
      setName(employee.name);
      setPhone(employee.phone);
      setPosition(employee.position);
      setStatus(employee.status);
      setPercentage(employee.currentProfitPercentage);
    }
  }, [employee]);

  if (!isOpen || !employee) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(
      employee.id,
      {
        name: name.trim(),
        phone: phone.trim(),
        position: position.trim(),
        status,
        currentProfitPercentage: canManageProfit ? percentage : employee.currentProfitPercentage,
      },
      notes.trim()
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-sky-100 text-sky-700">
              <Edit className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Edit Data Staff</h3>
              <p className="text-xs text-slate-500">{employee.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Lengkap</label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Nomor HP</label>
            <input
              type="tel"
              required
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Jabatan</label>
            <input
              type="text"
              value={position}
              onChange={e => setPosition(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Status Keaktifan</label>
            <select
              value={status}
              onChange={e => setStatus(e.target.value as any)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            >
              <option value="ACTIVE">Aktif (Dapat ditugaskan di antrian)</option>
              <option value="INACTIVE">Nonaktif (Cuti / Berhenti)</option>
            </select>
          </div>

          {canManageProfit ? (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-700">
                  Persentase Bagi Hasil (%)
                </label>
                <span className="text-xs font-bold text-purple-700">{percentage}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={percentage}
                onChange={e => setPercentage(Number(e.target.value))}
                className="w-full accent-purple-600"
              />
              <input
                type="text"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Alasan perubahan persentase (opsional)..."
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
          ) : (
            <div className="p-3 bg-slate-100 rounded-xl flex items-center gap-2 text-xs text-slate-500">
              <Lock className="w-4 h-4" />
              <span>Persentase komisi terkunci (Hanya Owner & Master).</span>
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors cursor-pointer"
            >
              Perbarui Data
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface ProfitHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  employeeName: string;
  historyList: StaffProfitSetting[];
}

export const ProfitHistoryModal: React.FC<ProfitHistoryModalProps> = ({
  isOpen,
  onClose,
  employeeName,
  historyList,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-purple-100 text-purple-700">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Riwayat Bagi Hasil</h3>
              <p className="text-xs text-purple-700 font-bold">{employeeName}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          {historyList.length === 0 ? (
            <p className="text-center text-xs text-slate-400 py-6">Belum ada riwayat perubahan.</p>
          ) : (
            historyList.map(item => (
              <div key={item.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 text-xs space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-md">
                    {item.percentage}% Komisi
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {new Date(item.effectiveDate).toLocaleDateString('id-ID', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="text-slate-700 mt-1">Diubah oleh: <strong>{item.updatedBy}</strong></p>
                {item.notes && <p className="text-[11px] text-slate-500 italic">"{item.notes}"</p>}
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
