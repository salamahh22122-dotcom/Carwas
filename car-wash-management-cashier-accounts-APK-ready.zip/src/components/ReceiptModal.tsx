import React from 'react';
import {
  X,
  Printer,
  Copy,
  Share2,
  CheckCircle2,
  Car,
  Receipt,
  ShieldAlert,
} from 'lucide-react';
import { Transaction, Customer, Vehicle, Business } from '../types';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  customer?: Customer | null;
  vehicle?: Vehicle | null;
  business?: Business | null;
  canViewProfit: boolean;
  onCopySuccess?: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  transaction,
  customer,
  vehicle,
  business,
  canViewProfit,
  onCopySuccess,
}) => {
  if (!isOpen || !transaction) return null;

  const dateStr = new Date(transaction.createdAt).toLocaleString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const generateReceiptText = (): string => {
    return `
=================================
${business?.name || 'CLEANAUTO CAR WASH'}
${business?.address || 'Jakarta'}
Telp: ${business?.phone || '-'}
=================================
ANTRIAN: #${transaction.queueNumber}
NO. INVOICE: ${transaction.invoiceNo}
TANGGAL   : ${dateStr}
KASIR     : ${transaction.cashierName}
---------------------------------
PELANGGAN : ${customer?.name || 'Pelanggan Umum'}
PLAT NOMOR: ${vehicle?.licensePlate || '-'} (${vehicle?.brandModel || ''})
PETUGAS   : ${transaction.assignedStaffNames || '-'}
---------------------------------
LAYANAN:
• ${transaction.serviceName}
  Rp ${(transaction.servicePrice || transaction.totalAmount).toLocaleString('id-ID')}
${transaction.additionalServices ? `• ${transaction.additionalServices}\n  +Rp ${transaction.additionalAmount.toLocaleString('id-ID')}` : ''}
${transaction.discountAmount > 0 ? `• DISKON: -Rp ${transaction.discountAmount.toLocaleString('id-ID')}` : ''}
---------------------------------
TOTAL BAYAR : Rp ${transaction.totalAmount.toLocaleString('id-ID')}
METODE BAYAR: ${transaction.paymentMethod}
STATUS      : LUNAS / SELESAI
=================================
Terima kasih atas kunjungan Anda!
Kendaraan Anda Bersih & Berkilau.
=================================
    `.trim();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generateReceiptText());
    if (onCopySuccess) onCopySuccess();
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(generateReceiptText());
    const phone = customer?.phone?.replace(/[^0-9]/g, '') || '';
    const url = phone.startsWith('0')
      ? `https://wa.me/62${phone.substring(1)}?text=${text}`
      : `https://wa.me/${phone}?text=${text}`;
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <Receipt className="w-5 h-5 text-sky-600" />
            <h3 className="font-bold text-slate-800 text-sm">Struk Transaksi Digital</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Receipt Paper Container */}
        <div className="p-5 overflow-y-auto flex-1 bg-slate-100/60">
          <div className="bg-white p-6 rounded-xl border border-dashed border-slate-300 shadow-xs font-mono text-xs text-slate-800 leading-relaxed print:p-0 print:border-none print:shadow-none">
            {/* Business Logo & Header */}
            <div className="text-center pb-4 border-b border-dashed border-slate-300">
              <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-sky-600 text-white flex items-center justify-center font-sans font-black text-sm">
                <Car className="w-5 h-5" />
              </div>
              <h4 className="font-sans font-extrabold text-base tracking-tight text-slate-900">
                {business?.name || 'CleanAuto Car Wash'}
              </h4>
              <p className="text-[11px] text-slate-500 font-sans mt-0.5">{business?.address}</p>
              <p className="text-[11px] text-slate-500 font-sans">Telp: {business?.phone}</p>

              {/* Big Queue Badge */}
              <div className="mt-3 inline-block px-3 py-1 bg-sky-100 text-sky-800 rounded-lg font-sans font-black text-sm">
                ANTRIAN #{transaction.queueNumber}
              </div>
            </div>

            {/* Invoice Meta */}
            <div className="py-3 border-b border-dashed border-slate-200 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500">Invoice:</span>
                <span className="font-bold text-slate-900">{transaction.invoiceNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Waktu:</span>
                <span>{dateStr}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Kasir:</span>
                <span>{transaction.cashierName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Pelanggan:</span>
                <span className="font-semibold">{customer?.name || 'Pelanggan Umum'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Kendaraan:</span>
                <span className="font-bold text-slate-900">
                  {vehicle?.licensePlate || '-'} {vehicle?.brandModel ? `(${vehicle.brandModel})` : ''}
                </span>
              </div>
              {transaction.assignedStaffNames && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Petugas Cuci:</span>
                  <span className="text-sky-700 font-medium">{transaction.assignedStaffNames}</span>
                </div>
              )}
            </div>

            {/* Line Items */}
            <div className="py-3 border-b border-dashed border-slate-200 space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-slate-900">{transaction.serviceName}</p>
                  <p className="text-[10px] text-slate-500">Layanan Pokok</p>
                </div>
                <p className="font-semibold">
                  Rp {(transaction.servicePrice || transaction.totalAmount).toLocaleString('id-ID')}
                </p>
              </div>

              {transaction.additionalServices && (
                <div className="flex justify-between items-start text-slate-700">
                  <div>
                    <p className="text-[11px] font-medium">{transaction.additionalServices}</p>
                    <p className="text-[10px] text-slate-500">Tambahan Layanan</p>
                  </div>
                  <p className="font-semibold">+Rp {transaction.additionalAmount.toLocaleString('id-ID')}</p>
                </div>
              )}

              {transaction.discountAmount > 0 && (
                <div className="flex justify-between items-center text-red-600">
                  <span>Potongan Diskon</span>
                  <span>-Rp {transaction.discountAmount.toLocaleString('id-ID')}</span>
                </div>
              )}

              {transaction.pointsUsed > 0 && (
                <div className="flex justify-between items-center text-amber-600 text-[11px]">
                  <span>Reward Poin Ditukar</span>
                  <span>{transaction.pointsUsed} Poin</span>
                </div>
              )}
            </div>

            {/* Total */}
            <div className="py-3 border-b border-dashed border-slate-300 space-y-1.5 font-sans">
              <div className="flex justify-between items-center text-sm font-extrabold text-slate-900">
                <span>TOTAL BAYAR:</span>
                <span className="text-base text-sky-700">
                  Rp {transaction.totalAmount.toLocaleString('id-ID')}
                </span>
              </div>
              <div className="flex justify-between text-xs text-slate-600">
                <span>Metode Pembayaran:</span>
                <span className="font-bold uppercase bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                  {transaction.paymentMethod}
                </span>
              </div>
              {transaction.pointsEarned > 0 && (
                <div className="flex justify-between text-[11px] text-emerald-600 font-semibold">
                  <span>Poin Diperoleh:</span>
                  <span>+{transaction.pointsEarned} Poin</span>
                </div>
              )}
            </div>

            {/* Confidential Profit Split (Visible ONLY to Owner & Master) */}
            {canViewProfit ? (
              <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-lg text-[10px] space-y-1 font-sans">
                <div className="flex items-center gap-1 font-bold text-slate-700 mb-1">
                  <ShieldAlert className="w-3 h-3 text-sky-600" />
                  <span>Info Finansial Internal (Hanya Owner/Master):</span>
                </div>
                <div className="flex justify-between text-emerald-700">
                  <span>• Hak Bersih Owner:</span>
                  <span className="font-bold">Rp {transaction.ownerShareAmount.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-purple-700">
                  <span>• Komisi Bagi Hasil Staff:</span>
                  <span className="font-bold">Rp {transaction.staffShareAmount.toLocaleString('id-ID')}</span>
                </div>
              </div>
            ) : null}

            {/* Footer Note */}
            <div className="mt-4 text-center text-[10px] text-slate-400 font-sans space-y-0.5">
              <p>Terima kasih atas kunjungan Anda!</p>
              <p className="text-[9px]">Simpan struk ini sebagai bukti pengerjaan resmi.</p>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Salin teks struk"
            >
              <Copy className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Salin</span>
            </button>
            <button
              onClick={handleWhatsApp}
              className="px-3 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Kirim ke WhatsApp Pelanggan"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Kirim WA</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-2 text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              Selesai
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
