import React, { useState, useEffect } from 'react';
import {
  Database,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Copy,
  ExternalLink,
  UploadCloud,
  X,
  Shield,
  Server,
  AlertTriangle,
  Code,
} from 'lucide-react';
import { SupabaseSyncService, SupabaseSyncStatus } from '../data/supabaseSync';
import { SUPABASE_SQL_SCHEMA } from '../lib/supabase';
import { CarWashStorage } from '../data/storage';

interface SupabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  storage: CarWashStorage;
}

export const SupabaseModal: React.FC<SupabaseModalProps> = ({ isOpen, onClose, storage }) => {
  const syncService = SupabaseSyncService.getInstance();
  const [status, setStatus] = useState<SupabaseSyncStatus>(syncService.getStatus());
  const [isTesting, setIsTesting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [syncResult, setSyncResult] = useState<{
    success: boolean;
    syncedCount: Record<string, number>;
    errors: string[];
  } | null>(null);

  useEffect(() => {
    const unsub = syncService.subscribe(newStatus => {
      setStatus(newStatus);
    });
    // Run initial connection test when opened
    if (isOpen) {
      handleTestConnection();
    }
    return unsub;
  }, [isOpen]);

  const handleTestConnection = async () => {
    setIsTesting(true);
    setSyncResult(null);
    try {
      await syncService.testConnection();
    } finally {
      setIsTesting(false);
    }
  };

  const handleSyncData = async () => {
    setIsSyncing(true);
    try {
      const result = await syncService.syncAllToSupabase(storage);
      setSyncResult(result);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleCopySQL = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-500/10 via-sky-500/10 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-900">Koneksi Supabase Cloud</h3>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                    status.isConnected
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {status.isConnected ? 'Terhubung' : 'Memeriksa...'}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                PostgreSQL Cloud Database Integration
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-slate-700 text-xs">
          {/* Connection Status Card */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-600" />
                <span className="font-bold text-slate-900 text-sm">Status Endpoint Proyek</span>
              </div>
              <button
                type="button"
                onClick={handleTestConnection}
                disabled={isTesting}
                className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 flex items-center gap-1.5 shadow-xs cursor-pointer disabled:opacity-60"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                <span>Uji Koneksi Ulang</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Supabase URL
                </span>
                <span className="font-mono text-slate-800 break-all text-[11px] font-semibold">
                  https://ukavxclgnthzwewvozgl.supabase.co
                </span>
              </div>
              <div className="bg-white p-3 rounded-xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Koneksi & Latensi
                </span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  {status.isConnected ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-amber-500 shrink-0" />
                  )}
                  <span className="font-semibold text-slate-900">
                    {status.isConnected
                      ? `Terkoneksi Aktif (${status.latencyMs ?? 0}ms)`
                      : status.message}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Sync & Tables */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <UploadCloud className="w-4 h-4 text-sky-600" />
                  Sinkronisasi Data Lokal ke Supabase
                </h4>
                <p className="text-[11px] text-slate-500">
                  Kirim data usaha, user, transaksi kasir, dan layanan ke tabel Supabase.
                </p>
              </div>

              <button
                type="button"
                onClick={handleSyncData}
                disabled={isSyncing}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-70 transition-all"
              >
                <UploadCloud className={`w-4 h-4 ${isSyncing ? 'animate-bounce' : ''}`} />
                <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}</span>
              </button>
            </div>

            {/* Sync Result notification */}
            {syncResult && (
              <div
                className={`p-3.5 rounded-2xl border text-xs ${
                  syncResult.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-amber-50 border-amber-200 text-amber-900'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  {syncResult.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                  )}
                  <span>
                    {syncResult.success
                      ? 'Sinkronisasi Berhasil Sepenuhnya!'
                      : 'Sinkronisasi Sebagian Selesai (Perlu Skema Tabel)'}
                  </span>
                </div>

                {Object.keys(syncResult.syncedCount).length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {Object.entries(syncResult.syncedCount).map(([tbl, count]) => (
                      <span
                        key={tbl}
                        className="px-2 py-0.5 rounded-md bg-white border border-slate-200 font-mono text-[10px] text-slate-700 font-bold"
                      >
                        {tbl}: {count} baris
                      </span>
                    ))}
                  </div>
                )}

                {syncResult.errors.length > 0 && (
                  <div className="mt-2 space-y-1 text-[11px] text-amber-800/90 font-mono bg-white/80 p-2.5 rounded-xl border border-amber-200">
                    <div className="font-sans font-bold text-amber-900">
                      Catatan: Tabel belum dibuat di Supabase SQL Editor.
                    </div>
                    {syncResult.errors.map((err, i) => (
                      <div key={i}>• {err}</div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* SQL DDL Schema Box */}
          <div className="space-y-2 border-t border-slate-100 pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code className="w-4 h-4 text-purple-600" />
                <span className="font-bold text-slate-900 text-xs">
                  Skrip DDL Pembuatan Tabel PostgreSQL Supabase
                </span>
              </div>
              <button
                type="button"
                onClick={handleCopySQL}
                className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 text-xs font-bold rounded-xl border border-purple-200 flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Tersalin ke Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Salin Skrip SQL</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-[11px] text-slate-500">
              Jika tabel belum ada di database Supabase Anda, buka{' '}
              <a
                href="https://supabase.com/dashboard/project/ukavxclgnthzwewvozgl/sql/new"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sky-600 hover:underline font-bold inline-flex items-center gap-0.5"
              >
                Supabase SQL Editor <ExternalLink className="w-3 h-3" />
              </a>
              , paste skrip berikut lalu klik <strong>Run</strong>:
            </p>

            <div className="relative">
              <pre className="bg-slate-900 text-slate-200 p-3.5 rounded-2xl text-[10px] font-mono overflow-x-auto max-h-44 scrollbar-thin scrollbar-thumb-slate-700">
                {SUPABASE_SQL_SCHEMA}
              </pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <Shield className="w-3.5 h-3.5 text-emerald-600" />
            <span>Kredensial tersambung aman via Supabase Anon Key</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
