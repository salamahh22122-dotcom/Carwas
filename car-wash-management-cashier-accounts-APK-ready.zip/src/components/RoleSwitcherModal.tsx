import React from 'react';
import {
  X,
  Check,
  Shield,
  Briefcase,
  UserCheck,
  Lock,
  LogOut,
  AlertCircle,
} from 'lucide-react';
import { User, UserRole, USER_ROLES } from '../types';

interface RoleSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  users: User[];
  onSelectUser: (user: User) => void;
  onLogout: () => void;
}

export const RoleSwitcherModal: React.FC<RoleSwitcherModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  users,
  onSelectUser,
  onLogout,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-sky-100 text-sky-700">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Ganti Akun & Simulasi Role</h3>
              <p className="text-xs text-slate-500">Uji coba akses berjenjang (RBAC) dan kerahasiaan bagi hasil</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-4">
          <div className="bg-sky-50 border border-sky-200/70 rounded-xl p-3.5 flex items-start gap-3">
            <AlertCircle className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
            <p className="text-xs text-sky-900 leading-relaxed">
              <strong>Prinsip Keamanan:</strong> Pada peran <strong>Kasir</strong> dan <strong>Staff</strong>, persentase komisi bagi hasil dan total laba owner otomatis disembunyikan untuk menjaga privasi finansial.
            </p>
          </div>

          <div className="space-y-2.5">
            {users.map(user => {
              const meta = USER_ROLES[user.role];
              const isSelected = currentUser?.id === user.id;

              return (
                <div
                  key={user.id}
                  id={`switch_to_user_${user.username}`}
                  onClick={() => {
                    onSelectUser(user);
                    onClose();
                  }}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'border-sky-500 bg-sky-50/70 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/80'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm"
                      style={{ backgroundColor: meta.badgeBg, color: meta.badgeColor }}
                    >
                      {user.role === 'MASTER' && <Shield className="w-5 h-5" />}
                      {user.role === 'OWNER' && <Briefcase className="w-5 h-5" />}
                      {user.role === 'ADMIN' && <UserCheck className="w-5 h-5" />}
                      {user.role === 'KASIR' && <Lock className="w-5 h-5" />}
                      {user.role === 'STAFF' && <span className="text-xs">STF</span>}
                    </div>

                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-800 text-sm">{user.fullName}</span>
                        <span
                          className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                          style={{ backgroundColor: meta.badgeBg, color: meta.badgeColor }}
                        >
                          {meta.displayName}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        <span className="font-mono text-slate-600">@{user.username}</span> • {meta.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center pl-2">
                    {isSelected ? (
                      <span className="flex items-center gap-1 text-xs font-bold text-sky-700 bg-sky-100 px-2 py-1 rounded-md">
                        <Check className="w-3.5 h-3.5" />
                        Aktif
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-slate-400 hover:text-slate-700">Pilih</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <button
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="flex items-center gap-1.5 text-xs font-semibold text-red-600 hover:text-red-700 hover:underline cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Keluar (Kembali ke Halaman Login)
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
