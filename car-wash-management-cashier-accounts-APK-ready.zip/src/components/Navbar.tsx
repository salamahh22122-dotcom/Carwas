import React, { useState } from 'react';
import {
  Car,
  Shield,
  ArrowLeftRight,
  LogOut,
  Building2,
  Calendar,
  LayoutDashboard,
  Receipt,
  Clock,
  Users,
  Sparkles,
  UserCheck,
  CreditCard,
  BarChart3,
  Settings,
  Plus,
  Menu,
  X,
  Lock,
  CheckCircle2,
  Database,
} from 'lucide-react';
import { User, Business, USER_ROLES } from '../types';
import { CarWashStorage } from '../data/storage';

interface NavbarProps {
  storage: CarWashStorage;
  currentUser: User | null;
  currentBusiness: Business | null;
  businesses?: Business[];
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenRoleSwitcher: () => void;
  onOpenNewTx: () => void;
  onSwitchBusiness?: (biz: Business) => void;
  onLogout: () => void;
  queueActiveCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  storage,
  currentUser,
  currentBusiness,
  businesses = [],
  activeTab,
  onSelectTab,
  onOpenRoleSwitcher,
  onOpenNewTx,
  onSwitchBusiness,
  onLogout,
  queueActiveCount = 0,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const roleMeta = currentUser ? USER_ROLES[currentUser.role] : null;
  const isMaster = currentUser?.role === 'MASTER';
  const canViewFinancials = currentUser ? storage.canViewFinancials(currentUser.role) : false;

  const todayFormatted = new Date().toLocaleDateString('id-ID', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      roles: ['MASTER', 'OWNER', 'ADMIN', 'STAFF'],
    },
    {
      id: 'pos',
      label: 'Kasir POS',
      icon: Receipt,
      roles: ['MASTER', 'OWNER', 'ADMIN', 'KASIR'],
    },
    {
      id: 'antrian',
      label: 'Antrian Cuci',
      icon: Clock,
      badge: queueActiveCount > 0 ? queueActiveCount : undefined,
      roles: ['MASTER', 'OWNER', 'ADMIN', 'KASIR', 'STAFF'],
    },
    {
      id: 'pelanggan',
      label: 'Pelanggan & Mobil',
      icon: Users,
      roles: ['MASTER', 'OWNER', 'ADMIN', 'KASIR'],
    },
    {
      id: 'layanan',
      label: 'Layanan & Tarif',
      icon: Sparkles,
      roles: ['MASTER', 'OWNER', 'ADMIN', 'KASIR'],
    },
    {
      id: 'karyawan',
      label: 'Staf & Komisi',
      icon: UserCheck,
      roles: ['MASTER', 'OWNER', 'ADMIN'],
    },
    {
      id: 'absensi',
      label: 'Presensi',
      icon: Calendar,
      roles: ['MASTER', 'OWNER', 'ADMIN', 'STAFF'],
    },
    {
      id: 'membership',
      label: 'Membership',
      icon: CreditCard,
      roles: ['MASTER', 'OWNER', 'ADMIN'],
    },
    {
      id: 'laporan',
      label: 'Laporan Keuangan',
      icon: BarChart3,
      roles: ['MASTER', 'OWNER', 'KASIR'],
      restricted: !canViewFinancials,
    },
    ...(isMaster
      ? [
          {
            id: 'master',
            label: 'Master Multi-Cabang',
            icon: Building2,
            roles: ['MASTER'],
          },
        ]
      : []),
    {
      id: 'pengaturan',
      label: 'Pengaturan',
      icon: Settings,
      roles: ['MASTER', 'OWNER', 'ADMIN'],
    },
    {
      id: 'test',
      label: 'Skenario Test',
      icon: CheckCircle2,
      roles: ['MASTER', 'OWNER', 'ADMIN'],
    },
  ];

  const visibleNavItems = navItems.filter(
    item => currentUser && item.roles.includes(currentUser.role)
  );

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/90 shadow-xs">
      {/* Top Utility Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand & Business Info */}
          <div className="flex items-center space-x-3">
            <button
              onClick={() => onSelectTab('dashboard')}
              className="flex items-center space-x-3 text-left group cursor-pointer focus:outline-hidden"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-white shadow-xs group-hover:bg-sky-600 transition-colors">
                <Car className="w-5 h-5 text-sky-400 group-hover:text-white transition-colors" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-extrabold text-slate-900 text-base leading-tight tracking-tight">
                    {isMaster ? 'Master Control Center' : currentBusiness?.name || 'CleanAuto Car Wash'}
                  </span>
                  {isMaster && (
                    <span className="text-[10px] uppercase font-extrabold px-1.5 py-0.5 rounded-md bg-purple-100 text-purple-700 tracking-wider">
                      Multi-Tenant
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                  <span className="font-medium text-slate-600">{todayFormatted}</span>
                  {!isMaster && currentBusiness?.phone && (
                    <>
                      <span className="text-slate-300">•</span>
                      <span className="text-slate-400 hidden sm:inline">{currentBusiness.phone}</span>
                    </>
                  )}
                </p>
              </div>
            </button>
          </div>

          {/* Right Action Tools */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Quick Action: New Transaction Button */}
            {currentUser?.role !== 'STAFF' && (
              <button
                type="button"
                id="navbar_quick_tx_btn"
                onClick={onOpenNewTx}
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs hover:shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Transaksi Baru</span>
              </button>
            )}

            {/* Business Selector (If Master has multiple businesses) */}
            {isMaster && businesses.length > 1 && onSwitchBusiness && (
              <div className="hidden lg:flex items-center space-x-2 bg-slate-100 px-2.5 py-1.5 rounded-xl border border-slate-200">
                <Building2 className="w-3.5 h-3.5 text-slate-600" />
                <select
                  className="bg-transparent text-xs font-bold text-slate-800 focus:outline-hidden cursor-pointer pr-1"
                  value={currentBusiness?.id || ''}
                  onChange={e => {
                    const b = businesses.find(x => x.id === Number(e.target.value));
                    if (b) onSwitchBusiness(b);
                  }}
                >
                  {businesses.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Role Switcher Pill */}
            {currentUser && roleMeta && (
              <button
                type="button"
                id="top_bar_role_switcher_btn"
                onClick={onOpenRoleSwitcher}
                className="flex items-center space-x-2 px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 hover:border-slate-300 transition-all cursor-pointer text-left group"
                title="Ganti Role & Simulasi Hak Akses"
              >
                <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center font-bold text-[10px] text-slate-700 uppercase">
                  {currentUser.fullName.charAt(0)}
                </div>
                <div className="hidden md:block text-left leading-tight">
                  <p className="text-xs font-bold text-slate-800 group-hover:text-sky-700 transition-colors">
                    {currentUser.fullName}
                  </p>
                </div>
                <div
                  className="px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wide flex items-center gap-1"
                  style={{ backgroundColor: roleMeta.badgeBg, color: roleMeta.badgeColor }}
                >
                  <Shield className="w-3 h-3" />
                  <span>{roleMeta.displayName}</span>
                  <ArrowLeftRight className="w-2.5 h-2.5 opacity-60 group-hover:opacity-100 transition-opacity" />
                </div>
              </button>
            )}

            {/* Logout Button */}
            <button
              type="button"
              id="top_bar_logout_btn"
              onClick={onLogout}
              className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
              title="Keluar"
            >
              <LogOut className="w-4 h-4" />
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl lg:hidden cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Desktop Main Navigation Tabs */}
      <div className="border-t border-slate-100 bg-slate-50/70 hidden lg:block overflow-x-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-1 py-1.5">
            {visibleNavItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav_tab_${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 ${isActive ? 'text-sky-400' : 'text-slate-400'}`}
                  />
                  <span>{item.label}</span>
                  {item.badge !== undefined && (
                    <span
                      className={`ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-extrabold ${
                        isActive
                          ? 'bg-sky-500 text-white'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {item.restricted && (
                    <Lock className="w-3 h-3 text-slate-400 ml-0.5" />
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1 shadow-lg animate-in slide-in-from-top-2 duration-150">
          {currentUser?.role !== 'STAFF' && (
            <div className="pb-2 mb-2 border-b border-slate-100">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenNewTx();
                }}
                className="w-full py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ Transaksi Kasir Baru</span>
              </button>
            </div>
          )}

          <div className="grid grid-cols-2 gap-1.5">
            {visibleNavItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-bold transition-all text-left cursor-pointer ${
                    isActive
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-sky-400' : 'text-slate-500'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                  {item.badge !== undefined && (
                    <span className="ml-auto px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-2 mt-2 border-t border-slate-100 flex items-center justify-between">
            {currentUser?.role !== 'KASIR' && (
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenRoleSwitcher();
              }}
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-sky-700 py-1.5"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-slate-500" />
              <span>Ganti Akun</span>
            </button>
            )}

            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onLogout();
              }}
              className="flex items-center gap-1.5 text-xs font-bold text-red-600 hover:text-red-700 py-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Keluar (Logout)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
