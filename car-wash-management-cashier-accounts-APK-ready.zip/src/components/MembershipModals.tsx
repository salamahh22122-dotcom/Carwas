import React, { useState } from 'react';
import { X, CreditCard, Gift, Sparkles, AlertCircle } from 'lucide-react';
import { MembershipPackage, Customer, PointRule } from '../types';

interface AddPackageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: {
    name: string;
    price: number;
    totalVisits: number;
    validityDays: number;
    serviceName: string;
    description: string;
  }) => void;
}

export const AddPackageModal: React.FC<AddPackageModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('450000');
  const [totalVisits, setTotalVisits] = useState('10');
  const [validityDays, setValidityDays] = useState('60');
  const [serviceName, setServiceName] = useState('Cuci Salju Reguler (Mobil)');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Nama paket wajib diisi.');
      return;
    }
    const numPrice = parseFloat(price);
    const numVisits = parseInt(totalVisits);
    if (isNaN(numPrice) || numPrice <= 0 || isNaN(numVisits) || numVisits <= 0) {
      setError('Harga dan kuota kunjungan harus valid.');
      return;
    }

    onConfirm({
      name: name.trim(),
      price: numPrice,
      totalVisits: numVisits,
      validityDays: parseInt(validityDays) || 30,
      serviceName: serviceName.trim(),
      description: description.trim(),
    });
    setName('');
    setDescription('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Tambah Paket Membership</h3>
              <p className="text-xs text-slate-500">Paket cuci berkala / langganan</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nama Paket <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Contoh: PAKET 10X CUCI SALJU"
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Harga (Rp)</label>
              <input
                type="number"
                required
                min="0"
                value={price}
                onChange={e => setPrice(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Kuota Kunjungan</label>
              <input
                type="number"
                required
                min="1"
                value={totalVisits}
                onChange={e => setTotalVisits(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Masa Berlaku (Hari)</label>
              <input
                type="number"
                min="1"
                value={validityDays}
                onChange={e => setValidityDays(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Layanan Pokok</label>
              <input
                type="text"
                value={serviceName}
                onChange={e => setServiceName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Deskripsi Paket</label>
            <textarea
              rows={2}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Keuntungan paket cuci..."
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl cursor-pointer"
            >
              Simpan Paket
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface PurchaseMembershipModalProps {
  isOpen: boolean;
  onClose: () => void;
  pkg: MembershipPackage | null;
  customers: Customer[];
  onConfirm: (customerId: number, pkg: MembershipPackage) => void;
}

export const PurchaseMembershipModal: React.FC<PurchaseMembershipModalProps> = ({
  isOpen,
  onClose,
  pkg,
  customers,
  onConfirm,
}) => {
  const [selectedCustomerId, setSelectedCustomerId] = useState<number>(customers[0]?.id || 0);

  if (!isOpen || !pkg) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId) return;
    onConfirm(selectedCustomerId, pkg);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Beli Paket Membership</h3>
              <p className="text-xs text-slate-500">{pkg.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200/80 space-y-1 text-xs text-emerald-900">
            <p className="font-bold text-sm text-emerald-800">{pkg.name}</p>
            <p>Harga: <strong>Rp {pkg.price.toLocaleString('id-ID')}</strong></p>
            <p>Kuota: <strong>{pkg.totalVisits}x Kunjungan Cuci</strong></p>
            <p>Masa Berlaku: <strong>{pkg.validityDays} Hari</strong></p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Pilih Pelanggan Penerima
            </label>
            <select
              value={selectedCustomerId}
              onChange={e => setSelectedCustomerId(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            >
              {customers.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone})
                </option>
              ))}
            </select>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl cursor-pointer"
            >
              Aktifkan Paket
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface EditPointRuleModalProps {
  isOpen: boolean;
  onClose: () => void;
  pointRule: PointRule | null;
  onConfirm: (data: Partial<PointRule>) => void;
}

export const EditPointRuleModal: React.FC<EditPointRuleModalProps> = ({
  isOpen,
  onClose,
  pointRule,
  onConfirm,
}) => {
  const [spendAmount, setSpendAmount] = useState(pointRule?.spendAmountPerPoint.toString() || '10000');
  const [pointsEarned, setPointsEarned] = useState(pointRule?.pointsEarned.toString() || '1');
  const [redeemValue, setRedeemValue] = useState(pointRule?.pointRedeemValue.toString() || '1000');
  const [isEnabled, setIsEnabled] = useState(pointRule?.isEnabled ?? true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm({
      spendAmountPerPoint: parseFloat(spendAmount) || 10000,
      pointsEarned: parseInt(pointsEarned) || 1,
      pointRedeemValue: parseFloat(redeemValue) || 1000,
      isEnabled,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Aturan Program Poin Loyalitas</h3>
              <p className="text-xs text-slate-500">Kalkulasi perolehan & penukaran reward poin</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <p className="text-xs font-bold text-slate-800">Status Program Poin</p>
              <p className="text-[11px] text-slate-500">Hitung otomatis reward saat transaksi kasir</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={isEnabled}
                onChange={e => setIsEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
            </label>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nominal Belanja per Kelipatan Poin (Rp)
            </label>
            <input
              type="number"
              value={spendAmount}
              onChange={e => setSpendAmount(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
            <p className="text-[10px] text-slate-400 mt-1">Misal Rp 10.000 = 1 Poin</p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Poin yang Diperoleh per Kelipatan
            </label>
            <input
              type="number"
              value={pointsEarned}
              onChange={e => setPointsEarned(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nilai Diskon per 1 Poin (Rp)
            </label>
            <input
              type="number"
              value={redeemValue}
              onChange={e => setRedeemValue(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
            <p className="text-[10px] text-slate-400 mt-1">Misal 1 Poin dapat ditukar diskon Rp 1.000</p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl cursor-pointer"
            >
              Simpan Aturan
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface AdjustPointsModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer | null;
  onConfirm: (customerId: number, delta: number, description: string) => void;
}

export const AdjustPointsModal: React.FC<AdjustPointsModalProps> = ({
  isOpen,
  onClose,
  customer,
  onConfirm,
}) => {
  const [delta, setDelta] = useState('10');
  const [isAdd, setIsAdd] = useState(true);
  const [description, setDescription] = useState('');

  if (!isOpen || !customer) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Math.abs(parseInt(delta) || 0);
    if (amount === 0) return;
    const finalDelta = isAdd ? amount : -amount;
    onConfirm(customer.id, finalDelta, description.trim() || (isAdd ? 'Bonus loyalitas manual' : 'Koreksi saldo poin'));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Penyesuaian Poin Pelanggan</h3>
              <p className="text-xs text-slate-500">{customer.name} (Saldo: {customer.pointsBalance} Poin)</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setIsAdd(true)}
              className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                isAdd ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs' : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              + Tambah Bonus Poin
            </button>
            <button
              type="button"
              onClick={() => setIsAdd(false)}
              className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                !isAdd ? 'bg-red-600 text-white border-red-600 shadow-xs' : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              - Kurangi Saldo Poin
            </button>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Jumlah Poin</label>
            <input
              type="number"
              min="1"
              required
              value={delta}
              onChange={e => setDelta(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Alasan Penyesuaian</label>
            <input
              type="text"
              required
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Contoh: Reward pelanggan setia, kompensasi antrian lama..."
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl cursor-pointer"
            >
              Simpan Poin
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
