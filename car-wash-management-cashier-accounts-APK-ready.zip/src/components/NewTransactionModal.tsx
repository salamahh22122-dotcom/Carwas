import React, { useState, useMemo } from 'react';
import {
  X,
  Car,
  Search,
  Plus,
  Check,
  Percent,
  Sparkles,
  Lock,
  Receipt,
  AlertCircle,
  CreditCard,
  Banknote,
  QrCode,
  Users,
} from 'lucide-react';
import {
  Customer,
  Vehicle,
  Service,
  Employee,
  AdditionalOption,
  DEFAULT_ADDITIONAL_SERVICES,
  Transaction,
  CustomerMembership,
  PointRule,
} from '../types';

interface NewTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  customers: Customer[];
  vehicles: Vehicle[];
  services: Service[];
  employees: Employee[];
  customerMemberships: CustomerMembership[];
  pointRule: PointRule | null;
  canViewProfit: boolean;
  onOpenQuickCustomer: () => void;
  onConfirm: (params: {
    customerId: number;
    vehicleId: number;
    service: Service;
    assignedStaff: Employee[];
    additionalItems: AdditionalOption[];
    discountAmount: number;
    paymentMethod: string;
    notes: string;
    usedMembershipId?: number | null;
    pointsToRedeem?: number;
  }) => void;
}

export const NewTransactionModal: React.FC<NewTransactionModalProps> = ({
  isOpen,
  onClose,
  customers,
  vehicles,
  services,
  employees,
  customerMemberships,
  pointRule,
  canViewProfit,
  onOpenQuickCustomer,
  onConfirm,
}) => {
  const [searchPlate, setSearchPlate] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(vehicles[0] || null);
  const [selectedService, setSelectedService] = useState<Service | null>(
    services.find(s => s.isActive) || services[0] || null
  );
  const [selectedStaff, setSelectedStaff] = useState<Employee[]>(
    employees.filter(e => e.status === 'ACTIVE').slice(0, 1)
  );
  const [selectedAddons, setSelectedAddons] = useState<AdditionalOption[]>([]);
  const [discountInput, setDiscountInput] = useState('0');
  const [useMembershipQuota, setUseMembershipQuota] = useState(false);
  const [pointsToRedeem, setPointsToRedeem] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('QRIS');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Match vehicles
  const matchingVehicles = useMemo(() => {
    if (!searchPlate.trim()) return vehicles.slice(0, 4);
    const q = searchPlate.trim().toLowerCase();
    return vehicles.filter(
      v => v.licensePlate.toLowerCase().includes(q) || v.brandModel.toLowerCase().includes(q)
    );
  }, [searchPlate, vehicles]);

  const currentCustomer = useMemo(() => {
    if (!selectedVehicle) return null;
    return customers.find(c => c.id === selectedVehicle.customerId) || null;
  }, [selectedVehicle, customers]);

  // Active membership check
  const activeMembership = useMemo(() => {
    if (!currentCustomer) return null;
    const now = Date.now();
    return customerMemberships.find(
      m => m.customerId === currentCustomer.id && m.remainingQuota > 0 && m.expiresAt > now
    );
  }, [currentCustomer, customerMemberships]);

  // Calculations
  const servicePrice = selectedService?.price || 0;
  const addonsTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
  const manualDiscount = parseFloat(discountInput) || 0;
  const pointRate = pointRule?.pointRedeemValue || 1000;
  const pointDiscount = pointRule?.isEnabled ? pointsToRedeem * pointRate : 0;
  const membershipDiscount = useMembershipQuota && activeMembership ? servicePrice : 0;
  const totalDiscount = Math.min(servicePrice + addonsTotal, manualDiscount + pointDiscount + membershipDiscount);
  const finalTotal = Math.max(0, servicePrice + addonsTotal - totalDiscount);

  // Staff and Owner share simulation (For Owner / Master only)
  const staffPortion = selectedStaff.length > 0 ? finalTotal / selectedStaff.length : 0;
  const totalStaffShare = selectedStaff.reduce((sum, emp) => {
    return sum + (staffPortion * emp.currentProfitPercentage) / 100.0;
  }, 0);
  const ownerShare = Math.max(0, finalTotal - totalStaffShare);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVehicle || !currentCustomer) {
      setError('Pilih kendaraan & pelanggan terlebih dahulu.');
      return;
    }
    if (!selectedService) {
      setError('Pilih layanan utama.');
      return;
    }
    if (selectedStaff.length === 0) {
      setError('Kasir WAJIB memilih minimal 1 Staff / Petugas pengerja!');
      return;
    }

    onConfirm({
      customerId: currentCustomer.id,
      vehicleId: selectedVehicle.id,
      service: selectedService,
      assignedStaff: selectedStaff,
      additionalItems: selectedAddons,
      discountAmount: totalDiscount,
      paymentMethod,
      notes: notes.trim(),
      usedMembershipId: useMembershipQuota ? activeMembership?.id : null,
      pointsToRedeem: pointsToRedeem > 0 ? pointsToRedeem : undefined,
    });

    onClose();
  };

  const toggleStaff = (emp: Employee) => {
    if (selectedStaff.some(e => e.id === emp.id)) {
      setSelectedStaff(selectedStaff.filter(e => e.id !== emp.id));
    } else {
      setSelectedStaff([...selectedStaff, emp]);
    }
  };

  const toggleAddon = (opt: AdditionalOption) => {
    if (selectedAddons.some(a => a.id === opt.id)) {
      setSelectedAddons(selectedAddons.filter(a => a.id !== opt.id));
    } else {
      setSelectedAddons([...selectedAddons, opt]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-sky-100 text-sky-700">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Kasir Transaksi Baru (POS)</h3>
              <p className="text-xs text-slate-500">Pendaftaran antrian pengerjaan cuci mobil</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. KENDARAAN & PELANGGAN */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-sky-700 flex items-center gap-1.5">
                <Car className="w-4 h-4" />
                1. Data Kendaraan & Pelanggan
              </label>
              <button
                type="button"
                onClick={onOpenQuickCustomer}
                className="text-xs font-bold text-sky-600 hover:text-sky-700 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                + Mobil & Pelanggan Baru
              </button>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchPlate}
                onChange={e => setSearchPlate(e.target.value.toUpperCase())}
                placeholder="Ketik plat nomor untuk mencari (misal: B 1234 ABC)..."
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
              {matchingVehicles.map(veh => {
                const owner = customers.find(c => c.id === veh.customerId);
                const isSelected = selectedVehicle?.id === veh.id;
                return (
                  <div
                    key={veh.id}
                    onClick={() => {
                      setSelectedVehicle(veh);
                      setError(null);
                    }}
                    className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'border-sky-500 bg-sky-50/80 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 tracking-wider">{veh.licensePlate}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-sky-600" />}
                    </div>
                    <p className="text-slate-600 truncate mt-0.5">
                      {veh.brandModel} ({veh.color})
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Pemilik: {owner?.name || 'Pelanggan'} • {owner?.phone || '-'}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. LAYANAN UTAMA */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="text-xs font-bold uppercase tracking-wider text-sky-700 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              2. Pilihan Layanan Pokok
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {services
                .filter(s => s.isActive)
                .map(srv => {
                  const isSelected = selectedService?.id === srv.id;
                  return (
                    <div
                      key={srv.id}
                      onClick={() => {
                        setSelectedService(srv);
                        setError(null);
                      }}
                      className={`p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'border-sky-500 bg-sky-50/80 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-bold text-xs text-slate-900">{srv.name}</p>
                          <p className="text-[10px] text-slate-500">{srv.category} • ~{srv.estimatedDurationMinutes} mnt</p>
                        </div>
                        <span className="text-xs font-bold text-sky-700">
                          Rp {srv.price.toLocaleString('id-ID')}
                        </span>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* 3. TAMBAHAN LAYANAN */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="text-xs font-bold uppercase tracking-wider text-sky-700">
              3. Tambahan Layanan Ekstra (Opsional)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {DEFAULT_ADDITIONAL_SERVICES.map(opt => {
                const isChecked = selectedAddons.some(a => a.id === opt.id);
                return (
                  <label
                    key={opt.id}
                    className={`flex items-center justify-between p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      isChecked
                        ? 'border-cyan-500 bg-cyan-50/60 text-slate-900'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleAddon(opt)}
                        className="rounded-sm text-sky-600 focus:ring-sky-500"
                      />
                      <span>{opt.name}</span>
                    </div>
                    <span className="font-semibold text-[11px] text-sky-700">
                      +Rp {opt.price.toLocaleString('id-ID')}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* 4. DISKON, MEMBERSHIP & POIN */}
          <div className="space-y-2.5 pt-2 border-t border-slate-100">
            <label className="text-xs font-bold uppercase tracking-wider text-sky-700 flex items-center gap-1.5">
              <Percent className="w-4 h-4" />
              4. Diskon, Membership & Reward Poin
            </label>

            {/* Membership Quota Checkbox */}
            {activeMembership && (
              <div
                onClick={() => setUseMembershipQuota(!useMembershipQuota)}
                className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between ${
                  useMembershipQuota ? 'bg-emerald-50 border-emerald-300' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={useMembershipQuota}
                      onChange={() => setUseMembershipQuota(!useMembershipQuota)}
                      className="rounded-sm text-emerald-600"
                    />
                    <span className="text-xs font-bold text-slate-900">Gunakan Kuota Membership</span>
                  </div>
                  <p className="text-[10px] text-emerald-700 mt-0.5 ml-5">
                    {activeMembership.packageName} (Sisa {activeMembership.remainingQuota}x kuota cuci gratis)
                  </p>
                </div>
                {useMembershipQuota && (
                  <span className="text-xs font-bold text-emerald-700">
                    -Rp {servicePrice.toLocaleString('id-ID')}
                  </span>
                )}
              </div>
            )}

            {/* Loyalty Points Redemption */}
            {currentCustomer && currentCustomer.pointsBalance > 0 && pointRule?.isEnabled && (
              <div className="p-3 rounded-xl bg-amber-50/60 border border-amber-200 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-amber-900">
                    Reward Poin Pelanggan: {currentCustomer.pointsBalance} Poin
                  </span>
                  <p className="text-[10px] text-amber-700">
                    1 Poin = Potongan Rp {pointRate.toLocaleString('id-ID')}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <select
                    value={pointsToRedeem}
                    onChange={e => setPointsToRedeem(Number(e.target.value))}
                    className="px-2 py-1 bg-white border border-amber-300 rounded-lg text-xs font-bold text-amber-900"
                  >
                    <option value={0}>0 Poin</option>
                    {currentCustomer.pointsBalance >= 5 && <option value={5}>5 Poin (-Rp 5.000)</option>}
                    {currentCustomer.pointsBalance >= 10 && <option value={10}>10 Poin (-Rp 10.000)</option>}
                    <option value={currentCustomer.pointsBalance}>
                      Semua ({currentCustomer.pointsBalance} Poin)
                    </option>
                  </select>
                </div>
              </div>
            )}

            {/* Manual Discount Input */}
            <div className="flex items-center gap-3">
              <div className="w-1/2">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Potongan Diskon Manual (Rp)
                </label>
                <input
                  type="number"
                  min="0"
                  value={discountInput}
                  onChange={e => setDiscountInput(e.target.value)}
                  placeholder="0"
                  className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                />
              </div>
              <div className="w-1/2 flex items-end gap-1.5 pb-0.5">
                {['0', '5000', '10000', '15000'].map(d => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDiscountInput(d)}
                    className={`px-2 py-1 text-[10px] font-bold rounded-lg border transition-colors cursor-pointer ${
                      discountInput === d
                        ? 'bg-sky-600 text-white border-sky-600'
                        : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    {d === '0' ? 'Nol' : `${parseInt(d) / 1000}k`}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 5. PETUGAS / STAFF PENGERJA (MANDATORY) */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-sky-700 flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                5. Petugas / Staff yang Mengerjakan <span className="text-red-500 font-extrabold">*WAJIB</span>
              </label>
              {!canViewProfit && (
                <span className="text-[10px] text-slate-400 flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Komisi dirahasiakan
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {employees
                .filter(e => e.status === 'ACTIVE')
                .map(emp => {
                  const isChecked = selectedStaff.some(e => e.id === emp.id);
                  return (
                    <div
                      key={emp.id}
                      onClick={() => toggleStaff(emp)}
                      className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                        isChecked
                          ? 'border-sky-500 bg-sky-50/80 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleStaff(emp)}
                          className="rounded-sm text-sky-600"
                        />
                        <div>
                          <p className="font-bold text-slate-900">{emp.name}</p>
                          <p className="text-[10px] text-slate-500">{emp.position}</p>
                        </div>
                      </div>

                      {canViewProfit ? (
                        <span className="text-[11px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md">
                          {emp.currentProfitPercentage}% Bagi Hasil
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">Ditugaskan</span>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>

          {/* 6. METODE PEMBAYARAN */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="text-xs font-bold uppercase tracking-wider text-sky-700">
              6. Metode Pembayaran
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'QRIS', label: 'QRIS', icon: QrCode },
                { id: 'CASH', label: 'Tunai', icon: Banknote },
                { id: 'TRANSFER', label: 'Transfer', icon: CreditCard },
                { id: 'MEMBERSHIP', label: 'Member', icon: Sparkles },
              ].map(item => {
                const Icon = item.icon;
                const isSel = paymentMethod === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setPaymentMethod(item.id)}
                    className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      isSel
                        ? 'border-sky-500 bg-sky-600 text-white font-bold shadow-xs'
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-xs">{item.label}</span>
                  </button>
                );
              })}
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Catatan Transaksi (Opsional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Misal: Titip kunci mobil, minta parfum kopi..."
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
          </div>

          {/* 7. RINGKASAN TOTAL PEMBAYARAN */}
          <div className="p-4 rounded-xl bg-slate-900 text-white space-y-2">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Layanan ({selectedService?.name || '-'}):</span>
              <span>Rp {servicePrice.toLocaleString('id-ID')}</span>
            </div>
            {addonsTotal > 0 && (
              <div className="flex justify-between text-xs text-slate-300">
                <span>Tambahan ({selectedAddons.length} item):</span>
                <span>+Rp {addonsTotal.toLocaleString('id-ID')}</span>
              </div>
            )}
            {totalDiscount > 0 && (
              <div className="flex justify-between text-xs text-red-300">
                <span>Total Potongan Diskon:</span>
                <span>-Rp {totalDiscount.toLocaleString('id-ID')}</span>
              </div>
            )}

            <div className="pt-2 border-t border-slate-700 flex justify-between items-baseline">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                TOTAL BAYAR:
              </span>
              <span className="text-xl font-black text-cyan-400">
                Rp {finalTotal.toLocaleString('id-ID')}
              </span>
            </div>

            {/* Confidential Owner / Staff Share calculation */}
            {canViewProfit && selectedStaff.length > 0 && (
              <div className="pt-2 border-t border-slate-800 text-[11px] space-y-1 text-slate-400">
                <div className="flex justify-between">
                  <span>• Hak Bersih Owner:</span>
                  <span className="font-bold text-emerald-400">
                    Rp {ownerShare.toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>• Komisi Bagi Hasil Staff ({selectedStaff.length} orang):</span>
                  <span className="font-bold text-purple-400">
                    Rp {totalStaffShare.toLocaleString('id-ID')}
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              id="btn_confirm_new_transaction"
              className="px-6 py-2.5 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition-colors shadow-sm shadow-sky-200 flex items-center gap-1.5 cursor-pointer"
            >
              <Receipt className="w-4 h-4" />
              <span>Proses & Masuk Antrian</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
