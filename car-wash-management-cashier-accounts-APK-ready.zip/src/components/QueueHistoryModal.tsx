import React from 'react';
import { X, History, Car, Clock } from 'lucide-react';
import { Vehicle, VehicleStatusHistory, QUEUE_STATUSES } from '../types';

interface QueueHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  vehicle: Vehicle | null;
  historyList: VehicleStatusHistory[];
}

export const QueueHistoryModal: React.FC<QueueHistoryModalProps> = ({
  isOpen,
  onClose,
  vehicle,
  historyList,
}) => {
  if (!isOpen || !vehicle) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-sky-100 text-sky-700">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Riwayat Alur Kendaraan</h3>
              <p className="text-xs text-slate-500 font-mono font-bold text-sky-700">
                {vehicle.licensePlate} • {vehicle.brandModel}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Timeline list */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {historyList.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              Belum ada riwayat pergerakan status untuk kendaraan ini.
            </div>
          ) : (
            <div className="relative border-l-2 border-slate-200 ml-4 pl-4 space-y-6">
              {historyList.map(item => {
                const meta = QUEUE_STATUSES[item.status];
                const timeStr = new Date(item.timestamp).toLocaleString('id-ID', {
                  day: 'numeric',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div key={item.id} className="relative">
                    {/* Timeline dot */}
                    <div
                      className="absolute -left-[25px] top-0.5 w-4 h-4 rounded-full border-2 border-white shadow-xs"
                      style={{ backgroundColor: meta.color }}
                    />

                    <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                      <div className="flex items-center justify-between">
                        <span
                          className="text-xs font-bold px-2 py-0.5 rounded-md"
                          style={{ backgroundColor: meta.bg, color: meta.color }}
                        >
                          {meta.displayName}
                        </span>
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {timeStr}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 mt-2">
                        Petugas: <strong className="text-slate-800">{item.updatedBy}</strong>
                      </p>
                      {item.notes && (
                        <p className="text-[11px] text-slate-500 italic mt-1 bg-white p-2 rounded-lg border border-slate-100">
                          "{item.notes}"
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
